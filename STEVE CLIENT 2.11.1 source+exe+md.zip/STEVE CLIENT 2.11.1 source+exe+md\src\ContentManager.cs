using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Threading;

namespace SteveClient
{
    internal enum ContentKind
    {
        Mod,
        TexturePack,
        World,
        Template
    }

    internal sealed class ContentProfile
    {
        public string DisplayName = string.Empty;
        public string UserName = string.Empty;
        public string PackageFamily = string.Empty;
        public string DataDir = string.Empty;
        public string SharedDir = string.Empty;
        public string RootDir = string.Empty;
        public string AccountId = string.Empty;
        public bool IsPreview;
        public bool IsCurrentUser;
        public bool IsCustom;
        public bool IsGDK;
        public bool IsReadOnly;
        public bool Exists;

        public string KindText
        {
            get
            {
                if (IsReadOnly) return "只读";
                if (IsCustom) return "自定义";
                if (IsGDK) return IsPreview ? "预览版" : "正式版";
                return "旧版 UWP";
            }
        }
    }

    internal sealed class ContentItem
    {
        public ContentKind Kind;
        public string Name = string.Empty;
        public string Version = string.Empty;
        public string Uuid = string.Empty;
        public string FolderPath = string.Empty;
        public string IconPath = string.Empty;
        public string ArchivePath = string.Empty;
        public string ArchiveIconEntry = string.Empty;
        public DateTime Modified;

        public string KindText
        {
            get
            {
                switch (Kind)
                {
                    case ContentKind.World: return "世界";
                    case ContentKind.Template: return "模板";
                    case ContentKind.TexturePack: return "资源包";
                    default: return "行为包";
                }
            }
        }

        public string MetaText
        {
            get
            {
                if (Kind == ContentKind.World) return "存档  ·  " + Modified.ToString("yyyy/MM/dd HH:mm");
                if (Kind == ContentKind.Template)
                    return (string.IsNullOrEmpty(Version) ? "模板" : "v" + Version) + "  ·  " + Modified.ToString("yyyy/MM/dd HH:mm");
                string prefix = string.IsNullOrEmpty(Version) ? "版本未知" : "v" + Version;
                return prefix + "  ·  " + Modified.ToString("yyyy/MM/dd HH:mm");
            }
        }
    }

    internal sealed class ContentInstallResult
    {
        public bool Success;
        public bool Skipped;
        public ContentKind Kind;
        public string Message = string.Empty;
        public string TargetPath = string.Empty;
    }

    internal sealed class ContentConflict
    {
        public ContentKind Kind;
        public string Name = string.Empty;
        public string Uuid = string.Empty;
        public string ExistingPath = string.Empty;
    }

    internal sealed class ImportProgress
    {
        public string FileName = string.Empty;
        public string Phase = string.Empty;
        public long CompletedBytes;
        public long TotalBytes;
        public bool Indeterminate;

        public double Fraction
        {
            get
            {
                if (Indeterminate || TotalBytes <= 0) return 0;
                return Math.Max(0, Math.Min(1, (double)CompletedBytes / TotalBytes));
            }
        }
    }

    internal sealed class PackManifest
    {
        public string Folder = string.Empty;
        public string Name = string.Empty;
        public string Version = string.Empty;
        public string Uuid = string.Empty;
        public bool HasResources;
        public bool HasBehavior;
        public bool HasWorldTemplate;
        public string Error = string.Empty;
    }

    /// <summary>
    /// Finds the Minecraft data directories on this PC. Modern GDK builds keep
    /// one com.mojang per Xbox account under %APPDATA%\Minecraft Bedrock\Users\&lt;XUID&gt;,
    /// with packs shared in Users\Shared. Older UWP builds use
    /// %LOCALAPPDATA%\Packages\&lt;PFN&gt;\LocalState\games\com.mojang instead.
    /// </summary>
    internal static class ContentProfiles
    {
        public static List<ContentProfile> Discover(AppConfig config)
        {
            List<ContentProfile> list = new List<ContentProfile>();
            string roaming = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string currentProfileDir = string.IsNullOrEmpty(local) ? string.Empty : Path.GetDirectoryName(local);

            if (!string.IsNullOrEmpty(roaming)) AddGdkProfiles(list, roaming, Environment.UserName, true);
            if (!string.IsNullOrEmpty(local)) AddLegacyProfiles(list, local, Environment.UserName, true);

            string usersRoot = string.IsNullOrEmpty(currentProfileDir) ? string.Empty : Path.GetDirectoryName(currentProfileDir);
            if (!string.IsNullOrEmpty(usersRoot))
            {
                string[] userDirs;
                try { userDirs = Directory.GetDirectories(usersRoot); }
                catch { userDirs = new string[0]; }
                foreach (string dir in userDirs)
                {
                    if (!string.IsNullOrEmpty(currentProfileDir) &&
                        string.Equals(dir, currentProfileDir, StringComparison.OrdinalIgnoreCase)) continue;
                    string name = Path.GetFileName(dir);
                    if (string.Equals(name, "Public", StringComparison.OrdinalIgnoreCase)) continue;
                    if (string.Equals(name, "Default", StringComparison.OrdinalIgnoreCase)) continue;
                    if (string.Equals(name, "Default User", StringComparison.OrdinalIgnoreCase)) continue;
                    if (string.Equals(name, "All Users", StringComparison.OrdinalIgnoreCase)) continue;
                    string otherRoaming = Path.Combine(dir, "AppData", "Roaming");
                    if (Directory.Exists(otherRoaming)) AddGdkProfiles(list, otherRoaming, name, false);
                    string otherLocal = Path.Combine(dir, "AppData", "Local");
                    if (Directory.Exists(otherLocal)) AddLegacyProfiles(list, otherLocal, name, false);
                }
            }

            string custom = config != null ? config.ResourceDataDir : null;
            if (config != null && config.ResourceCustom && !string.IsNullOrWhiteSpace(custom) && !ContainsPath(list, custom))
            {
                ContentProfile profile = new ContentProfile();
                profile.DisplayName = "自定义目录";
                profile.DataDir = custom;
                profile.SharedDir = custom;
                profile.IsCustom = true;
                profile.IsCurrentUser = true;
                profile.Exists = Directory.Exists(custom);
                list.Add(profile);
            }

            string scanDir = config != null ? config.ResourceScanDir : null;
            if (!string.IsNullOrWhiteSpace(scanDir) && Directory.Exists(scanDir) && !ContainsPath(list, scanDir))
            {
                ContentProfile profile = new ContentProfile();
                profile.DisplayName = "外部扫描目录";
                profile.DataDir = scanDir;
                profile.SharedDir = scanDir;
                profile.IsReadOnly = true;
                profile.Exists = true;
                list.Add(profile);
            }

            if (list.Count == 0) list.Add(CreateFallback());
            return list;
        }

        public static ContentProfile CreateFallback()
        {
            ContentProfile profile = new ContentProfile();
            profile.UserName = Environment.UserName;
            profile.IsCurrentUser = true;
            profile.PackageFamily = GameLauncher.StableFamily;
            profile.DisplayName = Environment.UserName + " · 正式版";
            profile.DataDir = PackageDataDir(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                GameLauncher.StableFamily);
            profile.SharedDir = profile.DataDir;
            profile.Exists = Directory.Exists(profile.DataDir);
            return profile;
        }

        public static string Shorten(string path)
        {
            if (string.IsNullOrEmpty(path)) return string.Empty;
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (!string.IsNullOrEmpty(local) && path.StartsWith(local, StringComparison.OrdinalIgnoreCase))
                return "%LOCALAPPDATA%" + path.Substring(local.Length);
            string roaming = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            if (!string.IsNullOrEmpty(roaming) && path.StartsWith(roaming, StringComparison.OrdinalIgnoreCase))
                return "%APPDATA%" + path.Substring(roaming.Length);
            return path;
        }

        private static void AddGdkProfiles(List<ContentProfile> list, string roaming, string userName, bool currentUser)
        {
            AddGdkVersion(list, Path.Combine(roaming, "Minecraft Bedrock"), false, userName, currentUser);
            AddGdkVersion(list, Path.Combine(roaming, "Minecraft Bedrock Preview"), true, userName, currentUser);
        }

        private static void AddGdkVersion(List<ContentProfile> list, string root, bool preview, string userName, bool currentUser)
        {
            string usersRoot = Path.Combine(root, "Users");
            if (!Directory.Exists(usersRoot)) return;
            string shared = Path.Combine(usersRoot, "Shared", "games", "com.mojang");
            string[] dirs;
            try { dirs = Directory.GetDirectories(usersRoot); }
            catch { return; }
            Array.Sort(dirs, StringComparer.OrdinalIgnoreCase);
            foreach (string dir in dirs)
            {
                string accountId = Path.GetFileName(dir);
                if (string.Equals(accountId, "Shared", StringComparison.OrdinalIgnoreCase)) continue;
                string dataDir = Path.Combine(dir, "games", "com.mojang");
                if (!Directory.Exists(dataDir)) continue;
                if (ContainsPath(list, dataDir)) continue;

                ContentProfile profile = new ContentProfile();
                profile.UserName = userName;
                profile.AccountId = accountId;
                profile.DataDir = dataDir;
                profile.SharedDir = shared;
                profile.RootDir = root;
                profile.IsPreview = preview;
                profile.IsCurrentUser = currentUser;
                profile.IsGDK = true;
                profile.Exists = true;
                string accountName = ReadAccountName(dataDir);
                if (string.IsNullOrEmpty(accountName)) accountName = "账号 " + ShortAccount(accountId);
                profile.DisplayName = accountName + " · " + (preview ? "预览版" : "正式版");
                if (!currentUser && !string.IsNullOrEmpty(userName)) profile.DisplayName += " · " + userName;
                list.Add(profile);
            }
        }

        private static void AddLegacyProfiles(List<ContentProfile> list, string localAppData, string userName, bool currentUser)
        {
            string packages = Path.Combine(localAppData, "Packages");
            if (!Directory.Exists(packages)) return;
            string[] dirs;
            try { dirs = Directory.GetDirectories(packages); }
            catch { return; }
            Array.Sort(dirs, StringComparer.OrdinalIgnoreCase);
            foreach (string dir in dirs)
            {
                string family = Path.GetFileName(dir);
                bool stable = string.Equals(family, GameLauncher.StableFamily, StringComparison.OrdinalIgnoreCase);
                bool preview = string.Equals(family, GameLauncher.PreviewFamily, StringComparison.OrdinalIgnoreCase);
                if (!stable && !preview) continue;
                string dataDir = Path.Combine(dir, "LocalState", "games", "com.mojang");
                if (ContainsPath(list, dataDir)) continue;
                if (!Directory.Exists(dataDir) && ContainsGdk(list)) continue;
                ContentProfile profile = new ContentProfile();
                profile.UserName = userName;
                profile.PackageFamily = family;
                profile.IsPreview = preview;
                profile.IsCurrentUser = currentUser;
                profile.IsGDK = false;
                profile.DataDir = dataDir;
                profile.SharedDir = dataDir;
                profile.RootDir = Path.GetDirectoryName(dir);
                profile.Exists = Directory.Exists(dataDir);
                profile.DisplayName = userName + " · " + (preview ? "预览版" : "正式版") + "（UWP）";
                list.Add(profile);
            }
        }

        private static string ReadAccountName(string dataDir)
        {
            try
            {
                string file = Path.Combine(dataDir, "minecraftpe", "options.txt");
                if (!File.Exists(file)) return string.Empty;
                foreach (string line in File.ReadAllLines(file, Encoding.UTF8))
                {
                    if (line.StartsWith("mp_username:", StringComparison.OrdinalIgnoreCase))
                        return line.Substring("mp_username:".Length).Trim();
                }
            }
            catch { }
            return string.Empty;
        }

        private static string ShortAccount(string accountId)
        {
            if (string.IsNullOrEmpty(accountId)) return "?";
            if (accountId.Length <= 6) return accountId;
            return accountId.Substring(accountId.Length - 6);
        }

        private static string PackageDataDir(string localAppData, string family)
        {
            if (string.IsNullOrEmpty(localAppData)) return string.Empty;
            return Path.Combine(localAppData, "Packages", family, "LocalState", "games", "com.mojang");
        }

        private static bool ContainsPath(List<ContentProfile> list, string path)
        {
            if (string.IsNullOrEmpty(path)) return false;
            foreach (ContentProfile profile in list)
            {
                if (string.Equals(profile.DataDir, path, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }

        private static bool ContainsGdk(List<ContentProfile> list)
        {
            foreach (ContentProfile profile in list)
                if (profile.IsGDK) return true;
            return false;
        }
    }

    internal static class ContentInstaller
    {
        private const long MaxExtractedBytes = 8L * 1024L * 1024L * 1024L;

        public static List<ContentInstallResult> Install(string file, ContentProfile profile,
            Func<List<ContentConflict>, bool> confirmOverwrite = null)
        {
            return Install(file, profile, confirmOverwrite, null, CancellationToken.None, null);
        }

        public static List<ContentInstallResult> Install(string file, ContentProfile profile,
            Func<List<ContentConflict>, bool> confirmOverwrite,
            Action<ImportProgress> progress, CancellationToken token,
            List<ContentItem> existingItems)
        {
            List<ContentInstallResult> results = new List<ContentInstallResult>();
            string staging = string.Empty;
            try
            {
                if (profile == null || string.IsNullOrEmpty(profile.DataDir))
                {
                    results.Add(Fail("没有选择目标目录"));
                    return results;
                }
                if (string.IsNullOrEmpty(file) || !File.Exists(file))
                {
                    results.Add(Fail("文件不存在：" + file));
                    return results;
                }

                token.ThrowIfCancellationRequested();
                EnsureWritable(profile);
                staging = Path.Combine(profile.DataDir, ".steve-import-" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(staging);
                Report(progress, file, "正在解压", 0, 0, true);
                ExtractZip(file, staging, progress, token, file);
                token.ThrowIfCancellationRequested();

                Report(progress, file, "正在展开子包", 0, 0, true);
                ExpandNestedArchives(staging, 0, progress, token, file);
                token.ThrowIfCancellationRequested();

                Report(progress, file, "正在检查冲突", 0, 0, true);
                string extension = Path.GetExtension(file).ToLowerInvariant();
                bool worldImport = extension == ".mcworld";
                List<PackManifest> manifests = new List<PackManifest>();
                if (!worldImport)
                {
                    manifests = ReadManifests(staging);
                    if (manifests.Count == 0 && FindWorldFolder(staging, 0) != null) worldImport = true;
                }
                bool templateImport = extension == ".mctemplate" || HasWorldTemplate(manifests);

                List<ContentConflict> conflicts = FindConflicts(profile, staging, file, manifests, worldImport, existingItems);
                if (conflicts.Count > 0)
                {
                    if (confirmOverwrite == null)
                    {
                        results.Add(Fail(Path.GetFileName(file) + "：已存在相同 UUID 或同名的资源"));
                        return results;
                    }
                    if (!confirmOverwrite(conflicts))
                    {
                        results.Add(Skip(Path.GetFileName(file) + "：已跳过，未覆盖现有资源"));
                        return results;
                    }
                    token.ThrowIfCancellationRequested();
                    string conflictError;
                    if (!RemoveConflicts(profile, conflicts, out conflictError))
                    {
                        results.Add(Fail("覆盖现有资源失败：" + conflictError));
                        return results;
                    }
                }

                token.ThrowIfCancellationRequested();
                if (worldImport)
                {
                    InstallWorld(staging, file, profile, results, progress, token);
                }
                else if (templateImport)
                {
                    InstallTemplate(staging, file, profile, results, progress, token);
                }
                else if (manifests.Count > 0)
                {
                    InstallPacks(manifests, file, profile, results, progress, token);
                }
                else
                {
                    results.Add(Fail(Path.GetFileName(file) + "：压缩包中既没有 manifest.json 也没有 level.dat，无法识别"));
                }
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (UnauthorizedAccessException ex)
            {
                results.Add(Fail("没有写入权限：" + ex.Message));
            }
            catch (InvalidDataException ex)
            {
                results.Add(Fail("压缩包无效：" + ex.Message));
            }
            catch (IOException ex)
            {
                results.Add(Fail("文件操作失败：" + ex.Message));
            }
            catch (Exception ex)
            {
                results.Add(Fail("安装失败：" + ex.Message));
            }
            finally
            {
                if (!string.IsNullOrEmpty(staging)) TryDeleteDirectory(staging);
            }
            if (results.Count == 0) results.Add(Fail(Path.GetFileName(file) + "：没有安装任何内容"));
            return results;
        }

        private static void Report(Action<ImportProgress> progress, string file, string phase,
            long completed, long total, bool indeterminate)
        {
            if (progress == null) return;
            ImportProgress info = new ImportProgress();
            info.FileName = Path.GetFileName(file);
            info.Phase = phase;
            info.CompletedBytes = completed;
            info.TotalBytes = total;
            info.Indeterminate = indeterminate;
            progress(info);
        }

        public static List<ContentItem> Scan(ContentProfile profile)
        {
            List<ContentItem> items = new List<ContentItem>();
            if (profile == null || string.IsNullOrEmpty(profile.DataDir)) return items;
            string packRoot = PackRoot(profile);
            AddPacks(items, Path.Combine(packRoot, "resource_packs"), ContentKind.TexturePack);
            AddPacks(items, Path.Combine(packRoot, "behavior_packs"), ContentKind.Mod);
            AddWorlds(items, Path.Combine(profile.DataDir, "minecraftWorlds"));
            AddTemplates(items, profile);
            items.Sort(delegate(ContentItem a, ContentItem b)
            {
                int kind = a.Kind.CompareTo(b.Kind);
                if (kind != 0) return kind;
                return string.Compare(a.Name, b.Name, StringComparison.CurrentCultureIgnoreCase);
            });
            return items;
        }

        public static bool Remove(ContentItem item, ContentProfile profile, out string message)
        {
            message = string.Empty;
            try
            {
                if (item == null || string.IsNullOrEmpty(item.FolderPath) ||
                    (!Directory.Exists(item.FolderPath) && !File.Exists(item.FolderPath)))
                {
                    message = "文件已经不存在";
                    return false;
                }
                if (profile == null || string.IsNullOrEmpty(profile.DataDir))
                {
                    message = "没有选择目标目录";
                    return false;
                }
                string root = Path.GetFullPath(profile.DataDir).TrimEnd('\\');
                string full = Path.GetFullPath(item.FolderPath).TrimEnd('\\');
                string packRoot = Path.GetFullPath(PackRoot(profile)).TrimEnd('\\');
                bool insideData = full.StartsWith(root + "\\", StringComparison.OrdinalIgnoreCase);
                bool insideShared = full.StartsWith(packRoot + "\\", StringComparison.OrdinalIgnoreCase);
                if (!insideData && !insideShared)
                {
                    message = "该目录不在当前资源目录中";
                    return false;
                }
                string trash = MoveToTrash(profile, full);
                message = "已移动到 " + trash;
                return true;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return false;
            }
        }

        private static void InstallPacks(List<PackManifest> manifests, string sourceFile, ContentProfile profile,
            List<ContentInstallResult> results, Action<ImportProgress> progress, CancellationToken token)
        {
            string fallback = Path.GetFileNameWithoutExtension(sourceFile);
            foreach (PackManifest manifest in manifests)
            {
                token.ThrowIfCancellationRequested();
                if (!string.IsNullOrEmpty(manifest.Error))
                {
                    results.Add(Fail(manifest.Error));
                    continue;
                }
                if (!manifest.HasResources && !manifest.HasBehavior)
                {
                    results.Add(Fail("不支持的包类型（既不是资源包也不是行为包）：" + manifest.Name));
                    continue;
                }
                if (manifest.HasResources)
                    InstallPackFolder(manifest, "resource_packs", ContentKind.TexturePack, fallback, profile, results, progress, token, sourceFile);
                if (manifest.HasBehavior)
                    InstallPackFolder(manifest, "behavior_packs", ContentKind.Mod, fallback, profile, results, progress, token, sourceFile);
            }
        }

        private static void InstallPackFolder(PackManifest manifest, string targetDirName, ContentKind kind,
            string fallbackName, ContentProfile profile, List<ContentInstallResult> results,
            Action<ImportProgress> progress, CancellationToken token, string sourceFile)
        {
            token.ThrowIfCancellationRequested();
            string targetRoot = Path.Combine(PackRoot(profile), targetDirName);
            Directory.CreateDirectory(targetRoot);
            string folderName = BuildPackFolderName(manifest, fallbackName);
            string dest = Path.Combine(targetRoot, folderName);
            if (Directory.Exists(dest))
            {
                int index = 2;
                while (Directory.Exists(dest))
                {
                    dest = Path.Combine(targetRoot, folderName + " (" + index + ")");
                    index++;
                }
            }
            try
            {
                CopyDirectory(manifest.Folder, dest, progress, token, sourceFile, "正在安装" + KindLabel(kind));
            }
            catch
            {
                TryDeleteDirectory(dest);
                throw;
            }
            results.Add(Success(kind, "已安装" + KindLabel(kind) + "「" + DisplayName(manifest, fallbackName) + "」", dest));        }

        private static void InstallWorld(string staging, string sourceFile, ContentProfile profile,
            List<ContentInstallResult> results, Action<ImportProgress> progress, CancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            string worldFolder = FindWorldFolder(staging, 0);
            if (worldFolder == null)
            {
                results.Add(Fail(Path.GetFileName(sourceFile) + "：没有找到 level.dat，可能不是有效的世界文件"));
                return;
            }
            string name = ReadWorldName(worldFolder);
            if (string.IsNullOrWhiteSpace(name)) name = Path.GetFileNameWithoutExtension(sourceFile);
            name = SanitizeName(name, "世界");
            string targetRoot = Path.Combine(profile.DataDir, "minecraftWorlds");
            Directory.CreateDirectory(targetRoot);
            string dest = Path.Combine(targetRoot, name);
            int index = 2;
            while (Directory.Exists(dest))
            {
                dest = Path.Combine(targetRoot, name + " (" + index + ")");
                index++;
            }
            try
            {
                MoveOrCopyDirectory(worldFolder, dest, progress, token, sourceFile, "正在安装世界");
            }
            catch
            {
                TryDeleteDirectory(dest);
                throw;
            }
            results.Add(Success(ContentKind.World, "已安装世界「" + name + "」", dest));
        }

        private static void InstallTemplate(string staging, string sourceFile, ContentProfile profile,
            List<ContentInstallResult> results, Action<ImportProgress> progress, CancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            List<PackManifest> manifests = ReadManifests(staging);
            PackManifest template = null;
            foreach (PackManifest manifest in manifests)
            {
                if (manifest.HasWorldTemplate)
                {
                    template = manifest;
                    break;
                }
            }
            if (template == null)
            {
                results.Add(Fail(Path.GetFileName(sourceFile) + "：不是有效的世界模板（manifest.json 缺少 world_template 模块）"));
                return;
            }
            if (!string.IsNullOrEmpty(template.Error))
            {
                results.Add(Fail(template.Error));
                return;
            }
            if (FindWorldFolder(template.Folder, 0) == null)
            {
                results.Add(Fail(Path.GetFileName(sourceFile) + "：模板中没有找到 level.dat"));
                return;
            }

            string fallback = Path.GetFileNameWithoutExtension(sourceFile);
            string name = IsPlaceholderName(template.Name) ? fallback : template.Name;
            name = SanitizeName(name, "模板");
            string targetRoot = TemplateRoot(profile);
            Directory.CreateDirectory(targetRoot);
            string dest = Path.Combine(targetRoot, name);
            if (Directory.Exists(dest))
            {
                int index = 2;
                while (Directory.Exists(dest))
                {
                    dest = Path.Combine(targetRoot, name + " (" + index + ")");
                    index++;
                }
            }

            try
            {
                MoveOrCopyDirectory(template.Folder, dest, progress, token, sourceFile, "正在安装模板");
            }
            catch
            {
                TryDeleteDirectory(dest);
                throw;
            }
            results.Add(Success(ContentKind.Template, "已安装模板「" + name + "」", dest));
        }

        private static bool HasWorldTemplate(List<PackManifest> manifests)
        {
            foreach (PackManifest manifest in manifests)
                if (manifest.HasWorldTemplate) return true;
            return false;
        }

        /// <summary>
        /// Some .mcaddon packages do not contain unpacked pack folders; instead
        /// they contain nested .mcpack files (behaviors.mcpack / resources.mcpack).
        /// Extract those recursively so the normal manifest scan can see them.
        /// </summary>
        private static void ExpandNestedArchives(string root, int depth,
            Action<ImportProgress> progress, CancellationToken token, string sourceFile)
        {
            if (depth > 5) return;
            token.ThrowIfCancellationRequested();
            string[] files;
            try { files = Directory.GetFiles(root, "*.*", SearchOption.AllDirectories); }
            catch { return; }

            List<string> archives = new List<string>();
            foreach (string file in files)
            {
                string extension = Path.GetExtension(file).ToLowerInvariant();
                if (extension == ".mcpack" || extension == ".mcaddon") archives.Add(file);
            }
            if (archives.Count == 0) return;

            string tempRoot = Path.Combine(Path.GetTempPath(), "steve-nested-" + Guid.NewGuid().ToString("N"));
            try
            {
                Directory.CreateDirectory(tempRoot);
                foreach (string archive in archives)
                {
                    token.ThrowIfCancellationRequested();
                    string temp = Path.Combine(tempRoot, Guid.NewGuid().ToString("N"));
                    try
                    {
                        ExtractZip(archive, temp, progress, token, sourceFile);
                        string baseName = SanitizeName(Path.GetFileNameWithoutExtension(archive), "pack");
                        string dest = UniqueDirectory(root, baseName);
                        Directory.CreateDirectory(dest);
                        CopyDirectory(temp, dest, progress, token, sourceFile, "正在展开子包");
                        File.Delete(archive);
                    }
                    catch (OperationCanceledException)
                    {
                        throw;
                    }
                    catch
                    {
                        TryDeleteDirectory(temp);
                    }
                }
            }
            finally
            {
                TryDeleteDirectory(tempRoot);
            }
            ExpandNestedArchives(root, depth + 1, progress, token, sourceFile);
        }

        private static string UniqueDirectory(string parent, string name)
        {
            string dest = Path.Combine(parent, name);
            int index = 2;
            while (Directory.Exists(dest) || File.Exists(dest))
            {
                dest = Path.Combine(parent, name + " (" + index + ")");
                index++;
            }
            return dest;
        }

        private static List<ContentConflict> FindConflicts(ContentProfile profile, string staging, string sourceFile,
            List<PackManifest> manifests, bool worldImport, List<ContentItem> existingItems)
        {
            List<ContentConflict> conflicts = new List<ContentConflict>();
            List<ContentItem> existing = existingItems != null ? existingItems : Scan(profile);

            if (worldImport)
            {
                string name = IncomingWorldName(staging, sourceFile);
                if (string.IsNullOrEmpty(name)) return conflicts;
                string folderName = SanitizeName(name, "世界");
                foreach (ContentItem item in existing)
                {
                    if (item.Kind != ContentKind.World) continue;
                    bool sameDisplay = string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase);
                    bool sameFolder = string.Equals(Path.GetFileName(item.FolderPath), folderName, StringComparison.OrdinalIgnoreCase);
                    if (!sameDisplay && !sameFolder) continue;
                    if (HasConflictPath(conflicts, item.FolderPath)) continue;
                    conflicts.Add(NewConflict(ContentKind.World, name, string.Empty, item.FolderPath));
                }
                return conflicts;
            }

            string fallback = Path.GetFileNameWithoutExtension(sourceFile);
            foreach (PackManifest manifest in manifests)
            {
                if (!string.IsNullOrEmpty(manifest.Error)) continue;
                string name = DisplayName(manifest, fallback);
                if (manifest.HasResources)
                    AddUuidConflict(conflicts, existing, ContentKind.TexturePack, name, manifest.Uuid);
                if (manifest.HasBehavior)
                    AddUuidConflict(conflicts, existing, ContentKind.Mod, name, manifest.Uuid);
                if (manifest.HasWorldTemplate)
                    AddUuidConflict(conflicts, existing, ContentKind.Template, name, manifest.Uuid);
            }
            return conflicts;
        }

        private static void AddUuidConflict(List<ContentConflict> conflicts, List<ContentItem> existing,
            ContentKind kind, string name, string uuid)
        {
            if (string.IsNullOrEmpty(uuid)) return;
            foreach (ContentItem item in existing)
            {
                if (item.Kind != kind || string.IsNullOrEmpty(item.Uuid)) continue;
                if (!string.Equals(item.Uuid, uuid, StringComparison.OrdinalIgnoreCase)) continue;
                if (HasConflictPath(conflicts, item.FolderPath)) continue;
                conflicts.Add(NewConflict(kind, name, uuid, item.FolderPath));
            }
        }

        private static ContentConflict NewConflict(ContentKind kind, string name, string uuid, string existingPath)
        {
            ContentConflict conflict = new ContentConflict();
            conflict.Kind = kind;
            conflict.Name = name ?? string.Empty;
            conflict.Uuid = uuid ?? string.Empty;
            conflict.ExistingPath = existingPath ?? string.Empty;
            return conflict;
        }

        private static bool HasConflictPath(List<ContentConflict> conflicts, string path)
        {
            if (string.IsNullOrEmpty(path)) return false;
            foreach (ContentConflict conflict in conflicts)
                if (string.Equals(conflict.ExistingPath, path, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        private static string IncomingWorldName(string staging, string sourceFile)
        {
            string folder = FindWorldFolder(staging, 0);
            string name = folder != null ? ReadWorldName(folder) : string.Empty;
            if (string.IsNullOrWhiteSpace(name)) name = Path.GetFileNameWithoutExtension(sourceFile);
            return StripFormatting(name).Trim();
        }

        private static bool RemoveConflicts(ContentProfile profile, List<ContentConflict> conflicts, out string error)
        {
            error = string.Empty;
            List<string> moved = new List<string>();
            foreach (ContentConflict conflict in conflicts)
            {
                string path = conflict.ExistingPath;
                if (string.IsNullOrEmpty(path)) continue;
                bool already = false;
                foreach (string previous in moved)
                    if (string.Equals(previous, path, StringComparison.OrdinalIgnoreCase)) { already = true; break; }
                if (already) continue;
                try
                {
                    if (Directory.Exists(path) || File.Exists(path)) MoveToTrash(profile, path);
                    moved.Add(path);
                }
                catch (Exception ex)
                {
                    error = path + "：" + ex.Message;
                    return false;
                }
            }
            return true;
        }

        private static List<PackManifest> ReadManifests(string root)
        {
            List<PackManifest> manifests = new List<PackManifest>();
            foreach (string path in EnumerateManifests(root, 0))
            {
                PackManifest manifest = ReadManifest(path);
                if (manifest != null) manifests.Add(manifest);
            }
            return manifests;
        }

        private static IEnumerable<string> EnumerateManifests(string dir, int depth)
        {
            string[] files;
            try { files = Directory.GetFiles(dir, "manifest.json", SearchOption.TopDirectoryOnly); }
            catch { yield break; }
            foreach (string file in files) yield return file;
            if (depth >= 2) yield break;
            string[] subs;
            try { subs = Directory.GetDirectories(dir); }
            catch { yield break; }
            foreach (string sub in subs)
            {
                string name = Path.GetFileName(sub);
                if (name.StartsWith("__MACOSX", StringComparison.OrdinalIgnoreCase)) continue;
                foreach (string file in EnumerateManifests(sub, depth + 1)) yield return file;
            }
        }

        private static PackManifest ReadManifest(string path)
        {
            PackManifest manifest = new PackManifest();
            manifest.Folder = Path.GetDirectoryName(path);
            try
            {
                string text = File.ReadAllText(path, Encoding.UTF8);
                Dictionary<string, object> root = JsonLite.AsObject(JsonLite.Parse(text));
                if (root == null) throw new FormatException("根节点不是对象");
                Dictionary<string, object> header = JsonLite.AsObject(JsonLite.Get(root, "header"));
                if (header == null) header = root;
                manifest.Name = JsonLite.GetString(header, "name");
                manifest.Version = FormatVersion(JsonLite.Get(header, "version"));
                manifest.Uuid = JsonLite.GetString(header, "uuid");
                if (!string.IsNullOrEmpty(manifest.Name))
                {
                    manifest.Name = StripFormatting(manifest.Name).Trim();
                    if (LooksLikeLocalizationKey(manifest.Name))
                    {
                        string localized = ResolveLocalizedName(manifest.Folder, manifest.Name);
                        if (!string.IsNullOrEmpty(localized)) manifest.Name = localized;
                    }
                }

                List<object> modules = JsonLite.AsArray(JsonLite.Get(root, "modules"));
                if (modules != null)
                {
                    foreach (object node in modules)
                    {
                        Dictionary<string, object> module = JsonLite.AsObject(node);
                        if (module == null) continue;
                        string type = JsonLite.GetString(module, "type");
                        if (type == null) continue;
                        type = type.Trim().ToLowerInvariant();
                        if (type.StartsWith("resources", StringComparison.Ordinal)) manifest.HasResources = true;
                        else if (type == "data" || type == "script" || type == "javascript") manifest.HasBehavior = true;
                        else if (type == "world_template") manifest.HasWorldTemplate = true;
                    }
                }
            }
            catch (Exception ex)
            {
                manifest.Error = "manifest.json 解析失败（" + Path.GetFileName(manifest.Folder) + "）：" + ex.Message;
            }
            return manifest;
        }

        private static bool LooksLikeLocalizationKey(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;
            if (name.IndexOf(' ') >= 0) return false;
            return name.IndexOf('.') > 0;
        }

        private static string ResolveLocalizedName(string folder, string key)
        {
            try
            {
                string texts = Path.Combine(folder, "texts");
                if (!Directory.Exists(texts)) return string.Empty;
                string value = ReadLangValue(Path.Combine(texts, "zh_CN.lang"), key);
                if (!string.IsNullOrEmpty(value)) return value;
                value = ReadLangValue(Path.Combine(texts, "en_US.lang"), key);
                if (!string.IsNullOrEmpty(value)) return value;
                string[] files;
                try { files = Directory.GetFiles(texts, "*.lang"); }
                catch { files = new string[0]; }
                Array.Sort(files, StringComparer.OrdinalIgnoreCase);
                foreach (string file in files)
                {
                    value = ReadLangValue(file, key);
                    if (!string.IsNullOrEmpty(value)) return value;
                }
            }
            catch { }
            return string.Empty;
        }

        private static string ReadLangValue(string file, string key)
        {
            try
            {
                if (!File.Exists(file)) return string.Empty;
                return ParseLangValue(File.ReadAllText(file, Encoding.UTF8), key);
            }
            catch { }
            return string.Empty;
        }

        private static string ParseLangValue(string text, string key)
        {
            if (string.IsNullOrEmpty(text)) return string.Empty;
            string[] lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            foreach (string raw in lines)
            {
                string line = raw.Trim();
                if (line.Length == 0) continue;
                if (line.StartsWith("#", StringComparison.Ordinal) || line.StartsWith("//", StringComparison.Ordinal)) continue;
                int equals = line.IndexOf('=');
                if (equals <= 0) continue;
                if (!string.Equals(line.Substring(0, equals).Trim(), key, StringComparison.OrdinalIgnoreCase)) continue;
                string value = line.Substring(equals + 1).Trim();
                return StripFormatting(value).Trim();
            }
            return string.Empty;
        }

        private static string FindPackIcon(string folder)
        {
            return FindAsset(folder, "pack_icon", new string[] { ".png", ".jpg", ".jpeg" });
        }

        private static string FindWorldIcon(string folder)
        {
            string path = FindAsset(folder, "world_icon", new string[] { ".jpeg", ".jpg", ".png" });
            if (string.IsNullOrEmpty(path))
                path = FindAsset(folder, "screenshot_icon_0", new string[] { ".jpeg", ".jpg", ".png" });
            return path;
        }

        private static string FindAsset(string folder, string baseName, string[] extensions)
        {
            foreach (string extension in extensions)
            {
                string path = Path.Combine(folder, baseName + extension);
                if (File.Exists(path)) return path;
            }
            try
            {
                foreach (string file in Directory.GetFiles(folder, baseName + ".*"))
                {
                    string extension = Path.GetExtension(file).ToLowerInvariant();
                    if (Array.IndexOf(extensions, extension) >= 0) return file;
                }
            }
            catch { }
            return string.Empty;
        }

        private static string FindWorldFolder(string dir, int depth)
        {
            try
            {
                if (File.Exists(Path.Combine(dir, "level.dat"))) return dir;
                if (depth >= 2) return null;
                foreach (string sub in Directory.GetDirectories(dir))
                {
                    string name = Path.GetFileName(sub);
                    if (name.StartsWith("__MACOSX", StringComparison.OrdinalIgnoreCase)) continue;
                    string found = FindWorldFolder(sub, depth + 1);
                    if (found != null) return found;
                }
            }
            catch { }
            return null;
        }

        private static string ReadWorldName(string folder)
        {
            try
            {
                string file = Path.Combine(folder, "levelname.txt");
                if (!File.Exists(file)) return string.Empty;
                string value = File.ReadAllText(file, Encoding.UTF8).Trim();
                value = StripFormatting(value).Trim();
                if (value.Length > 0) return value;
            }
            catch { }
            return string.Empty;
        }

        private static void AddPacks(List<ContentItem> items, string root, ContentKind kind)
        {
            if (!Directory.Exists(root)) return;
            string[] dirs;
            try { dirs = Directory.GetDirectories(root); }
            catch { return; }
            foreach (string dir in dirs)
            {
                string manifestPath = Path.Combine(dir, "manifest.json");
                if (!File.Exists(manifestPath)) continue;
                PackManifest manifest = ReadManifest(manifestPath);
                ContentItem item = new ContentItem();
                item.Kind = kind;
                item.Name = IsPlaceholderName(manifest.Name) ? Path.GetFileName(dir) : manifest.Name;
                item.Version = manifest.Version;
                item.Uuid = manifest.Uuid;
                item.FolderPath = dir;
                item.IconPath = FindPackIcon(dir);
                try { item.Modified = Directory.GetLastWriteTime(dir); }
                catch { item.Modified = DateTime.MinValue; }
                items.Add(item);
            }
        }

        private static void AddWorlds(List<ContentItem> items, string root)
        {
            if (!Directory.Exists(root)) return;
            string[] dirs;
            try { dirs = Directory.GetDirectories(root); }
            catch { return; }
            foreach (string dir in dirs)
            {
                if (!File.Exists(Path.Combine(dir, "level.dat"))) continue;
                string name = ReadWorldName(dir);
                ContentItem item = new ContentItem();
                item.Kind = ContentKind.World;
                item.Name = string.IsNullOrEmpty(name) ? Path.GetFileName(dir) : name;
                item.FolderPath = dir;
                item.IconPath = FindWorldIcon(dir);
                try { item.Modified = Directory.GetLastWriteTime(dir); }
                catch { item.Modified = DateTime.MinValue; }
                items.Add(item);
            }
        }

        private static void AddTemplates(List<ContentItem> items, ContentProfile profile)
        {
            foreach (string root in TemplateRoots(profile))
            {
                if (!Directory.Exists(root)) continue;
                string[] dirs;
                try { dirs = Directory.GetDirectories(root); }
                catch { dirs = new string[0]; }
                foreach (string dir in dirs)
                {
                    string manifestPath = Path.Combine(dir, "manifest.json");
                    if (!File.Exists(manifestPath)) continue;
                    PackManifest manifest = ReadManifest(manifestPath);
                    if (!manifest.HasWorldTemplate) continue;
                    ContentItem item = new ContentItem();
                    item.Kind = ContentKind.Template;
                    item.Name = IsPlaceholderName(manifest.Name) ? Path.GetFileName(dir) : manifest.Name;
                    item.Version = manifest.Version;
                    item.Uuid = manifest.Uuid;
                    item.FolderPath = dir;
                    item.IconPath = FindWorldIcon(dir);
                    try { item.Modified = Directory.GetLastWriteTime(dir); }
                    catch { item.Modified = DateTime.MinValue; }
                    items.Add(item);
                }

                string[] files;
                try { files = Directory.GetFiles(root, "*.mctemplate"); }
                catch { files = new string[0]; }
                foreach (string file in files) items.Add(ReadTemplateFile(file));
            }
        }

        private static ContentItem ReadTemplateFile(string file)
        {
            ContentItem item = new ContentItem();
            item.Kind = ContentKind.Template;
            item.FolderPath = file;
            item.Name = Path.GetFileNameWithoutExtension(file);
            try { item.Modified = File.GetLastWriteTime(file); }
            catch { item.Modified = DateTime.MinValue; }

            bool named = false;
            try
            {
                using (ZipArchive archive = ZipFile.OpenRead(file))
                {
                    ZipArchiveEntry manifestEntry = FindArchiveEntry(archive, "manifest.json");
                    if (manifestEntry != null)
                    {
                        Dictionary<string, object> root = JsonLite.AsObject(JsonLite.Parse(ReadArchiveText(manifestEntry)));
                        if (root != null)
                        {
                            Dictionary<string, object> header = JsonLite.AsObject(JsonLite.Get(root, "header"));
                            if (header == null) header = root;
                            string name = JsonLite.GetString(header, "name");
                            item.Version = FormatVersion(JsonLite.Get(header, "version"));
                            item.Uuid = JsonLite.GetString(header, "uuid");
                            if (!string.IsNullOrEmpty(name))
                            {
                                name = StripFormatting(name).Trim();
                                if (LooksLikeLocalizationKey(name))
                                {
                                    string localized = ResolveArchiveLangName(archive, name);
                                    if (!string.IsNullOrEmpty(localized)) name = localized;
                                }
                                if (!IsPlaceholderName(name))
                                {
                                    item.Name = name;
                                    named = true;
                                }
                            }
                        }
                    }
                    if (!named)
                    {
                        string levelName = ReadArchiveText(FindArchiveEntry(archive, "levelname.txt"));
                        if (!string.IsNullOrWhiteSpace(levelName))
                        {
                            item.Name = StripFormatting(levelName).Trim();
                            named = true;
                        }
                    }
                    ZipArchiveEntry icon = FindArchiveEntry(archive, "world_icon.jpeg");
                    if (icon == null) icon = FindArchiveEntry(archive, "world_icon.jpg");
                    if (icon == null) icon = FindArchiveEntry(archive, "world_icon.png");
                    if (icon == null) icon = FindArchiveEntry(archive, "screenshot_icon_0.jpeg");
                    if (icon == null) icon = FindArchiveEntry(archive, "screenshot_icon_0.png");
                    if (icon != null)
                    {
                        item.ArchivePath = file;
                        item.ArchiveIconEntry = icon.FullName;
                    }
                }
            }
            catch { }
            return item;
        }

        private static string ResolveArchiveLangName(ZipArchive archive, string key)
        {
            string value = ReadArchiveLang(archive, "texts/zh_CN.lang", key);
            if (!string.IsNullOrEmpty(value)) return value;
            value = ReadArchiveLang(archive, "texts/en_US.lang", key);
            if (!string.IsNullOrEmpty(value)) return value;
            foreach (ZipArchiveEntry entry in archive.Entries)
            {
                if (!entry.FullName.StartsWith("texts/", StringComparison.OrdinalIgnoreCase)) continue;
                if (!entry.Name.EndsWith(".lang", StringComparison.OrdinalIgnoreCase)) continue;
                value = ParseLangValue(ReadArchiveText(entry), key);
                if (!string.IsNullOrEmpty(value)) return value;
            }
            return string.Empty;
        }

        private static string ReadArchiveLang(ZipArchive archive, string path, string key)
        {
            foreach (ZipArchiveEntry entry in archive.Entries)
            {
                if (!string.Equals(entry.FullName, path, StringComparison.OrdinalIgnoreCase)) continue;
                return ParseLangValue(ReadArchiveText(entry), key);
            }
            return string.Empty;
        }

        private static string ReadArchiveText(ZipArchiveEntry entry)
        {
            if (entry == null) return string.Empty;
            try
            {
                using (Stream stream = entry.Open())
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8, true))
                    return reader.ReadToEnd();
            }
            catch { return string.Empty; }
        }

        private static ZipArchiveEntry FindArchiveEntry(ZipArchive archive, string fileName)
        {
            if (archive == null || string.IsNullOrEmpty(fileName)) return null;
            ZipArchiveEntry fallback = null;
            foreach (ZipArchiveEntry entry in archive.Entries)
            {
                if (!string.Equals(entry.Name, fileName, StringComparison.OrdinalIgnoreCase)) continue;
                if (string.Equals(entry.FullName, fileName, StringComparison.OrdinalIgnoreCase)) return entry;
                if (fallback == null) fallback = entry;
            }
            return fallback;
        }

        private static string PackRoot(ContentProfile profile)
        {
            if (profile == null) return string.Empty;
            if (!string.IsNullOrEmpty(profile.SharedDir)) return profile.SharedDir;
            return profile.DataDir;
        }

        private static string TemplateRoot(ContentProfile profile)
        {
            if (profile == null) return string.Empty;
            if (profile.IsGDK && !string.IsNullOrEmpty(profile.SharedDir))
                return Path.Combine(profile.SharedDir, "world_templates");
            if (!string.IsNullOrEmpty(profile.DataDir))
                return Path.Combine(profile.DataDir, "world_templates");
            return string.Empty;
        }

        private static List<string> TemplateRoots(ContentProfile profile)
        {
            List<string> roots = new List<string>();
            if (profile == null) return roots;
            if (profile.IsGDK && !string.IsNullOrEmpty(profile.SharedDir))
                AddDistinctPath(roots, Path.Combine(profile.SharedDir, "world_templates"));
            if (!string.IsNullOrEmpty(profile.DataDir))
                AddDistinctPath(roots, Path.Combine(profile.DataDir, "world_templates"));
            return roots;
        }

        private static void AddDistinctPath(List<string> list, string path)
        {
            if (string.IsNullOrEmpty(path)) return;
            foreach (string existing in list)
                if (string.Equals(existing, path, StringComparison.OrdinalIgnoreCase)) return;
            list.Add(path);
        }

        private static void EnsureWritable(ContentProfile profile)
        {
            if (string.IsNullOrEmpty(profile.DataDir)) throw new IOException("目标目录为空");
            string packRoot = PackRoot(profile);
            Directory.CreateDirectory(profile.DataDir);
            Directory.CreateDirectory(Path.Combine(profile.DataDir, "minecraftWorlds"));
            Directory.CreateDirectory(packRoot);
            Directory.CreateDirectory(Path.Combine(packRoot, "resource_packs"));
            Directory.CreateDirectory(Path.Combine(packRoot, "behavior_packs"));
            string templateRoot = TemplateRoot(profile);
            if (!string.IsNullOrEmpty(templateRoot)) Directory.CreateDirectory(templateRoot);
            string probe = Path.Combine(profile.DataDir, ".steve-write-" + Guid.NewGuid().ToString("N") + ".tmp");
            File.WriteAllText(probe, "ok", new UTF8Encoding(false));
            File.Delete(probe);
            profile.Exists = true;
        }

        private static void ExtractZip(string zipPath, string destination,
            Action<ImportProgress> progress, CancellationToken token, string sourceFile)
        {
            string root = Path.GetFullPath(destination);
            if (!root.EndsWith("\\", StringComparison.Ordinal)) root += "\\";
            long total = 0;
            long done = 0;
            using (ZipArchive archive = ZipFile.OpenRead(zipPath))
            {
                foreach (ZipArchiveEntry entry in archive.Entries)
                    if (!IsDirectoryEntry(entry)) total += entry.Length;
                Report(progress, sourceFile, "正在解压", 0, total, false);
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    token.ThrowIfCancellationRequested();
                    string relative = entry.FullName.Replace('/', '\\');
                    if (relative.StartsWith("__MACOSX\\", StringComparison.OrdinalIgnoreCase)) continue;
                    string full = Path.GetFullPath(Path.Combine(root, relative));
                    if (!full.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                        throw new InvalidDataException("压缩包包含非法路径：" + entry.FullName);
                    if (IsDirectoryEntry(entry))
                    {
                        Directory.CreateDirectory(full);
                        continue;
                    }
                    if (done + entry.Length > MaxExtractedBytes) throw new InvalidDataException("解压后体积过大");
                    string dir = Path.GetDirectoryName(full);
                    if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
                    entry.ExtractToFile(full, true);
                    done += entry.Length;
                    Report(progress, sourceFile, "正在解压", done, total, false);
                }
            }
        }

        private static bool IsDirectoryEntry(ZipArchiveEntry entry)
        {
            return entry.FullName.EndsWith("/", StringComparison.Ordinal) ||
                   entry.FullName.EndsWith("\\", StringComparison.Ordinal) ||
                   entry.Name.Length == 0;
        }

        private static void CopyDirectory(string source, string destination,
            Action<ImportProgress> progress, CancellationToken token, string sourceFile, string phase)
        {
            token.ThrowIfCancellationRequested();
            Directory.CreateDirectory(destination);
            string sourceFull = Path.GetFullPath(source).TrimEnd('\\');
            string[] dirs = Directory.GetDirectories(sourceFull, "*", SearchOption.AllDirectories);
            foreach (string dir in dirs)
            {
                token.ThrowIfCancellationRequested();
                string relative = dir.Substring(sourceFull.Length).TrimStart('\\');
                Directory.CreateDirectory(Path.Combine(destination, relative));
            }
            string[] files = Directory.GetFiles(sourceFull, "*", SearchOption.AllDirectories);
            long total = 0;
            foreach (string file in files)
            {
                try { total += new FileInfo(file).Length; }
                catch { }
            }
            Report(progress, sourceFile, phase, 0, total, false);
            long done = 0;
            foreach (string file in files)
            {
                token.ThrowIfCancellationRequested();
                string relative = file.Substring(sourceFull.Length).TrimStart('\\');
                string target = Path.Combine(destination, relative);
                string dir = Path.GetDirectoryName(target);
                if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
                File.Copy(file, target, true);
                try { done += new FileInfo(file).Length; }
                catch { }
                Report(progress, sourceFile, phase, done, total, false);
            }
        }

        private static void MoveOrCopyDirectory(string source, string destination,
            Action<ImportProgress> progress, CancellationToken token, string sourceFile, string phase)
        {
            token.ThrowIfCancellationRequested();
            try
            {
                Directory.Move(source, destination);
                Report(progress, sourceFile, phase, 0, 0, true);
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch
            {
                CopyDirectory(source, destination, progress, token, sourceFile, phase);
            }
        }

        private static string MoveToTrash(ContentProfile profile, string path)
        {
            string root = profile.DataDir;
            string packRoot = PackRoot(profile);
            if (!string.IsNullOrEmpty(packRoot) &&
                path.StartsWith(packRoot.TrimEnd('\\') + "\\", StringComparison.OrdinalIgnoreCase))
                root = packRoot;
            string trashRoot = Path.Combine(root, ".steve-client-trash", DateTime.Now.ToString("yyyyMMdd-HHmmss"));
            Directory.CreateDirectory(trashRoot);
            string name = Path.GetFileName(path.TrimEnd('\\'));
            string dest = Path.Combine(trashRoot, name);
            int index = 2;
            while (Directory.Exists(dest) || File.Exists(dest))
            {
                dest = Path.Combine(trashRoot, name + " (" + index + ")");
                index++;
            }
            if (File.Exists(path)) File.Move(path, dest);
            else Directory.Move(path, dest);
            return dest;
        }

        private static string BuildPackFolderName(PackManifest manifest, string fallback)
        {
            string name = IsPlaceholderName(manifest.Name) ? fallback : manifest.Name;
            name = SanitizeName(name, fallback);
            if (!string.IsNullOrEmpty(manifest.Version)) name = name + " " + manifest.Version;
            if (name.Length > 80) name = name.Substring(0, 80).Trim();
            return name;
        }

        private static string DisplayName(PackManifest manifest, string fallback)
        {
            if (!IsPlaceholderName(manifest.Name)) return manifest.Name;
            return fallback;
        }

        private static bool IsPlaceholderName(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return true;
            return string.Equals(name, "pack.name", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(name, "pack.description", StringComparison.OrdinalIgnoreCase);
        }

        private static string SanitizeName(string name, string fallback)
        {
            if (string.IsNullOrWhiteSpace(name)) name = fallback;
            if (string.IsNullOrWhiteSpace(name)) name = "content";
            name = StripFormatting(name).Trim();
            char[] invalid = Path.GetInvalidFileNameChars();
            StringBuilder sb = new StringBuilder();
            foreach (char c in name)
            {
                if (c == '\\' || c == '/' || Array.IndexOf(invalid, c) >= 0 || char.IsControl(c)) sb.Append('_');
                else sb.Append(c);
            }
            string result = sb.ToString().Trim().TrimEnd('.');
            if (result.Length > 64) result = result.Substring(0, 64).Trim();
            if (result.Length == 0) result = "content";
            return result;
        }

        private static string FormatVersion(object value)
        {
            List<object> parts = value as List<object>;
            if (parts != null)
            {
                StringBuilder sb = new StringBuilder();
                foreach (object part in parts)
                {
                    if (sb.Length > 0) sb.Append('.');
                    if (part is double) sb.Append(((double)part).ToString("0", CultureInfo.InvariantCulture));
                    else sb.Append(Convert.ToString(part, CultureInfo.InvariantCulture));
                }
                return sb.ToString();
            }
            if (value is double) return ((double)value).ToString("0.###", CultureInfo.InvariantCulture);
            return value as string ?? string.Empty;
        }

        private static string KindLabel(ContentKind kind)
        {
            switch (kind)
            {
                case ContentKind.Mod: return "行为包";
                case ContentKind.World: return "世界";
                case ContentKind.Template: return "模板";
                default: return "资源包";
            }
        }

        private static string StripFormatting(string text)
        {
            if (string.IsNullOrEmpty(text)) return text;
            StringBuilder sb = new StringBuilder(text.Length);
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == '\u00A7')
                {
                    i++;
                    continue;
                }
                sb.Append(text[i]);
            }
            return sb.ToString();
        }

        private static ContentInstallResult Success(ContentKind kind, string message, string target)
        {
            ContentInstallResult result = new ContentInstallResult();
            result.Success = true;
            result.Kind = kind;
            result.Message = message;
            result.TargetPath = target;
            return result;
        }

        private static ContentInstallResult Fail(string message)
        {
            ContentInstallResult result = new ContentInstallResult();
            result.Success = false;
            result.Message = message;
            return result;
        }

        private static ContentInstallResult Skip(string message)
        {
            ContentInstallResult result = new ContentInstallResult();
            result.Success = true;
            result.Skipped = true;
            result.Message = message;
            return result;
        }

        private static void TryDeleteDirectory(string path)
        {
            if (string.IsNullOrEmpty(path)) return;
            try { if (Directory.Exists(path)) Directory.Delete(path, true); }
            catch { }
        }
    }

    /// <summary>
    /// Minimal JSON reader for manifest.json. Supports the subset needed by
    /// Bedrock manifests (objects, arrays, strings, numbers, booleans, null).
    /// </summary>
    internal static class JsonLite
    {
        public static object Parse(string text)
        {
            int index = 0;
            object value = ParseValue(text, ref index);
            Skip(text, ref index);
            return value;
        }

        public static Dictionary<string, object> AsObject(object value)
        {
            return value as Dictionary<string, object>;
        }

        public static List<object> AsArray(object value)
        {
            return value as List<object>;
        }

        public static object Get(Dictionary<string, object> obj, string key)
        {
            object value;
            if (obj != null && obj.TryGetValue(key, out value)) return value;
            return null;
        }

        public static string GetString(Dictionary<string, object> obj, string key)
        {
            object value = Get(obj, key);
            string text = value as string;
            return text;
        }

        private static object ParseValue(string text, ref int index)
        {
            Skip(text, ref index);
            if (index >= text.Length) throw new FormatException("JSON 意外结束");
            char c = text[index];
            if (c == '{') return ParseObject(text, ref index);
            if (c == '[') return ParseArray(text, ref index);
            if (c == '"') return ParseString(text, ref index);
            if (c == 't' || c == 'f' || c == 'n') return ParseLiteral(text, ref index);
            return ParseNumber(text, ref index);
        }

        private static Dictionary<string, object> ParseObject(string text, ref int index)
        {
            Dictionary<string, object> obj = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            index++;
            Skip(text, ref index);
            if (index < text.Length && text[index] == '}') { index++; return obj; }
            while (index < text.Length)
            {
                Skip(text, ref index);
                if (index >= text.Length || text[index] != '"') throw new FormatException("JSON 对象缺少键");
                string key = ParseString(text, ref index);
                Skip(text, ref index);
                if (index >= text.Length || text[index] != ':') throw new FormatException("JSON 对象缺少冒号");
                index++;
                obj[key] = ParseValue(text, ref index);
                Skip(text, ref index);
                if (index >= text.Length) throw new FormatException("JSON 对象未结束");
                if (text[index] == ',') { index++; continue; }
                if (text[index] == '}') { index++; return obj; }
                throw new FormatException("JSON 对象格式错误");
            }
            throw new FormatException("JSON 对象未结束");
        }

        private static List<object> ParseArray(string text, ref int index)
        {
            List<object> list = new List<object>();
            index++;
            Skip(text, ref index);
            if (index < text.Length && text[index] == ']') { index++; return list; }
            while (index < text.Length)
            {
                list.Add(ParseValue(text, ref index));
                Skip(text, ref index);
                if (index >= text.Length) throw new FormatException("JSON 数组未结束");
                if (text[index] == ',') { index++; continue; }
                if (text[index] == ']') { index++; return list; }
                throw new FormatException("JSON 数组格式错误");
            }
            throw new FormatException("JSON 数组未结束");
        }

        private static string ParseString(string text, ref int index)
        {
            StringBuilder sb = new StringBuilder();
            index++;
            while (index < text.Length)
            {
                char c = text[index++];
                if (c == '"') return sb.ToString();
                if (c != '\\') { sb.Append(c); continue; }
                if (index >= text.Length) break;
                char escape = text[index++];
                switch (escape)
                {
                    case '"': sb.Append('"'); break;
                    case '\\': sb.Append('\\'); break;
                    case '/': sb.Append('/'); break;
                    case 'b': sb.Append('\b'); break;
                    case 'f': sb.Append('\f'); break;
                    case 'n': sb.Append('\n'); break;
                    case 'r': sb.Append('\r'); break;
                    case 't': sb.Append('\t'); break;
                    case 'u':
                        if (index + 4 <= text.Length)
                        {
                            int code;
                            if (int.TryParse(text.Substring(index, 4), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out code))
                                sb.Append((char)code);
                            index += 4;
                        }
                        break;
                    default: sb.Append(escape); break;
                }
            }
            throw new FormatException("JSON 字符串未结束");
        }

        private static object ParseNumber(string text, ref int index)
        {
            int start = index;
            while (index < text.Length)
            {
                char c = text[index];
                if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E') index++;
                else break;
            }
            if (start == index) throw new FormatException("JSON 数字格式错误");
            double value;
            if (!double.TryParse(text.Substring(start, index - start), NumberStyles.Float, CultureInfo.InvariantCulture, out value))
                throw new FormatException("JSON 数字格式错误");
            return value;
        }

        private static object ParseLiteral(string text, ref int index)
        {
            if (index + 4 <= text.Length && text.Substring(index, 4) == "true") { index += 4; return true; }
            if (index + 5 <= text.Length && text.Substring(index, 5) == "false") { index += 5; return false; }
            if (index + 4 <= text.Length && text.Substring(index, 4) == "null") { index += 4; return null; }
            throw new FormatException("JSON 常量格式错误");
        }

        private static void Skip(string text, ref int index)
        {
            while (index < text.Length && char.IsWhiteSpace(text[index])) index++;
        }
    }
}
