using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SteveClient
{
    internal class ThinProgressBar : Control
    {
        private double _value;
        private bool _indeterminate;

        public ThinProgressBar()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Surface;
        }

        public void SetProgress(double value, bool indeterminate)
        {
            _value = Math.Max(0, Math.Min(1, value));
            _indeterminate = indeterminate;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            float h = Math.Min(Height, Theme.SF(8f));
            float y = (Height - h) / 2f;
            RectangleF track = new RectangleF(0, y, Width, h);
            using (GraphicsPath path = Theme.RoundRect(track, h / 2f))
            using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Border, 150)))
                g.FillPath(b, path);

            double value = _indeterminate ? 0.34 : _value;
            float w = (float)(Math.Max(0.06, value) * Width);
            RectangleF fill = new RectangleF(0, y, Math.Max(h, w), h);
            using (GraphicsPath path = Theme.RoundRect(fill, h / 2f))
            using (LinearGradientBrush b = new LinearGradientBrush(fill, Theme.Accent, Theme.Accent2, 0f))
                g.FillPath(b, path);
        }
    }
}
