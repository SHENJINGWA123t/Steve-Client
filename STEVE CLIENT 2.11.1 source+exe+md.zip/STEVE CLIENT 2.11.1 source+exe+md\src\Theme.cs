using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace SteveClient
{
    internal static class Theme
    {
        public const string ProductName = "STEVE CLIENT";
        public const string Version = "2.11.1";
        public const string BuildDate = "2026-11-12";

        public static float UiScale = 1f;
        public static float FontScale = 1f;

        public static readonly Color Bg = Color.FromArgb(9, 11, 17);
        public static readonly Color Sidebar = Color.FromArgb(12, 15, 23);
        public static readonly Color Sidebar2 = Color.FromArgb(9, 11, 17);
        public static readonly Color Surface = Color.FromArgb(18, 22, 34);
        public static readonly Color Surface2 = Color.FromArgb(23, 28, 43);
        public static readonly Color Surface3 = Color.FromArgb(31, 37, 55);
        public static readonly Color Border = Color.FromArgb(38, 45, 65);
        public static readonly Color BorderSoft = Color.FromArgb(28, 34, 49);
        public static readonly Color Text = Color.FromArgb(241, 245, 255);
        public static readonly Color TextSoft = Color.FromArgb(204, 211, 230);
        public static readonly Color Muted = Color.FromArgb(132, 142, 166);
        public static readonly Color Muted2 = Color.FromArgb(92, 101, 123);
        public static readonly Color Accent = Color.FromArgb(139, 92, 246);
        public static readonly Color AccentLight = Color.FromArgb(177, 147, 255);
        public static readonly Color Accent2 = Color.FromArgb(34, 211, 238);
        public static readonly Color AccentDark = Color.FromArgb(67, 43, 130);
        public static readonly Color Success = Color.FromArgb(52, 211, 153);
        public static readonly Color Warning = Color.FromArgb(251, 191, 36);
        public static readonly Color Danger = Color.FromArgb(251, 113, 133);
        public static readonly Color Blue = Color.FromArgb(96, 165, 250);

        public static readonly string UiFontName = PickFont("Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI");
        public static readonly string DisplayFontName = PickFont("Bahnschrift", "Segoe UI Semibold", "Segoe UI");
        public static readonly string MonoFontName = PickFont("Cascadia Mono", "Consolas", "Courier New");

        private static readonly Dictionary<string, Font> FontCache = new Dictionary<string, Font>();
        private static readonly object FontLock = new object();

        public static void Init(float uiScale, float fontScale)
        {
            UiScale = Math.Max(0.65f, uiScale);
            FontScale = Math.Max(0.80f, fontScale);
        }

        public static int S(float value)
        {
            return (int)Math.Round(value * UiScale, MidpointRounding.AwayFromZero);
        }

        public static float SF(float value)
        {
            return value * UiScale;
        }

        public static Font Ui(float px, FontStyle style)
        {
            return GetFont(UiFontName, px, style);
        }

        public static Font Ui(float px)
        {
            return GetFont(UiFontName, px, FontStyle.Regular);
        }

        public static Font Display(float px, FontStyle style)
        {
            return GetFont(DisplayFontName, px, style);
        }

        public static Font Mono(float px, FontStyle style)
        {
            return GetFont(MonoFontName, px, style);
        }

        public static Font Mono(float px)
        {
            return GetFont(MonoFontName, px, FontStyle.Regular);
        }

        public static Font GetFont(string family, float px, FontStyle style)
        {
            float size = Math.Max(7f, (float)Math.Round(px * FontScale, 0, MidpointRounding.AwayFromZero));
            string key = family + "|" + size.ToString("0") + "|" + (int)style;
            lock (FontLock)
            {
                Font f;
                if (FontCache.TryGetValue(key, out f)) return f;
                Font created = null;
                try
                {
                    created = new Font(family, size, style, GraphicsUnit.Pixel);
                }
                catch
                {
                    try { created = new Font("Segoe UI", size, style, GraphicsUnit.Pixel); }
                    catch { created = new Font(FontFamily.GenericSansSerif, size, style, GraphicsUnit.Pixel); }
                }
                FontCache[key] = created;
                return created;
            }
        }

        private static string PickFont(params string[] names)
        {
            try
            {
                using (InstalledFontCollection fonts = new InstalledFontCollection())
                {
                    foreach (string candidate in names)
                    {
                        foreach (FontFamily family in fonts.Families)
                        {
                            if (string.Equals(family.Name, candidate, StringComparison.OrdinalIgnoreCase))
                                return candidate;
                        }
                    }
                }
            }
            catch { }
            return "Segoe UI";
        }

        public static GraphicsPath RoundRect(RectangleF rect, float radius)
        {
            GraphicsPath path = new GraphicsPath();
            float r = Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2f);
            if (r <= 0.1f)
            {
                path.AddRectangle(rect);
                path.CloseFigure();
                return path;
            }
            float d = r * 2f;
            path.AddArc(rect.X, rect.Y, d, d, 180, 90);
            path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
            path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
            path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        public static void FillRound(Graphics g, Brush brush, RectangleF rect, float radius)
        {
            using (GraphicsPath path = RoundRect(rect, radius))
                g.FillPath(brush, path);
        }

        public static void DrawRound(Graphics g, Pen pen, RectangleF rect, float radius)
        {
            using (GraphicsPath path = RoundRect(rect, radius))
                g.DrawPath(pen, path);
        }

        public static Color Alpha(Color color, int alpha)
        {
            return Color.FromArgb(Math.Max(0, Math.Min(255, alpha)), color);
        }

        public static Color Mix(Color a, Color b, float amount)
        {
            amount = Math.Max(0f, Math.Min(1f, amount));
            return Color.FromArgb(
                (int)(a.A + (b.A - a.A) * amount),
                (int)(a.R + (b.R - a.R) * amount),
                (int)(a.G + (b.G - a.G) * amount),
                (int)(a.B + (b.B - a.B) * amount));
        }

        public static void Prepare(Graphics g)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        }

        public static StringFormat Near
        {
            get
            {
                StringFormat f = new StringFormat(StringFormat.GenericTypographic);
                f.Alignment = StringAlignment.Near;
                f.LineAlignment = StringAlignment.Near;
                f.Trimming = StringTrimming.EllipsisCharacter;
                f.FormatFlags |= StringFormatFlags.NoWrap;
                return f;
            }
        }

        public static StringFormat Center
        {
            get
            {
                StringFormat f = new StringFormat(StringFormat.GenericTypographic);
                f.Alignment = StringAlignment.Center;
                f.LineAlignment = StringAlignment.Center;
                f.Trimming = StringTrimming.EllipsisCharacter;
                f.FormatFlags |= StringFormatFlags.NoWrap;
                return f;
            }
        }

        public static StringFormat LeftCenter
        {
            get
            {
                StringFormat f = new StringFormat(StringFormat.GenericTypographic);
                f.Alignment = StringAlignment.Near;
                f.LineAlignment = StringAlignment.Center;
                f.Trimming = StringTrimming.EllipsisCharacter;
                f.FormatFlags |= StringFormatFlags.NoWrap;
                return f;
            }
        }

        public static StringFormat RightCenter
        {
            get
            {
                StringFormat f = new StringFormat(StringFormat.GenericTypographic);
                f.Alignment = StringAlignment.Far;
                f.LineAlignment = StringAlignment.Center;
                f.Trimming = StringTrimming.EllipsisCharacter;
                f.FormatFlags |= StringFormatFlags.NoWrap;
                return f;
            }
        }

        public static void DrawText(Graphics g, string text, Font font, Color color, RectangleF rect, StringFormat format)
        {
            using (SolidBrush b = new SolidBrush(color))
                g.DrawString(text, font, b, rect, format);
        }

        public static void ApplyRoundedRegion(Control control, float radius)
        {
            if (control == null || control.Width <= 0 || control.Height <= 0) return;
            try
            {
                using (GraphicsPath path = RoundRect(new RectangleF(0, 0, control.Width, control.Height), radius))
                {
                    Region old = control.Region;
                    control.Region = new Region(path);
                    if (old != null) old.Dispose();
                }
            }
            catch { }
        }

        public static void DrawSpaced(Graphics g, string text, Font font, Color color, float x, float y, float spacing)
        {
            float cx = x;
            using (SolidBrush b = new SolidBrush(color))
            {
                for (int i = 0; i < text.Length; i++)
                {
                    string ch = text.Substring(i, 1);
                    g.DrawString(ch, font, b, cx, y);
                    SizeF size = g.MeasureString(ch, font);
                    cx += size.Width + spacing;
                }
            }
        }

        public static float MeasureSpaced(Graphics g, string text, Font font, float spacing)
        {
            float width = 0f;
            for (int i = 0; i < text.Length; i++)
            {
                width += g.MeasureString(text.Substring(i, 1), font).Width + spacing;
            }
            return Math.Max(0f, width - spacing);
        }
    }
}
