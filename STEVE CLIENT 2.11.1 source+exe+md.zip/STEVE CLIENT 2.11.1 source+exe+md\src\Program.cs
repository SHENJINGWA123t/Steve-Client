using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace SteveClient
{
    internal static class Program
    {
        private static Mutex _mutex;

        [STAThread]
        private static void Main(string[] args)
        {
            if (args != null && args.Length > 0 && args[0].Equals("--self-test", StringComparison.OrdinalIgnoreCase))
            {
                SelfTest.Run();
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Native.EnableDarkMode();
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += delegate(object sender, ThreadExceptionEventArgs e)
            {
                Log.Error("未处理的 UI 异常：" + e.Exception);
                try
                {
                    DialogForm.Error(null, "启动器发生错误", e.Exception.Message + "\n\n详情已写入日志。");
                }
                catch { }
            };
            AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs e)
            {
                Exception ex = e.ExceptionObject as Exception;
                Log.Error("未处理的异常：" + (ex != null ? ex.ToString() : "unknown"));
            };

            bool multiInstance = false;
            if (args != null)
            {
                foreach (string arg in args)
                    if (string.Equals(arg, "--test-instance", StringComparison.OrdinalIgnoreCase)) multiInstance = true;
            }

            if (!multiInstance)
            {
                bool created;
                _mutex = new Mutex(true, "Local\\SteveClient.SingleInstance", out created);
                if (!created)
                {
                    IntPtr existing = Native.FindWindowW(null, Theme.ProductName);
                    if (existing != IntPtr.Zero)
                    {
                        Native.ShowWindowAsync(existing, Native.SW_RESTORE);
                        Native.SetForegroundWindow(existing);
                    }
                    return;
                }
            }

            try
            {
                Application.Run(new MainForm());
            }
            catch (Exception ex)
            {
                try { File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "crash.log"), ex.ToString()); } catch { }
                throw;
            }
            finally
            {
                if (_mutex != null)
                {
                    try { _mutex.ReleaseMutex(); } catch { }
                    _mutex.Dispose();
                }
            }
        }
    }

    internal static class SelfTest
    {
        public static void Run()
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                AppPaths.Ensure();
                sb.AppendLine("BaseDir=" + AppPaths.BaseDir);
                sb.AppendLine("DllDir=" + AppPaths.DllDir);
                sb.AppendLine("Config=" + AppPaths.ConfigFile);
                sb.AppendLine("Admin=" + AppPaths.IsAdministrator());
                sb.AppendLine("Dlls=" + Directory.GetFiles(AppPaths.DllDir, "*.dll").Length);

                string temp = Path.Combine(Path.GetTempPath(), "steve-client-selftest-" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(temp);
                AppConfig cfg = new AppConfig();
                cfg.InjectDelayMs = 4000;
                cfg.LaunchPath = @"C:\selftest\game.exe";
                GameProfile testProfile = cfg.AddProfile("测试档案", @"C:\selftest\game.exe");
                cfg.DllStates["a.dll"] = false;
                string cfgFile = Path.Combine(temp, "config.ini");
                cfg.Save(cfgFile);
                AppConfig cfg2 = AppConfig.Load(cfgFile);
                GameProfile loadedProfile = cfg2.FindProfile(testProfile.Id);
                sb.AppendLine("ConfigRoundTrip=" + (cfg2.InjectDelayMs == 4000 &&
                    loadedProfile != null && loadedProfile.Name == "测试档案" &&
                    loadedProfile.LaunchPath == @"C:\selftest\game.exe" &&
                    cfg2.GetSelectedProfile() != null && cfg2.GetSelectedProfile().Id == testProfile.Id &&
                    cfg2.FindProfile(AppConfig.OfficialProfileId) != null &&
                    cfg2.DllStates.ContainsKey("a.dll") && !cfg2.DllStates["a.dll"]));
                string profileJson = ProfileTransfer.Export(cfg);
                ProfileImportData importedProfiles = ProfileTransfer.Parse(profileJson);
                bool profileTransferOk = string.IsNullOrEmpty(importedProfiles.Error) &&
                    importedProfiles.Profiles.Count == cfg.Profiles.Count;
                if (profileTransferOk)
                {
                    bool found = false;
                    foreach (GameProfile importedProfile in importedProfiles.Profiles)
                    {
                        if (importedProfile.Name == "测试档案" &&
                            importedProfile.LaunchPath == @"C:\selftest\game.exe")
                        {
                            found = true;
                            break;
                        }
                    }
                    profileTransferOk = found;
                }
                sb.AppendLine("ProfileTransferRoundTrip=" + profileTransferOk);
                Directory.Delete(temp, true);

                string resTemp = Path.Combine(Path.GetTempPath(), "steve-client-res-" + Guid.NewGuid().ToString("N"));
                try
                {
                    string comMojang = Path.Combine(resTemp, "Users", "1234567890", "games", "com.mojang");
                    string shared = Path.Combine(resTemp, "Users", "Shared", "games", "com.mojang");
                    Directory.CreateDirectory(comMojang);
                    Directory.CreateDirectory(shared);
                    ContentProfile fake = new ContentProfile();
                    fake.DisplayName = "selftest";
                    fake.UserName = "selftest";
                    fake.AccountId = "1234567890";
                    fake.DataDir = comMojang;
                    fake.SharedDir = shared;
                    fake.IsGDK = true;
                    fake.IsCurrentUser = true;
                    fake.Exists = true;

                    List<ContentProfile> profiles = ContentProfiles.Discover(new AppConfig());
                    sb.AppendLine("Profiles=" + profiles.Count);
                    foreach (ContentProfile profile in profiles)
                        sb.AppendLine("  Profile=" + profile.DisplayName + " | shared=" + profile.SharedDir + " | exists=" + profile.Exists);

                    AppConfig scanConfig = new AppConfig();
                    scanConfig.ResourceScanDir = shared;
                    bool externalScan = false;
                    foreach (ContentProfile profile in ContentProfiles.Discover(scanConfig))
                        if (profile.IsReadOnly && string.Equals(profile.DataDir, shared, StringComparison.OrdinalIgnoreCase)) externalScan = true;
                    sb.AppendLine("ExternalScanProfile=" + externalScan);

                    string packSrc = Path.Combine(resTemp, "pack");
                    Directory.CreateDirectory(packSrc);
                    File.WriteAllText(Path.Combine(packSrc, "manifest.json"),
                        "{\"format_version\":2,\"header\":{\"name\":\"Selftest Pack\",\"uuid\":\"11111111-1111-1111-1111-111111111111\",\"version\":[1,0,0]},\"modules\":[{\"type\":\"resources\",\"uuid\":\"22222222-2222-2222-2222-222222222222\",\"version\":[1,0,0]}]}",
                        new UTF8Encoding(false));
                    string mcpack = Path.Combine(resTemp, "selftest.mcpack");
                    ZipFile.CreateFromDirectory(packSrc, mcpack);
                    List<ContentInstallResult> packResults = ContentInstaller.Install(mcpack, fake);
                    sb.AppendLine("PackInstall=" + (packResults.Count > 0 && packResults[0].Success));
                    if (packResults.Count > 0) sb.AppendLine("PackMessage=" + packResults[0].Message);
                    string resDir = Path.Combine(shared, "resource_packs");
                    sb.AppendLine("PackDirs=" + (Directory.Exists(resDir) ? Directory.GetDirectories(resDir).Length : 0));

                    List<ContentInstallResult> declinePack = ContentInstaller.Install(mcpack, fake,
                        delegate(List<ContentConflict> conflicts) { return false; });
                    sb.AppendLine("PackDeclineSkip=" + (declinePack.Count > 0 && declinePack[0].Skipped));
                    sb.AppendLine("PackDirsAfterDecline=" + Directory.GetDirectories(resDir).Length);
                    List<ContentInstallResult> overwritePack = ContentInstaller.Install(mcpack, fake,
                        delegate(List<ContentConflict> conflicts) { return true; });
                    sb.AppendLine("PackOverwrite=" + (overwritePack.Count > 0 && overwritePack[0].Success && !overwritePack[0].Skipped));
                    sb.AppendLine("PackDirsAfterOverwrite=" + Directory.GetDirectories(resDir).Length);
                    List<ContentInstallResult> noCallbackPack = ContentInstaller.Install(mcpack, fake);
                    sb.AppendLine("PackNoCallbackRejected=" + (noCallbackPack.Count > 0 && !noCallbackPack[0].Success));

                    string nestedRpSrc = Path.Combine(resTemp, "nested-rp");
                    Directory.CreateDirectory(nestedRpSrc);
                    File.WriteAllText(Path.Combine(nestedRpSrc, "manifest.json"),
                        "{\"format_version\":2,\"header\":{\"name\":\"Nested RP\",\"uuid\":\"77777777-1111-1111-1111-111111111111\",\"version\":[1,0,0]},\"modules\":[{\"type\":\"resources\",\"uuid\":\"77777777-2222-2222-2222-222222222222\",\"version\":[1,0,0]}]}",
                        new UTF8Encoding(false));
                    string nestedRpPack = Path.Combine(resTemp, "nested-rp.mcpack");
                    ZipFile.CreateFromDirectory(nestedRpSrc, nestedRpPack);

                    string nestedBpSrc = Path.Combine(resTemp, "nested-bp");
                    Directory.CreateDirectory(nestedBpSrc);
                    File.WriteAllText(Path.Combine(nestedBpSrc, "manifest.json"),
                        "{\"format_version\":2,\"header\":{\"name\":\"Nested BP\",\"uuid\":\"77777777-3333-3333-3333-333333333333\",\"version\":[1,0,0]},\"modules\":[{\"type\":\"data\",\"uuid\":\"77777777-4444-4444-4444-444444444444\",\"version\":[1,0,0]}]}",
                        new UTF8Encoding(false));
                    string nestedBpPack = Path.Combine(resTemp, "nested-bp.mcpack");
                    ZipFile.CreateFromDirectory(nestedBpSrc, nestedBpPack);

                    string nestedAddonSrc = Path.Combine(resTemp, "nested-addon");
                    Directory.CreateDirectory(nestedAddonSrc);
                    File.Copy(nestedRpPack, Path.Combine(nestedAddonSrc, "resources.mcpack"));
                    File.Copy(nestedBpPack, Path.Combine(nestedAddonSrc, "behaviors.mcpack"));
                    string nestedAddon = Path.Combine(resTemp, "nested.mcaddon");
                    ZipFile.CreateFromDirectory(nestedAddonSrc, nestedAddon);
                    List<ContentInstallResult> nestedResults = ContentInstaller.Install(nestedAddon, fake);
                    sb.AppendLine("NestedAddonInstall=" + (nestedResults.Count > 0 && nestedResults[0].Success));
                    sb.AppendLine("NestedRpFolder=" + Directory.Exists(Path.Combine(shared, "resource_packs", "Nested RP 1.0.0")));
                    sb.AppendLine("NestedBpFolder=" + Directory.Exists(Path.Combine(shared, "behavior_packs", "Nested BP 1.0.0")));
                    List<ContentInstallResult> nestedDecline = ContentInstaller.Install(nestedAddon, fake,
                        delegate(List<ContentConflict> conflicts) { return false; });
                    sb.AppendLine("NestedAddonDeclineSkip=" + (nestedDecline.Count > 0 && nestedDecline[0].Skipped));
                    List<ContentInstallResult> nestedOverwrite = ContentInstaller.Install(nestedAddon, fake,
                        delegate(List<ContentConflict> conflicts) { return true; });
                    sb.AppendLine("NestedAddonOverwrite=" + (nestedOverwrite.Count > 0 && nestedOverwrite[0].Success && !nestedOverwrite[0].Skipped));

                    string placeholderSrc = Path.Combine(resTemp, "placeholder");
                    Directory.CreateDirectory(placeholderSrc);
                    Directory.CreateDirectory(Path.Combine(placeholderSrc, "texts"));
                    File.WriteAllText(Path.Combine(placeholderSrc, "texts", "zh_CN.lang"),
                        "pack.name=本地化测试包\n", new UTF8Encoding(false));
                    File.WriteAllText(Path.Combine(placeholderSrc, "manifest.json"),
                        "{\"format_version\":2,\"header\":{\"name\":\"pack.name\",\"uuid\":\"33333333-3333-3333-3333-333333333333\",\"version\":[1,0,0]},\"modules\":[{\"type\":\"resources\",\"uuid\":\"44444444-4444-4444-4444-444444444444\",\"version\":[1,0,0]}]}",
                        new UTF8Encoding(false));
                    string placeholderPack = Path.Combine(resTemp, "placeholder.mcpack");
                    ZipFile.CreateFromDirectory(placeholderSrc, placeholderPack);
                    ContentInstaller.Install(placeholderPack, fake);
                    sb.AppendLine("PlaceholderNameFolder=" + Directory.Exists(Path.Combine(resDir, "本地化测试包 1.0.0")));

                    string worldSrc = Path.Combine(resTemp, "world");
                    Directory.CreateDirectory(worldSrc);
                    File.WriteAllBytes(Path.Combine(worldSrc, "level.dat"), new byte[] { 1, 2, 3, 4 });
                    File.WriteAllText(Path.Combine(worldSrc, "levelname.txt"), "Selftest World", new UTF8Encoding(false));
                    string mcworld = Path.Combine(resTemp, "selftest.mcworld");
                    ZipFile.CreateFromDirectory(worldSrc, mcworld);
                    List<ContentInstallResult> worldResults = ContentInstaller.Install(mcworld, fake);
                    sb.AppendLine("WorldInstall=" + (worldResults.Count > 0 && worldResults[0].Success));
                    sb.AppendLine("WorldDirs=" + Directory.GetDirectories(Path.Combine(comMojang, "minecraftWorlds")).Length);
                    List<ContentInstallResult> declineWorld = ContentInstaller.Install(mcworld, fake,
                        delegate(List<ContentConflict> conflicts) { return false; });
                    sb.AppendLine("WorldDeclineSkip=" + (declineWorld.Count > 0 && declineWorld[0].Skipped));
                    List<ContentInstallResult> overwriteWorld = ContentInstaller.Install(mcworld, fake,
                        delegate(List<ContentConflict> conflicts) { return true; });
                    sb.AppendLine("WorldOverwrite=" + (overwriteWorld.Count > 0 && overwriteWorld[0].Success && !overwriteWorld[0].Skipped));
                    sb.AppendLine("WorldDirsAfterOverwrite=" + Directory.GetDirectories(Path.Combine(comMojang, "minecraftWorlds")).Length);

                    string templateSrc = Path.Combine(resTemp, "template");
                    Directory.CreateDirectory(templateSrc);
                    Directory.CreateDirectory(Path.Combine(templateSrc, "texts"));
                    File.WriteAllText(Path.Combine(templateSrc, "texts", "zh_CN.lang"),
                        "pack.name=模板测试包\n", new UTF8Encoding(false));
                    File.WriteAllText(Path.Combine(templateSrc, "manifest.json"),
                        "{\"format_version\":2,\"header\":{\"name\":\"pack.name\",\"uuid\":\"55555555-5555-5555-5555-555555555555\",\"version\":[1,0,0]},\"modules\":[{\"type\":\"world_template\",\"uuid\":\"66666666-6666-6666-6666-666666666666\",\"version\":[1,0,0]}]}",
                        new UTF8Encoding(false));
                    File.WriteAllBytes(Path.Combine(templateSrc, "level.dat"), new byte[] { 1, 2, 3, 4 });
                    File.WriteAllText(Path.Combine(templateSrc, "levelname.txt"), "模板世界", new UTF8Encoding(false));
                    string mctemplate = Path.Combine(resTemp, "selftest.mctemplate");
                    ZipFile.CreateFromDirectory(templateSrc, mctemplate);
                    List<ContentInstallResult> templateResults = ContentInstaller.Install(mctemplate, fake);
                    sb.AppendLine("TemplateInstall=" + (templateResults.Count > 0 && templateResults[0].Success));
                    if (templateResults.Count > 0) sb.AppendLine("TemplateMessage=" + templateResults[0].Message);
                    string templateDir = Path.Combine(shared, "world_templates");
                    sb.AppendLine("TemplateFolder=" + Directory.Exists(Path.Combine(templateDir, "模板测试包")));
                    List<ContentInstallResult> declineTemplate = ContentInstaller.Install(mctemplate, fake,
                        delegate(List<ContentConflict> conflicts) { return false; });
                    sb.AppendLine("TemplateDeclineSkip=" + (declineTemplate.Count > 0 && declineTemplate[0].Skipped));
                    List<ContentInstallResult> overwriteTemplate = ContentInstaller.Install(mctemplate, fake,
                        delegate(List<ContentConflict> conflicts) { return true; });
                    sb.AppendLine("TemplateOverwrite=" + (overwriteTemplate.Count > 0 && overwriteTemplate[0].Success && !overwriteTemplate[0].Skipped));
                    sb.AppendLine("TemplateDirsAfterOverwrite=" + Directory.GetDirectories(templateDir).Length);
                    File.Copy(mctemplate, Path.Combine(templateDir, "existing.mctemplate"), true);
                    int templateCount = 0;
                    foreach (ContentItem item in ContentInstaller.Scan(fake))
                        if (item.Kind == ContentKind.Template) templateCount++;
                    sb.AppendLine("TemplateScan=" + templateCount);
                    sb.AppendLine("ScanCount=" + ContentInstaller.Scan(fake).Count);
                }
                catch (Exception resourceEx)
                {
                    sb.AppendLine("ResourceTest=FAIL " + resourceEx);
                }
                finally
                {
                    try { if (Directory.Exists(resTemp)) Directory.Delete(resTemp, true); } catch { }
                }

                MinecraftInstall mc = GameLauncher.Detect();
                sb.AppendLine("MinecraftFound=" + mc.Found);
                sb.AppendLine("MinecraftVersion=" + mc.Version);
                sb.AppendLine("MinecraftAUMID=" + mc.AppUserModelId);
                List<string> statePackages = GameLauncher.GetStateRepositoryPackages();
                sb.AppendLine("StatePackages=" + statePackages.Count);
                foreach (string pkg in statePackages) sb.AppendLine("  " + pkg);
                Process[] games = System.Diagnostics.Process.GetProcessesByName(GameLauncher.ProcessName);
                sb.AppendLine("GameRunning=" + (games.Length > 0));
                foreach (Process p in games) p.Dispose();

                string self = System.Reflection.Assembly.GetExecutingAssembly().Location;
                PeInfo pe = PeInspector.Inspect(self);
                sb.AppendLine("SelfPEValid=" + pe.Valid);
                sb.AppendLine("SelfPEArch=" + pe.ArchitectureText);
                sb.AppendLine("SelfPEIsDll=" + pe.IsDll);
                sb.AppendLine("Is64BitProcess=" + Environment.Is64BitProcess);
                sb.AppendLine("SelfTest=OK");
            }
            catch (Exception ex)
            {
                sb.AppendLine("SelfTest=FAIL");
                sb.AppendLine(ex.ToString());
            }
            try
            {
                File.WriteAllText(Path.Combine(AppPaths.BaseDir, "self-test.txt"), sb.ToString(), new UTF8Encoding(false));
            }
            catch { }
        }
    }
}
