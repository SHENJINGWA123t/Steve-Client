using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SteveClient
{
    internal sealed class GameProfile
    {
        public string Id = string.Empty;
        public string Name = string.Empty;
        public string LaunchPath = string.Empty;
        public bool IsOfficial;
    }

    internal sealed class AppConfig
    {
        public const string OfficialProfileId = "official";

        public bool FirstRunCompleted;
        public int ConfigVersion = 2;
        public int InjectDelayMs = 2500;
        public int StartupWarmupMs = 10000;
        public bool MinimizeAfterInject = true;
        public bool CloseAfterInject = false;
        public bool HideToTrayOnClose = false;
        public bool CloseBehaviorAsked = false;
        public string InjectHotkey = "Ctrl+1";
        public string LaunchHotkey = "Ctrl+2";
        public string CloseHotkey = "Ctrl+3";
        public bool EnableInjectHotkey = false;
        public bool EnableLaunchHotkey = false;
        public bool EnableCloseHotkey = false;
        public bool LaunchWithDlls = true;
        public bool VerifyArchitecture = true;
        public string LaunchPath = string.Empty;
        public string ResourceDataDir = string.Empty;
        public bool ResourceCustom;
        public string ResourceScanDir = string.Empty;
        public readonly List<GameProfile> Profiles = new List<GameProfile>();
        public string SelectedProfileId = OfficialProfileId;
        public readonly Dictionary<string, bool> DllStates = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);

        public AppConfig()
        {
            GameProfile official = new GameProfile();
            official.Id = OfficialProfileId;
            official.Name = "Minecraft 官方版";
            official.IsOfficial = true;
            Profiles.Add(official);
        }

        public GameProfile GetSelectedProfile()
        {
            foreach (GameProfile profile in Profiles)
                if (string.Equals(profile.Id, SelectedProfileId, StringComparison.OrdinalIgnoreCase))
                    return profile;
            return null;
        }

        public GameProfile FindProfile(string id)
        {
            foreach (GameProfile profile in Profiles)
                if (string.Equals(profile.Id, id, StringComparison.OrdinalIgnoreCase))
                    return profile;
            return null;
        }

        public static AppConfig Load(string path)
        {
            AppConfig config = new AppConfig();
            if (!File.Exists(path)) return config;
            config.Profiles.Clear();

            string section = "general";
            int loadedVersion = 0;
            try
            {
                foreach (string raw in File.ReadAllLines(path, Encoding.UTF8))
                {
                    string line = raw.Trim();
                    if (line.Length == 0 || line.StartsWith(";") || line.StartsWith("#")) continue;
                    if (line.StartsWith("[") && line.EndsWith("]"))
                    {
                        section = line.Substring(1, line.Length - 2).Trim().ToLowerInvariant();
                        continue;
                    }
                    int eq = line.IndexOf('=');
                    if (eq < 0) continue;
                    string key = line.Substring(0, eq).Trim();
                    string value = line.Substring(eq + 1).Trim();
                    if (section == "general")
                    {
                        if (key.Equals("configVersion", StringComparison.OrdinalIgnoreCase))
                            loadedVersion = ParseInt(value, 0);
                        else if (key.Equals("firstRunCompleted", StringComparison.OrdinalIgnoreCase))
                            config.FirstRunCompleted = ParseBool(value, config.FirstRunCompleted);
                        else if (key.Equals("injectDelayMs", StringComparison.OrdinalIgnoreCase))
                            config.InjectDelayMs = ParseInt(value, config.InjectDelayMs);
                        else if (key.Equals("startupWarmupMs", StringComparison.OrdinalIgnoreCase))
                            config.StartupWarmupMs = ParseInt(value, config.StartupWarmupMs);
                        else if (key.Equals("minimizeAfterInject", StringComparison.OrdinalIgnoreCase))
                            config.MinimizeAfterInject = ParseBool(value, config.MinimizeAfterInject);
                        else if (key.Equals("closeAfterInject", StringComparison.OrdinalIgnoreCase))
                            config.CloseAfterInject = ParseBool(value, config.CloseAfterInject);
                        else if (key.Equals("hideToTrayOnClose", StringComparison.OrdinalIgnoreCase) ||
                                 key.Equals("minimizeOnClose", StringComparison.OrdinalIgnoreCase))
                            config.HideToTrayOnClose = ParseBool(value, config.HideToTrayOnClose);
                        else if (key.Equals("closeBehaviorAsked", StringComparison.OrdinalIgnoreCase))
                            config.CloseBehaviorAsked = ParseBool(value, config.CloseBehaviorAsked);
                        else if (key.Equals("injectHotkey", StringComparison.OrdinalIgnoreCase))
                            config.InjectHotkey = value;
                        else if (key.Equals("launchHotkey", StringComparison.OrdinalIgnoreCase))
                            config.LaunchHotkey = value;
                        else if (key.Equals("closeHotkey", StringComparison.OrdinalIgnoreCase))
                            config.CloseHotkey = value;
                        else if (key.Equals("enableInjectHotkey", StringComparison.OrdinalIgnoreCase))
                            config.EnableInjectHotkey = ParseBool(value, config.EnableInjectHotkey);
                        else if (key.Equals("enableLaunchHotkey", StringComparison.OrdinalIgnoreCase))
                            config.EnableLaunchHotkey = ParseBool(value, config.EnableLaunchHotkey);
                        else if (key.Equals("enableCloseHotkey", StringComparison.OrdinalIgnoreCase))
                            config.EnableCloseHotkey = ParseBool(value, config.EnableCloseHotkey);
                        else if (key.Equals("launchWithDlls", StringComparison.OrdinalIgnoreCase))
                            config.LaunchWithDlls = ParseBool(value, config.LaunchWithDlls);
                        else if (key.Equals("verifyArchitecture", StringComparison.OrdinalIgnoreCase))
                            config.VerifyArchitecture = ParseBool(value, config.VerifyArchitecture);
                        else if (key.Equals("launchPath", StringComparison.OrdinalIgnoreCase))
                            config.LaunchPath = value;
                        else if (key.Equals("resourceDataDir", StringComparison.OrdinalIgnoreCase))
                            config.ResourceDataDir = value;
                    }
                    else if (section == "resources")
                    {
                        if (key.Equals("dataDir", StringComparison.OrdinalIgnoreCase) ||
                            key.Equals("resourceDataDir", StringComparison.OrdinalIgnoreCase))
                            config.ResourceDataDir = value;
                        else if (key.Equals("custom", StringComparison.OrdinalIgnoreCase))
                            config.ResourceCustom = ParseBool(value, config.ResourceCustom);
                        else if (key.Equals("scanDir", StringComparison.OrdinalIgnoreCase))
                            config.ResourceScanDir = value;
                    }
                    else if (section == "dlls")
                    {
                        if (key.Length > 0) config.DllStates[key] = ParseBool(value, true);
                    }
                    else if (section == "profiles")
                    {
                        if (key.Equals("selected", StringComparison.OrdinalIgnoreCase))
                        {
                            config.SelectedProfileId = value;
                        }
                        else
                        {
                            int dot = key.IndexOf('.');
                            int index;
                            if (dot > 1 && key[0] == 'p' &&
                                int.TryParse(key.Substring(1, dot - 1), out index) &&
                                index >= 0 && index < 100)
                            {
                                while (config.Profiles.Count <= index)
                                    config.Profiles.Add(new GameProfile());
                                GameProfile profile = config.Profiles[index];
                                string field = key.Substring(dot + 1).Trim().ToLowerInvariant();
                                if (field == "id") profile.Id = value;
                                else if (field == "name") profile.Name = value;
                                else if (field == "path") profile.LaunchPath = value;
                            }
                        }
                    }
                }
            }
            catch { }

            if (config.InjectDelayMs < 500) config.InjectDelayMs = 500;
            if (config.InjectDelayMs > 15000) config.InjectDelayMs = 15000;
            if (config.StartupWarmupMs < 0) config.StartupWarmupMs = 0;
            if (config.StartupWarmupMs > 30000) config.StartupWarmupMs = 30000;
            // 2.2.0 changed the default startup wait from 15s to 10s.
            if (loadedVersion < 2 && config.StartupWarmupMs == 15000) config.StartupWarmupMs = 10000;
            config.ConfigVersion = 2;
            config.NormalizeProfiles();
            return config;
        }

        private void NormalizeProfiles()
        {
            List<GameProfile> normalized = new List<GameProfile>();
            foreach (GameProfile profile in Profiles)
            {
                if (profile == null) continue;
                profile.Id = (profile.Id ?? string.Empty).Trim();
                profile.Name = (profile.Name ?? string.Empty).Trim();
                profile.LaunchPath = (profile.LaunchPath ?? string.Empty).Trim();
                if (profile.Id.Length == 0) profile.Id = Guid.NewGuid().ToString("N");
                if (profile.Name.Length == 0) profile.Name = "游戏档案";
                if (string.Equals(profile.Id, OfficialProfileId, StringComparison.OrdinalIgnoreCase))
                {
                    profile.Id = OfficialProfileId;
                    profile.IsOfficial = true;
                }
                if (profile.IsOfficial)
                {
                    profile.Id = OfficialProfileId;
                    profile.LaunchPath = string.Empty;
                    if (profile.Name.Length == 0) profile.Name = "Minecraft 官方版";
                }
                bool duplicate = false;
                foreach (GameProfile existing in normalized)
                {
                    if (string.Equals(existing.Id, profile.Id, StringComparison.OrdinalIgnoreCase))
                    {
                        duplicate = true;
                        break;
                    }
                }
                if (!duplicate) normalized.Add(profile);
            }

            Profiles.Clear();
            Profiles.AddRange(normalized);
            GameProfile official = FindProfile(OfficialProfileId);
            if (official == null)
            {
                official = new GameProfile();
                official.Id = OfficialProfileId;
                official.Name = "Minecraft 官方版";
                official.IsOfficial = true;
                Profiles.Insert(0, official);
            }

            // Migrate the single custom launch path from older versions.
            string legacyPath = (LaunchPath ?? string.Empty).Trim();
            if (legacyPath.Length > 0)
            {
                GameProfile legacy = null;
                foreach (GameProfile profile in Profiles)
                {
                    if (profile.IsOfficial) continue;
                    if (string.Equals(profile.LaunchPath, legacyPath, StringComparison.OrdinalIgnoreCase))
                    {
                        legacy = profile;
                        break;
                    }
                }
                if (legacy == null)
                {
                    legacy = new GameProfile();
                    legacy.Id = Guid.NewGuid().ToString("N");
                    legacy.Name = "自定义启动";
                    legacy.LaunchPath = legacyPath;
                    Profiles.Add(legacy);
                }
                if (string.IsNullOrEmpty(SelectedProfileId) ||
                    string.Equals(SelectedProfileId, OfficialProfileId, StringComparison.OrdinalIgnoreCase))
                    SelectedProfileId = legacy.Id;
                LaunchPath = string.Empty;
            }

            if (GetSelectedProfile() == null)
                SelectedProfileId = OfficialProfileId;
        }

        public void Save(string path)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("; STEVE CLIENT configuration");
                sb.AppendLine("; This file is generated automatically.");
                sb.AppendLine();
                sb.AppendLine("[general]");
                sb.AppendLine("configVersion=" + ConfigVersion);
                sb.AppendLine("firstRunCompleted=" + (FirstRunCompleted ? "true" : "false"));
                sb.AppendLine("injectDelayMs=" + InjectDelayMs);
                sb.AppendLine("startupWarmupMs=" + StartupWarmupMs);
                sb.AppendLine("minimizeAfterInject=" + (MinimizeAfterInject ? "true" : "false"));
                sb.AppendLine("closeAfterInject=" + (CloseAfterInject ? "true" : "false"));
                sb.AppendLine("hideToTrayOnClose=" + (HideToTrayOnClose ? "true" : "false"));
                sb.AppendLine("closeBehaviorAsked=" + (CloseBehaviorAsked ? "true" : "false"));
                sb.AppendLine("injectHotkey=" + (InjectHotkey ?? "Ctrl+1"));
                sb.AppendLine("launchHotkey=" + (LaunchHotkey ?? "Ctrl+2"));
                sb.AppendLine("closeHotkey=" + (CloseHotkey ?? "Ctrl+3"));
                sb.AppendLine("enableInjectHotkey=" + (EnableInjectHotkey ? "true" : "false"));
                sb.AppendLine("enableLaunchHotkey=" + (EnableLaunchHotkey ? "true" : "false"));
                sb.AppendLine("enableCloseHotkey=" + (EnableCloseHotkey ? "true" : "false"));
                sb.AppendLine("launchWithDlls=" + (LaunchWithDlls ? "true" : "false"));
                sb.AppendLine("verifyArchitecture=" + (VerifyArchitecture ? "true" : "false"));
                sb.AppendLine("launchPath=" + (LaunchPath ?? string.Empty));
                sb.AppendLine();
                sb.AppendLine("[dlls]");
                foreach (KeyValuePair<string, bool> pair in DllStates)
                {
                    if (string.IsNullOrWhiteSpace(pair.Key)) continue;
                    sb.AppendLine(pair.Key.Replace("=", "_") + "=" + (pair.Value ? "true" : "false"));
                }
                sb.AppendLine();
                sb.AppendLine("[resources]");
                sb.AppendLine("dataDir=" + (ResourceDataDir ?? string.Empty));
                sb.AppendLine("custom=" + (ResourceCustom ? "true" : "false"));
                sb.AppendLine("scanDir=" + (ResourceScanDir ?? string.Empty));
                sb.AppendLine();
                sb.AppendLine("[profiles]");
                sb.AppendLine("selected=" + (SelectedProfileId ?? string.Empty));
                sb.AppendLine("count=" + Profiles.Count);
                for (int i = 0; i < Profiles.Count; i++)
                {
                    GameProfile profile = Profiles[i];
                    sb.AppendLine("p" + i + ".id=" + CleanIniValue(profile.Id));
                    sb.AppendLine("p" + i + ".name=" + CleanIniValue(profile.Name));
                    sb.AppendLine("p" + i + ".path=" + CleanIniValue(profile.LaunchPath));
                }

                string tmp = path + ".tmp";
                File.WriteAllText(tmp, sb.ToString(), new UTF8Encoding(false));
                if (File.Exists(path)) File.Delete(path);
                File.Move(tmp, path);
            }
            catch (Exception ex)
            {
                Log.Warn("保存配置失败：" + ex.Message);
            }
        }

        public GameProfile AddProfile(string name, string launchPath)
        {
            GameProfile profile = new GameProfile();
            profile.Id = Guid.NewGuid().ToString("N");
            profile.Name = (name ?? string.Empty).Trim();
            if (profile.Name.Length == 0) profile.Name = "游戏档案";
            profile.LaunchPath = (launchPath ?? string.Empty).Trim();
            Profiles.Add(profile);
            SelectedProfileId = profile.Id;
            return profile;
        }

        public bool RemoveProfile(string id)
        {
            if (string.IsNullOrEmpty(id) ||
                string.Equals(id, OfficialProfileId, StringComparison.OrdinalIgnoreCase))
                return false;
            GameProfile profile = FindProfile(id);
            if (profile == null) return false;
            Profiles.Remove(profile);
            if (string.Equals(SelectedProfileId, id, StringComparison.OrdinalIgnoreCase))
                SelectedProfileId = OfficialProfileId;
            return true;
        }

        private static string CleanIniValue(string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            return value.Replace("\r", " ").Replace("\n", " ").Trim();
        }

        public bool? GetDllState(string fileName)
        {
            bool value;
            if (DllStates.TryGetValue(fileName, out value)) return value;
            return null;
        }

        public void SetDllState(string fileName, bool enabled)
        {
            DllStates[fileName] = enabled;
        }

        private static bool ParseBool(string value, bool fallback)
        {
            if (string.IsNullOrWhiteSpace(value)) return fallback;
            value = value.Trim();
            if (value.Equals("true", StringComparison.OrdinalIgnoreCase) || value == "1" || value.Equals("yes", StringComparison.OrdinalIgnoreCase)) return true;
            if (value.Equals("false", StringComparison.OrdinalIgnoreCase) || value == "0" || value.Equals("no", StringComparison.OrdinalIgnoreCase)) return false;
            return fallback;
        }

        private static int ParseInt(string value, int fallback)
        {
            int result;
            if (int.TryParse(value, out result)) return result;
            return fallback;
        }
    }
}
