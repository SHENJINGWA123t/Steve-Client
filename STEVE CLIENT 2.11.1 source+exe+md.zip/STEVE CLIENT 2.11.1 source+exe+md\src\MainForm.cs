using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SteveClient
{
    internal enum PageKind
    {
        Launch,
        Profiles,
        Modules,
        Resources,
        Logs,
        Settings
    }

    internal sealed class MainForm : Form
    {
        private readonly AppConfig _config;
        private MinecraftInstall _minecraft;
        private List<DllInfo> _dlls = new List<DllInfo>();
        private readonly bool _admin;
        private bool _firstRun;
        private bool _autoLaunch;

        private Panel _root;
        private Panel _sidebar;
        private Panel _workspace;
        private Panel _titlebar;
        private Panel _pageHost;
        private Panel _pageLaunch;
        private Panel _pageProfiles;
        private Panel _pageModules;
        private Panel _pageResources;
        private Panel _pageLogs;
        private ScrollHostPanel _pageSettings;
        private Panel _settingsContent;
        private IconButton _minButton;
        private IconButton _closeButton;
        private int _hoverNav = -1;
        private static readonly string[] NavNames = { "启动中心", "游戏档案", "DLL 模块", "资源库", "运行日志", "设置" };
        private static readonly IconGlyph[] NavGlyphs = { IconGlyph.Play, IconGlyph.Profile, IconGlyph.Puzzle, IconGlyph.Download, IconGlyph.Search, IconGlyph.Settings };
        private HeroCard _hero;
        private StatCard _statModules;
        private StatCard _statGame;
        private StatCard _statPermission;
        private ModuleStrip _moduleStrip;
        private RoundedPanel _launchPathCard;
        private TextLabel _launchPathCaption;
        private TextLabel _launchPathValue;
        private PageHeader _profilesHeader;
        private RoundedPanel _profileToolbar;
        private TextLabel _profileCountLabel;
        private TextLabel _profileHintLabel;
        private PillButton _importProfilesButton;
        private PillButton _exportProfilesButton;
        private PillButton _addProfileButton;
        private PillButton _batchProfilesButton;
        private BatchBar _profileBatchBar;
        private bool _profileBatchMode;
        private ProfileListPanel _profileListHost;
        private TextLabel _profilesFooter;
        private PillButton _launchPathBrowseButton;
        private PillButton _launchPathResetButton;
        private Badge _launchBadge;
        private PageHeader _launchHeader;
        private PageHeader _modulesHeader;
        private PageHeader _logsHeader;
        private PageHeader _settingsHeader;
        private DllListPanel _dllList;
        private PillButton _batchDllsButton;
        private BatchBar _dllBatchBar;
        private bool _dllBatchMode;
        private TextLabel _moduleFooter;
        private PageHeader _resourcesHeader;
        private RoundedPanel _profileCard;
        private TextLabel _profileCaption;
        private TextLabel _profileName;
        private TextLabel _profilePath;
        private PillButton _profileSwitch;
        private PillButton _addResourceButton;
        private PillButton _openResourceFolderButton;
        private PillButton _refreshResourceButton;
        private ContentListPanel _contentList;
        private TextLabel _contentFooter;
        private TextLabel _launchFooterNote;
        private PillButton _batchContentButton;
        private BatchBar _contentBatchBar;
        private bool _contentBatchMode;
        private PillButton _tabTexture;
        private PillButton _tabBehavior;
        private PillButton _tabWorld;
        private PillButton _tabTemplate;
        private ContentKind _contentTab = ContentKind.TexturePack;
        private ContextMenuStrip _profileMenu;
        private ContextMenuStrip _launchProfileMenu;
        private List<ContentProfile> _profiles = new List<ContentProfile>();
        private ContentProfile _profile;
        private List<ContentItem> _content = new List<ContentItem>();
        private string _contentCacheKey = string.Empty;
        private bool _contentDirty = true;
        private readonly Dictionary<string, List<ContentItem>> _contentMemoryCache =
            new Dictionary<string, List<ContentItem>>(StringComparer.OrdinalIgnoreCase);
        private RoundedPanel _importOverlay;
        private TextLabel _importTitle;
        private TextLabel _importDetail;
        private TextLabel _importPercent;
        private ThinProgressBar _importBar;
        private PillButton _importCancelButton;
        private CancellationTokenSource _importCts;
        private bool _importing;
        private bool _closeAfterImport;
        private bool _skipCloseBehavior;
        private bool _contentRefreshing;
        private DateTime _lastImportProgress;
        private LogView _logView;
        private Toast _toast;
        private NotifyIcon _trayIcon;
        private ContextMenuStrip _trayMenu;
        private ToolStripMenuItem _trayDirectLaunch;
        private ToolStripMenuItem _trayEndGame;
        private TrayNotice _trayNotice;
        private TextLabel _settingsPath;
        private TextLabel _settingsPermission;
        private TextLabel _settingsVersion;
        private ToggleSwitch _minimizeToggle;
        private ToggleSwitch _closeToggle;
        private ToggleSwitch _hideToTrayToggle;
        private ToggleSwitch _verifyToggle;
        private TextBox _warmupInput;
        private TextLabel _warmupUnit;
        private PillButton _warmupResetButton;
        private bool _warmupUpdating;
        private readonly List<PillButton> _delayButtons = new List<PillButton>();
        private PillButton _adminButton;
        private PageKind _page = PageKind.Launch;
        private string _breadcrumb = "启动中心";
        private string _statusText = "就绪";
        private Color _statusColor = Theme.Success;
        private string _activityText = "等待启动";
        private bool _busy;
        private CancellationTokenSource _cts;
        private FileSystemWatcher _watcher;
        private System.Windows.Forms.Timer _watchTimer;
        private System.Windows.Forms.Timer _gameWatchTimer;
        private System.Windows.Forms.Timer _restoreRepaintTimer;
        private bool _refreshPending;
        private bool _wasMinimized;
        private string _lastDropSignature = string.Empty;
        private DateTime _lastDropTime = DateTime.MinValue;
        private bool _lastGameRunning;
        private const int HotkeyInjectId = 0x5A01;
        private const int HotkeyLaunchId = 0x5A02;
        private const int HotkeyCloseId = 0x5A03;
        private enum HotkeyTarget { Inject, Launch, Close }
        private bool _hotkeyRegistered;
        private bool _launchHotkeyRegistered;
        private bool _closeHotkeyRegistered;
        private uint _injectHotkeyModifiers;
        private Keys _injectHotkeyKey;
        private uint _launchHotkeyModifiers;
        private Keys _launchHotkeyKey;
        private uint _closeHotkeyModifiers;
        private Keys _closeHotkeyKey;
        private bool _capturingHotkey;
        private HotkeyTarget _capturingHotkeyTarget;
        private PillButton _hotkeyButton;
        private PillButton _hotkeyResetButton;
        private PillButton _launchHotkeyButton;
        private PillButton _launchHotkeyResetButton;
        private PillButton _closeHotkeyButton;
        private PillButton _closeHotkeyResetButton;
        private ToggleSwitch _injectHotkeyToggle;
        private ToggleSwitch _launchHotkeyToggle;
        private ToggleSwitch _closeHotkeyToggle;
        private readonly ToolTip _tooltip = new ToolTip();
        private Image _logoImage;

        public MainForm()
        {
            AppPaths.Ensure();
            _admin = AppPaths.IsAdministrator();
            _config = AppConfig.Load(AppPaths.ConfigFile);
            _firstRun = AppPaths.IsFirstRun || !_config.FirstRunCompleted;
            try
            {
                foreach (string arg in Environment.GetCommandLineArgs())
                    if (string.Equals(arg, "--auto-launch", StringComparison.OrdinalIgnoreCase)) _autoLaunch = true;
            }
            catch { }

            float dpi = 96f;
            try { dpi = Native.GetDpiForSystem(); } catch { }
            if (dpi < 72f) dpi = 96f;
            Rectangle work;
            try { work = Screen.PrimaryScreen.WorkingArea; }
            catch { work = new Rectangle(0, 0, 1280, 720); }
            float layout = Math.Min(dpi / 96f, Math.Min((work.Width - 44f) / 1000f, (work.Height - 44f) / 650f));
            layout = Math.Max(0.78f, Math.Min(1.70f, layout));
            float font = Math.Min(dpi / 96f, 1.50f);
            if (font < 0.90f) font = 0.90f;
            Theme.Init(layout, font);

            _minecraft = GameLauncher.Detect();
            _lastGameRunning = GameLauncher.IsGameRunning();

            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            Text = Theme.ProductName;
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Theme.Border;
            Padding = new Padding(1);
            ClientSize = new Size(Theme.S(1000f), Theme.S(650f));
            DoubleBuffered = true;
            KeyPreview = true;
            AllowDrop = true;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
            try
            {
                string[] resourceNames = new string[] { "SteveIcon.png", "SteveClient.SteveIcon.png" };
                foreach (string resourceName in resourceNames)
                {
                    Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName);
                    if (stream == null) continue;
                    using (stream) _logoImage = Image.FromStream(stream);
                    break;
                }
            }
            catch { }

            Log.Initialize();
            BuildInterface();
            InitializeTrayIcon();
            BuildLogPage();
            PageKind startupPage = ParseStartupPage();
            SwitchPage(startupPage);
            Log.Info("启动页面：" + startupPage);
            LoadDlls(true);
            HookEvents();
            UpdateEverything();
            SetStatus(_lastGameRunning ? "游戏运行中" : "就绪", Theme.Success);
            SetActivity(_lastGameRunning ? "游戏运行中" : "等待启动");

            Log.Info("STEVE CLIENT v" + Theme.Version + " 启动");
            Log.Info("程序目录：" + AppPaths.BaseDir);
            Log.Info("DLL 目录：" + AppPaths.DllDir + "（" + _dlls.Count + " 个 DLL）");
            Log.Info("资源目标：" + (_profile != null ? _profile.DisplayName + " · " + _profile.DataDir : "未选择"));
            Log.Info("权限：" + (_admin ? "管理员" : "标准用户"));
            Log.Info("UI：dpi=" + dpi + " work=" + work.Width + "x" + work.Height +
                     " scale=" + Theme.UiScale.ToString("0.00") + " font=" + Theme.FontScale.ToString("0.00") +
                     " client=" + ClientSize.Width + "x" + ClientSize.Height);
            if (_minecraft.Found)
                Log.Info("检测到 " + _minecraft.DisplayName + " v" + _minecraft.Version);
            else
                Log.Warn("未检测到 Minecraft for Windows 安装信息");
            GameProfile selectedProfile = _config.GetSelectedProfile();
            if (selectedProfile != null)
            {
                if (selectedProfile.IsOfficial)
                    Log.Info("当前游戏档案：" + selectedProfile.Name + "（Microsoft Store）");
                else
                    Log.Info("当前游戏档案：" + selectedProfile.Name + " · " +
                             (File.Exists(selectedProfile.LaunchPath) ? selectedProfile.LaunchPath : "路径不存在"));
            }
            if (_firstRun)
            {
                _config.FirstRunCompleted = true;
                _config.Save(AppPaths.ConfigFile);
                Log.Ok("首次运行：已创建总文件夹 " + AppPaths.DataDir);
            }

            Shown += MainFormShown;
            FormClosing += MainFormClosing;
            Resize += MainFormResize;
            ResizeEnd += delegate { ApplyRoundedRegion(); };
            DragEnter += MainFormDragEnter;
            DragDrop += MainFormDragDrop;
            KeyDown += MainFormKeyDown;
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.ClearTopMost(Handle);
            Native.EnableFileDrop(Handle);
            RegisterConfiguredHotkey(HotkeyTarget.Inject);
            RegisterConfiguredHotkey(HotkeyTarget.Launch);
            RegisterConfiguredHotkey(HotkeyTarget.Close);
        }

        private void MainFormResize(object sender, EventArgs e)
        {
            PositionToast();
            if (WindowState == FormWindowState.Minimized)
            {
                _wasMinimized = true;
                return;
            }
            if (WindowState == FormWindowState.Normal && _wasMinimized)
            {
                _wasMinimized = false;
                try { BeginInvoke(new Action(ForceFullRepaint)); } catch { }
                StartRestoreRepaintTimer();
            }
        }

        private void StartRestoreRepaintTimer()
        {
            if (_restoreRepaintTimer == null)
            {
                _restoreRepaintTimer = new System.Windows.Forms.Timer();
                _restoreRepaintTimer.Interval = 120;
                _restoreRepaintTimer.Tick += delegate
                {
                    _restoreRepaintTimer.Stop();
                    ForceFullRepaint();
                };
            }
            _restoreRepaintTimer.Stop();
            _restoreRepaintTimer.Start();
        }

        private void ForceFullRepaint()
        {
            if (IsDisposed || !IsHandleCreated || WindowState != FormWindowState.Normal) return;
            try
            {
                Native.ClearTopMost(Handle);
                Native.EnableFileDrop(Handle);
                ApplyRoundedRegion();
                Invalidate(true);
                Update();
                Native.RedrawWindow(Handle, IntPtr.Zero, IntPtr.Zero,
                    Native.RDW_INVALIDATE | Native.RDW_ERASE | Native.RDW_FRAME |
                    Native.RDW_ALLCHILDREN | Native.RDW_UPDATENOW);
            }
            catch { }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == Native.WM_HOTKEY)
            {
                int id = m.WParam.ToInt32();
                if (id == HotkeyInjectId)
                {
                    HandleInjectHotkey();
                    return;
                }
                if (id == HotkeyLaunchId)
                {
                    HandleLaunchHotkey();
                    return;
                }
                if (id == HotkeyCloseId)
                {
                    HandleCloseHotkey();
                    return;
                }
            }
            if (m.Msg == Native.WM_DROPFILES)
            {
                string[] files = Native.ReadDropFiles(m.WParam);
                if (files.Length > 0)
                {
                    try { BeginInvoke(new Action(delegate { HandleDroppedFiles(files); })); } catch { }
                }
                return;
            }
            base.WndProc(ref m);
        }

        private static PageKind ParseStartupPage()
        {
            try
            {
                string[] args = Environment.GetCommandLineArgs();
                foreach (string arg in args)
                {
                    if (arg.StartsWith("--page=", StringComparison.OrdinalIgnoreCase))
                    {
                        string value = arg.Substring(7).Trim().ToLowerInvariant();
                        if (value == "modules" || value == "dll") return PageKind.Modules;
                        if (value == "profiles" || value == "profile") return PageKind.Profiles;
                        if (value == "resources" || value == "resource" || value == "content") return PageKind.Resources;
                        if (value == "logs") return PageKind.Logs;
                        if (value == "settings") return PageKind.Settings;
                    }
                }
            }
            catch { }
            return PageKind.Launch;
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= 0x00020000; // CS_DROPSHADOW
                return cp;
            }
        }

        private void InitializeTrayIcon()
        {
            _trayIcon = new NotifyIcon();
            try { _trayIcon.Icon = Icon != null ? Icon : SystemIcons.Application; }
            catch { _trayIcon.Icon = SystemIcons.Application; }
            _trayIcon.Text = "STEVE CLIENT";
            _trayIcon.Visible = false;

            _trayMenu = new ContextMenuStrip();
            _trayMenu.Renderer = new DarkMenuRenderer();
            _trayMenu.BackColor = Theme.Surface2;
            _trayMenu.ForeColor = Theme.TextSoft;
            _trayMenu.ShowImageMargin = false;

            _trayDirectLaunch = new ToolStripMenuItem("直接启动");
            _trayDirectLaunch.Font = new Font(_trayMenu.Font, FontStyle.Bold);
            _trayDirectLaunch.Click += async delegate { await StartFromTrayAsync(); };
            _trayMenu.Items.Add(_trayDirectLaunch);
            _trayMenu.Items.Add(new ToolStripSeparator());

            ToolStripMenuItem open = new ToolStripMenuItem("打开界面");
            open.Click += delegate { RestoreFromTray(); };
            _trayMenu.Items.Add(open);

            _trayEndGame = new ToolStripMenuItem("结束当前进程");
            _trayEndGame.Click += delegate { EndGameFromTray("托盘"); };
            _trayMenu.Items.Add(_trayEndGame);

            _trayMenu.Items.Add(new ToolStripSeparator());
            ToolStripMenuItem exit = new ToolStripMenuItem("彻底关闭");
            exit.ForeColor = Theme.Danger;
            exit.Click += delegate { ExitFromTray(); };
            _trayMenu.Items.Add(exit);
            _trayIcon.ContextMenuStrip = _trayMenu;

            _trayMenu.Opening += delegate
            {
                GameProfile profile = _config.GetSelectedProfile();
                _trayDirectLaunch.Text = "直接启动" + (profile != null ? " · " + profile.Name : string.Empty) +
                    (_config.LaunchWithDlls ? " · 带 DLL" : " · 仅启动");
                _trayDirectLaunch.Enabled = !_busy;
                _trayEndGame.Enabled = !_busy && GameLauncher.IsGameRunning();
            };

            _trayIcon.MouseClick += delegate(object sender, MouseEventArgs e)
            {
                if (e.Button == MouseButtons.Left) RestoreFromTray();
            };
            _trayIcon.DoubleClick += delegate { RestoreFromTray(); };
        }

        private void HideToTray()
        {
            if (_trayIcon == null) return;
            _trayIcon.Visible = true;
            Hide();
            ShowTrayNotice("已隐藏到系统托盘：左键打开，右键可彻底关闭");
        }

        private void ShowTrayNotice(string message)
        {
            if (IsDisposed || string.IsNullOrEmpty(message)) return;
            if (_trayNotice != null)
            {
                try { _trayNotice.Close(); } catch { }
                _trayNotice = null;
            }
            _trayNotice = new TrayNotice(message);
            _trayNotice.FormClosed += delegate { _trayNotice = null; };
            _trayNotice.Show();
        }

        private void RestoreFromTray()
        {
            if (_trayIcon != null) _trayIcon.Visible = false;
            if (_trayNotice != null)
            {
                try { _trayNotice.Close(); } catch { }
                _trayNotice = null;
            }
            Show();
            ShowInTaskbar = true;
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Activate();
            BringToFront();
        }

        private void ExitFromTray()
        {
            _skipCloseBehavior = true;
            if (_trayIcon != null) _trayIcon.Visible = false;
            Close();
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            base.OnVisibleChanged(e);
            if (Visible && _trayIcon != null) _trayIcon.Visible = false;
        }

        private void MainFormShown(object sender, EventArgs e)
        {
            Native.ClearTopMost(Handle);
            Native.EnableFileDrop(Handle);
            ApplyRoundedRegion();
            SwitchPage(_page);
            Native.ApplyDarkTheme(_dllList.Handle);
            Native.ApplyDarkTheme(_pageSettings.Handle);
            if (_logView != null) Native.ApplyDarkTheme(_logView.Handle);
            if (_firstRun)
            {
                if (_page == PageKind.Launch)
                    ShowToast("首次运行：已创建 STEVE CLIENT 总文件夹，请手动导入 DLL", ToastKind.Success);
                if (_dlls.Count == 0 && _page == PageKind.Launch)
                {
                    // Keep the launcher usable, but make the next action obvious.
                    SwitchPage(PageKind.Modules);
                }
            }
            else if (_dlls.Count == 0 && _page == PageKind.Launch)
            {
                ShowToast("DLLs 文件夹还是空的，点击“添加 DLL”开始", ToastKind.Info);
            }
            else if (!IsGameAvailable())
            {
                ShowToast("当前游戏档案不可用，请到“游戏档案”检查启动路径", ToastKind.Warning);
            }

            if (_autoLaunch)
            {
                _autoLaunch = false;
                BeginInvoke(new Action(AutoLaunch));
            }
        }

        private async void AutoLaunch()
        {
            await Task.Delay(600);
            await StartGameAsync();
        }

        private void MainFormClosing(object sender, FormClosingEventArgs e)
        {
            if (_closeAfterImport) _skipCloseBehavior = true;
            if (_importing && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                bool cancelImport = DialogForm.Confirm(this, "正在导入资源",
                    "资源仍在导入中。\n\n是否取消本次导入并退出启动器？\n" +
                    "已经完成安装的资源会保留。", "取消导入并退出");
                if (cancelImport)
                {
                    _closeAfterImport = true;
                    if (_importCts != null)
                    {
                        try { _importCts.Cancel(); } catch { }
                    }
                    ShowToast("正在取消导入，完成后会自动退出", ToastKind.Warning);
                }
                return;
            }
            if (_busy && e.CloseReason == CloseReason.UserClosing)
            {
                bool keepInjecting = DialogForm.Show(this, "正在注入",
                    "游戏启动或注入尚未完成。\n\n" +
                    "选择“继续注入”会把启动器最小化并在后台完成注入；\n" +
                    "选择“退出”会取消本次注入。",
                    DialogKind.Question, "继续注入", "退出", true);
                if (keepInjecting)
                {
                    e.Cancel = true;
                    WindowState = FormWindowState.Minimized;
                    Log.Info("窗口关闭请求已转为后台注入，注入将继续");
                    return;
                }
                _skipCloseBehavior = true;
            }

            if (!_skipCloseBehavior && e.CloseReason == CloseReason.UserClosing)
            {
                if (!_config.CloseBehaviorAsked)
                {
                    int choice = DialogForm.Choose(this, "关闭启动器",
                        "点击右上角关闭按钮时，希望启动器如何处理？\n\n" +
                        "· 隐藏到系统托盘：启动器进入任务栏通知区域，左键托盘图标恢复，右键可打开或彻底关闭；\n" +
                        "· 直接关闭：退出启动器。\n\n" +
                        "之后可以在 设置 → 关闭窗口时隐藏到系统托盘 中修改。",
                        "隐藏到托盘", "直接关闭", "取消");
                    if (choice == 0)
                    {
                        e.Cancel = true;
                        return;
                    }
                    _config.HideToTrayOnClose = choice == 1;
                    _config.CloseBehaviorAsked = true;
                    _config.Save(AppPaths.ConfigFile);
                    if (_hideToTrayToggle != null)
                        _hideToTrayToggle.SetCheckedSilent(_config.HideToTrayOnClose);
                }

                if (_config.HideToTrayOnClose)
                {
                    e.Cancel = true;
                    HideToTray();
                    return;
                }
            }
            _skipCloseBehavior = false;
            try { if (_cts != null) _cts.Cancel(); } catch { }
            UnregisterConfiguredHotkey(HotkeyTarget.Inject);
            UnregisterConfiguredHotkey(HotkeyTarget.Launch);
            UnregisterConfiguredHotkey(HotkeyTarget.Close);
            if (_watcher != null) _watcher.Dispose();
            if (_watchTimer != null) _watchTimer.Dispose();
            if (_gameWatchTimer != null) _gameWatchTimer.Dispose();
            if (_restoreRepaintTimer != null) _restoreRepaintTimer.Dispose();
            if (_trayIcon != null)
            {
                _trayIcon.Visible = false;
                _trayIcon.Dispose();
                _trayIcon = null;
            }
            if (_trayMenu != null)
            {
                _trayMenu.Dispose();
                _trayMenu = null;
            }
            if (_trayNotice != null)
            {
                try { _trayNotice.Close(); } catch { }
                _trayNotice = null;
            }
            if (_logoImage != null) _logoImage.Dispose();
            _tooltip.Dispose();
        }

        private void BuildInterface()
        {
            _root = new BufferedPanel();
            _root.Dock = DockStyle.Fill;
            _root.BackColor = Theme.Bg;
            _root.Resize += delegate { LayoutChrome(); };
            Controls.Add(_root);

            _workspace = new BufferedPanel();
            _workspace.BackColor = Theme.Bg;
            _root.Controls.Add(_workspace);

            _sidebar = new BufferedPanel();
            _sidebar.BackColor = Theme.Sidebar;
            _sidebar.Paint += SidebarPaint;
            _root.Controls.Add(_sidebar);

            _pageHost = new BufferedPanel();
            _pageHost.BackColor = Theme.Bg;
            _workspace.Controls.Add(_pageHost);

            _titlebar = new BufferedPanel();
            _titlebar.Height = Theme.S(44f);
            _titlebar.BackColor = Theme.Bg;
            _titlebar.Paint += TitlebarPaint;
            _titlebar.MouseDown += DragWindow;
            _workspace.Controls.Add(_titlebar);

            BuildSidebar();
            BuildTitlebarButtons();
            BuildLaunchPage();
            BuildProfilesPage();
            BuildModulesPage();
            BuildResourcesPage();
            BuildSettingsPage();

            _toast = new Toast();
            Controls.Add(_toast);
            _toast.BringToFront();
            LayoutChrome();
        }

        private void LayoutChrome()
        {
            if (_root == null || _sidebar == null || _workspace == null) return;
            int sidebarWidth = Theme.S(206f);
            int titleHeight = Theme.S(44f);
            _sidebar.Bounds = new Rectangle(0, 0, sidebarWidth, _root.ClientSize.Height);
            _workspace.Bounds = new Rectangle(sidebarWidth, 0,
                Math.Max(0, _root.ClientSize.Width - sidebarWidth), _root.ClientSize.Height);
            _titlebar.Bounds = new Rectangle(0, 0, _workspace.ClientSize.Width, titleHeight);
            _pageHost.Bounds = new Rectangle(0, titleHeight,
                _workspace.ClientSize.Width, Math.Max(0, _workspace.ClientSize.Height - titleHeight));
            LayoutTitlebarButtons();
        }

        private void BuildSidebar()
        {
            _sidebar.MouseMove += SidebarMouseMove;
            _sidebar.MouseLeave += delegate
            {
                if (_hoverNav != -1)
                {
                    _hoverNav = -1;
                    _sidebar.Cursor = Cursors.Default;
                    _sidebar.Invalidate();
                }
            };
            _sidebar.MouseClick += delegate(object sender, MouseEventArgs e)
            {
                if (e.Button != MouseButtons.Left) return;
                int index = HitTestNav(e.Location);
                if (index >= 0) SwitchPage((PageKind)index);
            };
        }

        private RectangleF GetNavRect(int index)
        {
            return new RectangleF(Theme.SF(14f), Theme.SF(120f + index * 38f),
                _sidebar.Width - Theme.SF(28f), Theme.SF(34f));
        }

        private int HitTestNav(Point location)
        {
            for (int i = 0; i < NavNames.Length; i++)
                if (GetNavRect(i).Contains(location)) return i;
            return -1;
        }

        private void SidebarMouseMove(object sender, MouseEventArgs e)
        {
            int index = HitTestNav(e.Location);
            if (index != _hoverNav)
            {
                _hoverNav = index;
                _sidebar.Cursor = index >= 0 ? Cursors.Hand : Cursors.Default;
                _sidebar.Invalidate();
            }
        }

        private void SidebarPaint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            using (LinearGradientBrush b = new LinearGradientBrush(new Rectangle(0, 0, _sidebar.Width, _sidebar.Height),
                Theme.Sidebar, Theme.Sidebar2, 90f))
                g.FillRectangle(b, _sidebar.ClientRectangle);
            using (SolidBrush glow = new SolidBrush(Color.FromArgb(28, Theme.Accent)))
                g.FillEllipse(glow, -Theme.S(100f), -Theme.S(120f), Theme.S(330f), Theme.S(300f));

            // Logo mark: use the same Steve head icon as the executable.
            float logoSize = Theme.SF(34f);
            RectangleF logo = new RectangleF(Theme.SF(20f), Theme.SF(23f), logoSize, logoSize);
            if (_logoImage != null)
            {
                g.DrawImage(_logoImage, logo);
            }
            else
            {
                using (GraphicsPath path = Theme.RoundRect(logo, Theme.SF(9f)))
                using (LinearGradientBrush b = new LinearGradientBrush(logo, Theme.Accent, Theme.Accent2, 45f))
                    g.FillPath(b, path);
                using (SolidBrush b = new SolidBrush(Color.FromArgb(235, 255, 255, 255)))
                {
                    float u = logoSize * 0.44f;
                    float cx = logo.X + logoSize / 2f;
                    float cy = logo.Y + logoSize / 2f;
                    PointF[] pts = {
                        new PointF(cx, cy - u*0.62f),
                        new PointF(cx + u*0.62f, cy),
                        new PointF(cx, cy + u*0.62f),
                        new PointF(cx - u*0.62f, cy)
                    };
                    g.FillPolygon(b, pts);
                }
            }
            using (SolidBrush b = new SolidBrush(Theme.Text))
            {
                Font nameFont = Theme.Display(20f, FontStyle.Bold);
                float brandCenter = Theme.SF(92f);
                g.DrawString("STEVE", nameFont, b,
                    new RectangleF(brandCenter - Theme.SF(62f), Theme.SF(23f), Theme.SF(124f), Theme.SF(30f)), Theme.Center);

                Font clientFont = Theme.Ui(8f, FontStyle.Bold);
                float clientSpacing = Theme.SF(2.4f);
                float clientWidth = Theme.MeasureSpaced(g, "CLIENT", clientFont, clientSpacing);
                Theme.DrawSpaced(g, "CLIENT", clientFont, Theme.AccentLight,
                    brandCenter - clientWidth / 2f, Theme.SF(49f), clientSpacing);

                Font versionFont = Theme.Ui(8.2f);
                using (SolidBrush vb = new SolidBrush(Theme.Muted2))
                    g.DrawString("v" + Theme.Version, versionFont, vb,
                        new RectangleF(brandCenter - Theme.SF(40f), Theme.SF(61f), Theme.SF(80f), Theme.SF(18f)),
                        Theme.Center);
            }

            using (SolidBrush b = new SolidBrush(Theme.Muted2))
                g.DrawString("导航", Theme.Ui(8.6f, FontStyle.Bold), b,
                    new RectangleF(Theme.SF(18f), Theme.SF(94f), Theme.SF(100f), Theme.SF(18f)), Theme.LeftCenter);

            for (int i = 0; i < NavNames.Length; i++)
            {
                RectangleF rect = GetNavRect(i);
                bool selected = (int)_page == i;
                bool hover = _hoverNav == i;
                if (selected || hover)
                {
                    Color fill = selected ? Theme.Alpha(Theme.Accent, 28) : Theme.Alpha(Theme.Surface2, 150);
                    using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(9f)))
                    using (SolidBrush b = new SolidBrush(fill))
                        g.FillPath(b, path);
                }
                if (selected)
                {
                    using (GraphicsPath path = Theme.RoundRect(
                        new RectangleF(rect.X, rect.Y + Theme.SF(9f), Theme.SF(3f), rect.Height - Theme.SF(18f)), Theme.SF(1.5f)))
                    using (SolidBrush b = new SolidBrush(Theme.Accent))
                        g.FillPath(b, path);
                }

                float iconSize = Theme.SF(16f);
                Color iconColor = selected ? Theme.AccentLight : (hover ? Theme.TextSoft : Theme.Muted);
                PillButton.DrawGlyph(g, NavGlyphs[i],
                    new RectangleF(rect.X + Theme.SF(15f), rect.Y + (rect.Height - iconSize) / 2f, iconSize, iconSize),
                    iconColor, 1.5f);
                Color textColor = selected ? Theme.Text : (hover ? Theme.TextSoft : Theme.Muted);
                using (SolidBrush b = new SolidBrush(textColor))
                    g.DrawString(NavNames[i], selected ? Theme.Ui(12.5f, FontStyle.Bold) : Theme.Ui(12.5f),
                        b, new RectangleF(rect.X + Theme.SF(42f), rect.Y, rect.Width - Theme.SF(48f), rect.Height),
                        Theme.LeftCenter);
            }

            using (Pen pen = new Pen(Theme.BorderSoft, 1f))
                g.DrawLine(pen, 0, Theme.S(350f), _sidebar.Width, Theme.S(350f));

            using (SolidBrush b = new SolidBrush(Theme.Muted2))
                g.DrawString("状态", Theme.Ui(8.6f, FontStyle.Bold), b,
                    new RectangleF(Theme.SF(18f), Theme.SF(362f), Theme.SF(100f), Theme.SF(18f)), Theme.LeftCenter);

            float cardY = Theme.SF(386f);
            RectangleF card = new RectangleF(Theme.SF(14f), cardY, _sidebar.Width - Theme.SF(28f), Theme.SF(68f));
            using (GraphicsPath path = Theme.RoundRect(card, Theme.SF(10f)))
            using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Surface2, 190)))
                g.FillPath(b, path);
            using (Pen pen = new Pen(Theme.BorderSoft, 1f))
            using (GraphicsPath path = Theme.RoundRect(card, Theme.SF(10f)))
                g.DrawPath(pen, path);
            bool gameAvailable = IsGameAvailable();
            GameProfile sidebarProfile = _config.GetSelectedProfile();
            bool customLaunch = sidebarProfile != null && !sidebarProfile.IsOfficial;
            Color dotColor = gameAvailable ? Theme.Success : Theme.Warning;
            using (SolidBrush b = new SolidBrush(dotColor))
                g.FillEllipse(b, card.X + Theme.SF(13f), card.Y + Theme.SF(17f), Theme.SF(7f), Theme.SF(7f));
            string sidebarTitle;
            string sidebarSubtitle;
            if (!gameAvailable)
            {
                sidebarTitle = customLaunch ? "档案不可用" : "未检测到游戏";
                sidebarSubtitle = customLaunch ? "启动路径不存在" : "请先安装";
            }
            else if (customLaunch)
            {
                sidebarTitle = sidebarProfile.Name;
                sidebarSubtitle = "当前游戏档案";
            }
            else
            {
                sidebarTitle = "Minecraft 已安装";
                sidebarSubtitle = "v" + _minecraft.Version;
            }
            using (SolidBrush b = new SolidBrush(Theme.TextSoft))
                g.DrawString(sidebarTitle, Theme.Ui(9.6f, FontStyle.Bold), b,
                    new RectangleF(card.X + Theme.SF(27f), card.Y + Theme.SF(9f), card.Width - Theme.SF(34f), Theme.SF(22f)), Theme.LeftCenter);
            using (SolidBrush b = new SolidBrush(Theme.Muted2))
                g.DrawString(sidebarSubtitle, Theme.Ui(8.8f), b,
                    new RectangleF(card.X + Theme.SF(27f), card.Y + Theme.SF(30f), card.Width - Theme.SF(34f), Theme.SF(18f)), Theme.LeftCenter);
            using (SolidBrush b = new SolidBrush(Theme.Muted2))
                g.DrawString(_activityText, Theme.Ui(8.5f), b,
                    new RectangleF(card.X + Theme.SF(27f), card.Y + Theme.SF(48f), card.Width - Theme.SF(34f), Theme.SF(16f)), Theme.LeftCenter);

            int bottom = _sidebar.Height - Theme.S(16f);
            using (Pen pen = new Pen(Theme.BorderSoft, 1f))
                g.DrawLine(pen, Theme.S(18f), bottom - Theme.S(58f), _sidebar.Width - Theme.S(18f), bottom - Theme.S(58f));
            float shield = Theme.SF(13f);
            PillButton.DrawGlyph(g, IconGlyph.Shield, new RectangleF(Theme.SF(20f), bottom - Theme.SF(40f), shield, shield),
                _admin ? Theme.Success : Theme.Warning, 1.3f);
            using (SolidBrush b = new SolidBrush(_admin ? Theme.TextSoft : Theme.Warning))
                g.DrawString(_admin ? "管理员权限" : "标准权限", Theme.Ui(9.2f), b,
                    new RectangleF(Theme.SF(40f), bottom - Theme.SF(44f), Theme.SF(140f), Theme.SF(18f)), Theme.LeftCenter);
            using (SolidBrush b = new SolidBrush(Theme.Muted2))
                g.DrawString("STEVE CLIENT · " + Theme.BuildDate, Theme.Ui(8f), b,
                    new RectangleF(Theme.SF(20f), bottom - Theme.SF(22f), _sidebar.Width - Theme.SF(30f), Theme.SF(16f)), Theme.LeftCenter);
        }

        private void BuildTitlebarButtons()
        {
            _minButton = new IconButton();
            _minButton.Glyph = IconGlyph.Minimize;
            _minButton.Size = new Size(Theme.S(36f), Theme.S(28f));
            _minButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _minButton.Location = new Point(_titlebar.Width - Theme.S(84f), Theme.S(8f));
            _minButton.Click += delegate { WindowState = FormWindowState.Minimized; };
            _titlebar.Controls.Add(_minButton);

            _closeButton = new IconButton();
            _closeButton.Glyph = IconGlyph.Close;
            _closeButton.CloseStyle = true;
            _closeButton.Size = new Size(Theme.S(36f), Theme.S(28f));
            _closeButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _closeButton.Location = new Point(_titlebar.Width - Theme.S(46f), Theme.S(8f));
            _closeButton.Click += delegate { Close(); };
            _titlebar.Controls.Add(_closeButton);

            _tooltip.SetToolTip(_minButton, "最小化");
            _tooltip.SetToolTip(_closeButton, "关闭");
            _titlebar.Resize += delegate { LayoutTitlebarButtons(); };
            LayoutTitlebarButtons();
        }

        private void LayoutTitlebarButtons()
        {
            if (_titlebar == null || _minButton == null || _closeButton == null) return;
            _closeButton.Location = new Point(_titlebar.Width - Theme.S(46f), Theme.S(8f));
            _minButton.Location = new Point(_closeButton.Left - Theme.S(38f), Theme.S(8f));
        }

        private void TitlebarPaint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            float x = Theme.SF(24f);
            Font consoleFont = Theme.Ui(9.6f);
            Font slashFont = Theme.Ui(9.4f);
            SizeF consoleSize = g.MeasureString("控制台", consoleFont);
            using (SolidBrush b = new SolidBrush(Theme.Muted2))
                g.DrawString("控制台", consoleFont, b,
                    new RectangleF(x, 0, consoleSize.Width + Theme.SF(2f), _titlebar.Height), LeftCenter());
            x += consoleSize.Width + Theme.SF(6f);
            SizeF slashSize = g.MeasureString("/", slashFont);
            using (SolidBrush b = new SolidBrush(Theme.Muted2))
                g.DrawString("/", slashFont, b,
                    new RectangleF(x, 0, slashSize.Width + Theme.SF(2f), _titlebar.Height), LeftCenter());
            x += slashSize.Width + Theme.SF(6f);
            using (SolidBrush b = new SolidBrush(Theme.Text))
                g.DrawString(_breadcrumb, Theme.Ui(9.8f, FontStyle.Bold), b,
                    new RectangleF(x, 0, Theme.SF(180f), _titlebar.Height), LeftCenter());

            Font statusFont = Theme.Ui(9.2f);
            Size statusTextSize = TextRenderer.MeasureText(_statusText, statusFont);
            float statusDot = Theme.SF(6f);
            float statusGap = Theme.SF(7f);
            float statusContentWidth = statusDot + statusGap + statusTextSize.Width;
            float badgeW = Math.Max(Theme.SF(98f), statusContentWidth + Theme.SF(20f));
            float badgeH = Theme.SF(25f);
            RectangleF badge = new RectangleF(_titlebar.Width - Theme.S(154f) - badgeW, (_titlebar.Height - badgeH) / 2f, badgeW, badgeH);
            using (GraphicsPath path = Theme.RoundRect(badge, badgeH / 2f))
            using (SolidBrush b = new SolidBrush(Theme.Alpha(_statusColor, 20)))
                g.FillPath(b, path);
            using (Pen pen = new Pen(Theme.Alpha(_statusColor, 65), 1f))
            using (GraphicsPath path = Theme.RoundRect(badge, badgeH / 2f))
                g.DrawPath(pen, path);

            float contentX = badge.X + (badge.Width - statusContentWidth) / 2f;
            using (SolidBrush b = new SolidBrush(_statusColor))
                g.FillEllipse(b, contentX, badge.Y + badge.Height / 2f - statusDot / 2f, statusDot, statusDot);
            using (SolidBrush b = new SolidBrush(_statusColor))
                g.DrawString(_statusText, statusFont, b,
                    new RectangleF(contentX + statusDot + statusGap, badge.Y,
                        statusTextSize.Width + Theme.SF(2f), badge.Height), LeftCenter());

            using (Pen pen = new Pen(Theme.BorderSoft, 1f))
                g.DrawLine(pen, 0, _titlebar.Height - 1, _titlebar.Width, _titlebar.Height - 1);
        }

        private static StringFormat LeftCenter()
        {
            StringFormat sf = new StringFormat(StringFormat.GenericTypographic);
            sf.Alignment = StringAlignment.Near;
            sf.LineAlignment = StringAlignment.Center;
            sf.Trimming = StringTrimming.EllipsisCharacter;
            sf.FormatFlags |= StringFormatFlags.NoWrap;
            return sf;
        }

        private void DragWindow(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Native.ReleaseCapture();
                Native.SendMessage(Handle, Native.WM_NCLBUTTONDOWN, (IntPtr)Native.HTCAPTION, IntPtr.Zero);
            }
        }

        private void BuildLaunchPage()
        {
            _pageLaunch = new BufferedPanel();
            _pageLaunch.Dock = DockStyle.Fill;
            _pageLaunch.BackColor = Theme.Bg;
            _pageLaunch.Resize += delegate { LayoutLaunchPage(); };
            _pageHost.Controls.Add(_pageLaunch);

            _launchHeader = new PageHeader();
            _launchHeader.Text = "启动中心";
            _launchHeader.Subtitle = "一键启动 Minecraft for Windows，并在游戏窗口出现后自动注入全部模块。";
            _launchHeader.Location = new Point(Theme.S(26f), Theme.S(12f));
            _launchHeader.Size = new Size(Theme.S(760f), Theme.S(66f));
            _launchHeader.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            _pageLaunch.Controls.Add(_launchHeader);

            _launchBadge = new Badge();
            _launchBadge.Size = new Size(Theme.S(96f), Theme.S(26f));
            _launchBadge.Location = new Point(_pageLaunch.Width - Theme.S(122f), Theme.S(22f));
            _launchBadge.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _launchBadge.SetData("就绪", Theme.Success, Theme.Alpha(Theme.Success, 20), Theme.Alpha(Theme.Success, 70));
            _pageLaunch.Controls.Add(_launchBadge);

            _hero = new HeroCard();
            _hero.LaunchRequested += async delegate { await StartGameAsync(); };
            _hero.EndGameRequested += delegate { EndRunningGame(); };
            _pageLaunch.Controls.Add(_hero);

            _statModules = new StatCard();
            _statModules.SetData("已启用模块", "0 / 0", "等待添加 DLL", IconGlyph.Puzzle, Theme.Accent);
            _pageLaunch.Controls.Add(_statModules);

            _statGame = new StatCard();
            _statGame.SetData("游戏状态", "未运行", "Minecraft Bedrock", IconGlyph.Cube, Theme.Accent2);
            _pageLaunch.Controls.Add(_statGame);

            _statPermission = new StatCard();
            _statPermission.SetData("运行权限", _admin ? "管理员" : "标准", _admin ? "可以进行进程注入" : "建议管理员运行", IconGlyph.Shield, _admin ? Theme.Success : Theme.Warning);
            _pageLaunch.Controls.Add(_statPermission);

            _moduleStrip = new ModuleStrip();
            _moduleStrip.Click += delegate { SwitchPage(PageKind.Modules); };
            _pageLaunch.Controls.Add(_moduleStrip);

            _launchPathCard = new RoundedPanel();
            _launchPathCard.Radius = 13;
            _launchPathCard.BackColor = Theme.Surface;
            _pageLaunch.Controls.Add(_launchPathCard);

            _launchPathCaption = MakeLabel("启动档案", Theme.Ui(8.6f, FontStyle.Bold), Theme.Muted2, Theme.Surface);
            _launchPathCard.Controls.Add(_launchPathCaption);

            _launchPathValue = MakeLabel(string.Empty, Theme.Mono(8.8f), Theme.TextSoft, Theme.Surface);
            _launchPathCard.Controls.Add(_launchPathValue);

            _launchPathBrowseButton = new PillButton();
            _launchPathBrowseButton.Text = "切换";
            _launchPathBrowseButton.Icon = IconGlyph.ChevronDown;
            _launchPathBrowseButton.Font = Theme.Ui(9.2f, FontStyle.Bold);
            _launchPathBrowseButton.Size = new Size(Theme.S(92f), Theme.S(30f));
            _launchPathBrowseButton.Click += delegate { ShowLaunchProfileMenu(); };
            _launchPathCard.Controls.Add(_launchPathBrowseButton);

            _launchPathResetButton = new PillButton();
            _launchPathResetButton.Text = "管理";
            _launchPathResetButton.Icon = IconGlyph.Settings;
            _launchPathResetButton.Font = Theme.Ui(9.2f, FontStyle.Bold);
            _launchPathResetButton.Size = new Size(Theme.S(76f), Theme.S(30f));
            _launchPathResetButton.Click += delegate { SwitchPage(PageKind.Profiles); };
            _launchPathCard.Controls.Add(_launchPathResetButton);

            TextLabel note = MakeLabel("所有 DLL 仅在本机加载；注入第三方模块前请确认来源可信。热键 " +
                _config.InjectHotkey + " 可注入运行中的游戏。",
                Theme.Ui(8.8f), Theme.Muted2);
            _launchFooterNote = note;
            note.Location = new Point(Theme.S(28f), Theme.S(608f));
            note.Size = new Size(Theme.S(700f), Theme.S(18f));
            note.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            _pageLaunch.Controls.Add(note);
            LayoutLaunchPage();
            UpdateLaunchPathUi();
        }

        private void LayoutLaunchPage()
        {
            if (_hero == null || _launchHeader == null || _launchPathCard == null) return;
            int pad = Theme.S(26f);
            int width = Math.Max(Theme.S(500f), _pageLaunch.ClientSize.Width - pad * 2);
            _launchHeader.Bounds = new Rectangle(pad, Theme.S(12f), width, Theme.S(66f));
            int header = Theme.S(84f);
            int heroH = Theme.S(232f);
            _hero.Bounds = new Rectangle(pad, header, width, heroH);

            int gap = Theme.S(12f);
            int statsY = _hero.Bottom + gap;
            int statsH = Theme.S(76f);
            int statW = (width - gap * 2) / 3;
            _statModules.Bounds = new Rectangle(pad, statsY, statW, statsH);
            _statGame.Bounds = new Rectangle(pad + statW + gap, statsY, statW, statsH);
            _statPermission.Bounds = new Rectangle(pad + (statW + gap) * 2, statsY, statW, statsH);

            int stripY = statsY + statsH + gap;
            _moduleStrip.Bounds = new Rectangle(pad, stripY, width, Theme.S(78f));

            int pathY = stripY + Theme.S(78f) + gap;
            _launchPathCard.Bounds = new Rectangle(pad, pathY, width, Theme.S(64f));
            int pathRight = width - Theme.S(16f);
            _launchPathResetButton.Location = new Point(pathRight - _launchPathResetButton.Width, Theme.S(17f));
            _launchPathBrowseButton.Location = new Point(_launchPathResetButton.Left - Theme.S(8f) - _launchPathBrowseButton.Width, Theme.S(17f));
            int pathTextWidth = Math.Max(Theme.S(160f),
                _launchPathBrowseButton.Left - Theme.S(16f) - Theme.S(12f));
            _launchPathCaption.Location = new Point(Theme.S(16f), Theme.S(8f));
            _launchPathCaption.Size = new Size(pathTextWidth, Theme.S(16f));
            _launchPathValue.Location = new Point(Theme.S(16f), Theme.S(26f));
            _launchPathValue.Size = new Size(pathTextWidth, Theme.S(24f));

            if (_launchBadge != null)
                _launchBadge.Location = new Point(_pageLaunch.ClientSize.Width - pad - _launchBadge.Width, Theme.S(22f));
            foreach (Control c in _pageLaunch.Controls)
            {
                TextLabel label = c as TextLabel;
                if (label != null && label.Text.StartsWith("所有 DLL"))
                {
                    label.Location = new Point(pad + Theme.S(2f), _pageLaunch.ClientSize.Height - Theme.S(28f));
                }
            }
        }

        private void BuildProfilesPage()
        {
            _pageProfiles = new BufferedPanel();
            _pageProfiles.Dock = DockStyle.Fill;
            _pageProfiles.BackColor = Theme.Bg;
            _pageProfiles.Resize += delegate { LayoutProfilesPage(); };
            _pageHost.Controls.Add(_pageProfiles);

            _profilesHeader = new PageHeader();
            _profilesHeader.Text = "游戏档案";
            _profilesHeader.Subtitle = "为不同版本或启动程序创建档案；启动中心会使用当前选中的档案。";
            _profilesHeader.Location = new Point(Theme.S(26f), Theme.S(12f));
            _profilesHeader.Size = new Size(Theme.S(760f), Theme.S(66f));
            _profilesHeader.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            _pageProfiles.Controls.Add(_profilesHeader);

            _profileToolbar = new RoundedPanel();
            _profileToolbar.Radius = 13;
            _profileToolbar.BackColor = Theme.Surface;
            _pageProfiles.Controls.Add(_profileToolbar);

            _profileCountLabel = MakeLabel("共 0 个档案", Theme.Ui(10f, FontStyle.Bold), Theme.TextSoft, Theme.Surface);
            _profileToolbar.Controls.Add(_profileCountLabel);

            _profileHintLabel = MakeLabel("选择档案后，启动中心会使用该档案的启动方式。",
                Theme.Ui(8.6f), Theme.Muted2, Theme.Surface);
            _profileToolbar.Controls.Add(_profileHintLabel);

            _batchProfilesButton = new PillButton();
            _batchProfilesButton.Text = "批量管理";
            _batchProfilesButton.Icon = IconGlyph.Check;
            _batchProfilesButton.CornerRadius = 8f;
            _batchProfilesButton.Font = Theme.Ui(9f, FontStyle.Bold);
            _batchProfilesButton.Size = new Size(Theme.S(92f), Theme.S(32f));
            _batchProfilesButton.Click += delegate { ToggleProfileBatch(); };
            _profileToolbar.Controls.Add(_batchProfilesButton);

            _importProfilesButton = new PillButton();
            _importProfilesButton.Text = "导入";
            _importProfilesButton.Icon = IconGlyph.Download;
            _importProfilesButton.CornerRadius = 8f;
            _importProfilesButton.Font = Theme.Ui(9f, FontStyle.Bold);
            _importProfilesButton.Size = new Size(Theme.S(78f), Theme.S(32f));
            _importProfilesButton.Click += delegate { ImportGameProfiles(); };
            _profileToolbar.Controls.Add(_importProfilesButton);

            _exportProfilesButton = new PillButton();
            _exportProfilesButton.Text = "导出";
            _exportProfilesButton.Icon = IconGlyph.Upload;
            _exportProfilesButton.CornerRadius = 8f;
            _exportProfilesButton.Font = Theme.Ui(9f, FontStyle.Bold);
            _exportProfilesButton.Size = new Size(Theme.S(78f), Theme.S(32f));
            _exportProfilesButton.Click += delegate { ExportGameProfiles(); };
            _profileToolbar.Controls.Add(_exportProfilesButton);

            _addProfileButton = new PillButton();
            _addProfileButton.Text = "新增档案";
            _addProfileButton.Icon = IconGlyph.Plus;
            _addProfileButton.Primary = true;
            _addProfileButton.Font = Theme.Ui(9.2f, FontStyle.Bold);
            _addProfileButton.Size = new Size(Theme.S(112f), Theme.S(32f));
            _addProfileButton.Click += delegate { AddGameProfile(); };
            _profileToolbar.Controls.Add(_addProfileButton);

            _profileListHost = new ProfileListPanel();
            _profileListHost.SelectRequested += delegate(GameProfile profile) { SelectGameProfile(profile); };
            _profileListHost.RemoveRequested += delegate(GameProfile profile) { RemoveGameProfile(profile); };
            _profileListHost.SelectionChanged += delegate { UpdateProfileBatchCount(); };
            _pageProfiles.Controls.Add(_profileListHost);

            _profileBatchBar = new BatchBar();
            _profileBatchBar.Visible = false;
            _profileBatchBar.AddAction("全选", IconGlyph.Check, 76, delegate { _profileListHost.SelectAll(true); });
            _profileBatchBar.AddAction("清空", IconGlyph.Close, 76, delegate { _profileListHost.SelectAll(false); });
            _profileBatchBar.AddAction("删除选中", IconGlyph.Trash, 100, delegate { DeleteSelectedProfiles(); });
            _pageProfiles.Controls.Add(_profileBatchBar);

            _profilesFooter = MakeLabel("官方档案固定存在，不能删除；选择档案后启动中心会使用它。",
                Theme.Ui(8.9f), Theme.Muted2);
            _profilesFooter.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            _pageProfiles.Controls.Add(_profilesFooter);

            LayoutProfilesPage();
            RefreshProfileList();
        }

        private void LayoutProfilesPage()
        {
            if (_pageProfiles == null || _profilesHeader == null || _profileToolbar == null) return;
            int pad = Theme.S(26f);
            int width = Math.Max(Theme.S(560f), _pageProfiles.ClientSize.Width - pad * 2);
            _profilesHeader.Bounds = new Rectangle(pad, Theme.S(12f), width, Theme.S(66f));

            _profileToolbar.Bounds = new Rectangle(pad, Theme.S(84f), width, Theme.S(58f));
            _profileCountLabel.Location = new Point(Theme.S(18f), Theme.S(8f));
            _profileHintLabel.Location = new Point(Theme.S(18f), Theme.S(29f));

            int buttonY = Theme.S(13f);
            int buttonGap = Theme.S(8f);
            _addProfileButton.Location = new Point(_profileToolbar.Width - Theme.S(18f) - _addProfileButton.Width,
                buttonY);
            _exportProfilesButton.Location = new Point(_addProfileButton.Left - buttonGap - _exportProfilesButton.Width,
                buttonY);
            _importProfilesButton.Location = new Point(_exportProfilesButton.Left - buttonGap - _importProfilesButton.Width,
                buttonY);
            _batchProfilesButton.Location = new Point(_importProfilesButton.Left - buttonGap - _batchProfilesButton.Width,
                buttonY);
            int labelWidth = Math.Max(Theme.S(150f), _batchProfilesButton.Left - Theme.S(30f));
            _profileCountLabel.Size = new Size(labelWidth, Theme.S(20f));
            _profileHintLabel.Size = new Size(labelWidth, Theme.S(18f));

            int listY = _profileToolbar.Bottom + Theme.S(10f);
            if (_profileBatchBar != null && _profileBatchBar.Visible)
            {
                _profileBatchBar.Bounds = new Rectangle(pad, listY, width, Theme.S(46f));
                _profileBatchBar.LayoutBar(width);
                listY = _profileBatchBar.Bottom + Theme.S(8f);
            }
            _profileListHost.Bounds = new Rectangle(pad, listY, Math.Max(Theme.S(300f), width),
                Math.Max(Theme.S(160f), _pageProfiles.ClientSize.Height - listY - Theme.S(42f)));
            _profilesFooter.Location = new Point(pad + Theme.S(2f), _pageProfiles.ClientSize.Height - Theme.S(27f));
            _profilesFooter.Size = new Size(Math.Max(Theme.S(300f), width), Theme.S(18f));
        }

        private void ToggleProfileBatch()
        {
            _profileBatchMode = !_profileBatchMode;
            if (_profileBatchMode && _config.Profiles.Count <= 1)
            {
                _profileBatchMode = false;
                ShowToast("没有可批量管理的自定义档案", ToastKind.Info);
                return;
            }
            _profileBatchBar.Visible = _profileBatchMode;
            _profileListHost.SetBatchMode(_profileBatchMode);
            _batchProfilesButton.Text = _profileBatchMode ? "退出批量" : "批量管理";
            _batchProfilesButton.Invalidate();
            _importProfilesButton.Enabled = !_profileBatchMode;
            _exportProfilesButton.Enabled = !_profileBatchMode;
            _addProfileButton.Enabled = !_profileBatchMode;
            UpdateProfileBatchCount();
            LayoutProfilesPage();
        }

        private void UpdateProfileBatchCount()
        {
            if (_profileBatchBar != null && _profileListHost != null)
                _profileBatchBar.SetCount(_profileListHost.SelectedProfiles().Count);
        }

        private void DeleteSelectedProfiles()
        {
            List<GameProfile> selected = _profileListHost.SelectedProfiles();
            if (selected.Count == 0)
            {
                ShowToast("请先选择要删除的档案", ToastKind.Info);
                return;
            }
            bool ok = DialogForm.Confirm(this, "批量删除档案",
                "确定要删除选中的 " + selected.Count + " 个游戏档案吗？\n\n这只会删除档案记录，不会删除游戏文件。", "删除");
            if (!ok) return;
            int removed = 0;
            foreach (GameProfile profile in selected)
                if (_config.RemoveProfile(profile.Id)) removed++;
            _config.Save(AppPaths.ConfigFile);
            RefreshProfileList();
            UpdateLaunchPathUi();
            UpdateHero();
            UpdateStats();
            UpdateProfileBatchCount();
            Log.Ok("批量删除了 " + removed + " 个游戏档案");
            ShowToast("已删除 " + removed + " 个游戏档案", ToastKind.Success);
        }

        private void RefreshProfileList()
        {
            if (_profileListHost == null) return;
            GameProfile selected = _config.GetSelectedProfile();
            _profileListHost.SetProfiles(_config.Profiles, selected != null ? selected.Id : string.Empty);
            if (_profileCountLabel != null)
                _profileCountLabel.Text = "共 " + _config.Profiles.Count + " 个档案";
        }

        private void ImportGameProfiles()
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "导入游戏档案";
                dialog.Filter = "STEVE CLIENT 游戏档案 (*.steveprofiles;*.json)|*.steveprofiles;*.json|所有文件 (*.*)|*.*";
                dialog.CheckFileExists = true;
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    FileInfo file = new FileInfo(dialog.FileName);
                    if (file.Length > 4L * 1024L * 1024L)
                    {
                        DialogForm.Error(this, "文件过大", "游戏档案文件不应超过 4 MB。");
                        return;
                    }
                    string text = File.ReadAllText(dialog.FileName, Encoding.UTF8);
                    ProfileImportData data = ProfileTransfer.Parse(text);
                    if (!string.IsNullOrEmpty(data.Error))
                    {
                        DialogForm.Error(this, "导入失败", data.Error);
                        return;
                    }

                    int imported = 0;
                    int missing = 0;
                    int skipped = 0;
                    foreach (GameProfile source in data.Profiles)
                    {
                        if (source.IsOfficial)
                        {
                            skipped++;
                            continue;
                        }
                        string name = (source.Name ?? string.Empty).Trim();
                        string path = (source.LaunchPath ?? string.Empty).Trim();
                        if (name.Length == 0 || path.Length == 0)
                        {
                            skipped++;
                            continue;
                        }
                        string uniqueName = UniqueProfileName(name);
                        _config.AddProfile(uniqueName, path);
                        imported++;
                        if (!File.Exists(path)) missing++;
                    }

                    if (imported == 0)
                    {
                        DialogForm.Info(this, "没有导入档案",
                            skipped > 0 ? "文件中只有官方档案或无效档案，没有可导入的内容。" : "文件中没有可导入的档案。");
                        return;
                    }

                    _config.Save(AppPaths.ConfigFile);
                    RefreshProfileList();
                    UpdateLaunchPathUi();
                    UpdateHero();
                    UpdateStats();
                    Log.Ok("已导入 " + imported + " 个游戏档案");
                    ShowToast("已导入 " + imported + " 个游戏档案", ToastKind.Success);
                    if (missing > 0)
                    {
                        DialogForm.Warning(this, "部分档案路径不存在",
                            "有 " + missing + " 个档案的启动路径在当前电脑上不存在。\n\n" +
                            "档案仍会保留，你可以删除它们，或把路径对应的程序放到原位置。");
                    }
                }
                catch (Exception ex)
                {
                    Log.Error("导入游戏档案失败：" + ex.Message);
                    DialogForm.Error(this, "导入失败", ex.Message);
                }
            }
        }

        private void ExportGameProfiles()
        {
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Title = "导出游戏档案";
                dialog.Filter = "STEVE CLIENT 游戏档案 (*.steveprofiles)|*.steveprofiles|JSON 文件 (*.json)|*.json";
                dialog.DefaultExt = ProfileTransfer.Extension;
                dialog.AddExtension = true;
                dialog.FileName = "STEVE CLIENT 游戏档案";
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    string text = ProfileTransfer.Export(_config);
                    File.WriteAllText(dialog.FileName, text, new UTF8Encoding(false));
                    Log.Ok("已导出 " + _config.Profiles.Count + " 个游戏档案：" + dialog.FileName);
                    ShowToast("游戏档案已导出", ToastKind.Success);
                }
                catch (Exception ex)
                {
                    Log.Error("导出游戏档案失败：" + ex.Message);
                    DialogForm.Error(this, "导出失败", ex.Message);
                }
            }
        }

        private string UniqueProfileName(string name)
        {
            string candidate = name;
            int index = 2;
            while (true)
            {
                bool exists = false;
                foreach (GameProfile profile in _config.Profiles)
                {
                    if (string.Equals(profile.Name, candidate, StringComparison.OrdinalIgnoreCase))
                    {
                        exists = true;
                        break;
                    }
                }
                if (!exists) return candidate;
                candidate = name + " (" + index + ")";
                index++;
            }
        }

        private void AddGameProfile()
        {
            using (ProfileDialog dialog = new ProfileDialog())
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                GameProfile profile = _config.AddProfile(dialog.ProfileName, dialog.ProfilePath);
                _config.Save(AppPaths.ConfigFile);
                RefreshProfileList();
                UpdateLaunchPathUi();
                UpdateHero();
                UpdateStats();
                Log.Ok("已添加游戏档案：" + profile.Name + " · " + profile.LaunchPath);
                ShowToast("已添加游戏档案 " + profile.Name, ToastKind.Success);
            }
        }

        private void SelectGameProfile(GameProfile profile)
        {
            if (profile == null) return;
            _config.SelectedProfileId = profile.Id;
            _config.Save(AppPaths.ConfigFile);
            RefreshProfileList();
            UpdateLaunchPathUi();
            UpdateHero();
            UpdateStats();
            Log.Info("已选择游戏档案：" + profile.Name);
            ShowToast("已切换到 " + profile.Name, ToastKind.Info);
        }

        private void RemoveGameProfile(GameProfile profile)
        {
            if (profile == null || profile.IsOfficial) return;
            bool confirmed = DialogForm.Confirm(this, "删除游戏档案",
                "确定要删除档案 “" + profile.Name + "” 吗？\n\n这只会删除档案记录，不会删除游戏文件。", "删除");
            if (!confirmed) return;
            if (!_config.RemoveProfile(profile.Id)) return;
            _config.Save(AppPaths.ConfigFile);
            RefreshProfileList();
            UpdateLaunchPathUi();
            UpdateHero();
            UpdateStats();
            Log.Ok("已删除游戏档案：" + profile.Name);
            ShowToast("已删除档案 " + profile.Name, ToastKind.Success);
        }

        private void BuildModulesPage()
        {
            _pageModules = new BufferedPanel();
            _pageModules.Dock = DockStyle.Fill;
            _pageModules.BackColor = Theme.Bg;
            _pageModules.Resize += delegate { LayoutModulesPage(); };
            _pageHost.Controls.Add(_pageModules);

            _modulesHeader = new PageHeader();
            _modulesHeader.Text = "DLL 模块";
            _modulesHeader.Subtitle = "0 个模块 · 所有已启用的 DLL 会在启动游戏后自动注入";
            _modulesHeader.Location = new Point(Theme.S(26f), Theme.S(12f));
            _modulesHeader.Size = new Size(Theme.S(760f), Theme.S(66f));
            _modulesHeader.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            _pageModules.Controls.Add(_modulesHeader);

            PillButton add = new PillButton();
            add.Text = "添加 DLL";
            add.Icon = IconGlyph.Plus;
            add.Primary = true;
            add.Size = new Size(Theme.S(118f), Theme.S(38f));
            add.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            add.Click += delegate { AddDlls(); };
            _pageModules.Controls.Add(add);

            PillButton open = new PillButton();
            open.Text = "打开文件夹";
            open.Icon = IconGlyph.Folder;
            open.Size = new Size(Theme.S(124f), Theme.S(38f));
            open.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            open.Click += delegate { AppPaths.OpenDllFolder(); };
            _pageModules.Controls.Add(open);

            PillButton refresh = new PillButton();
            refresh.Text = "刷新";
            refresh.Icon = IconGlyph.Refresh;
            refresh.Size = new Size(Theme.S(88f), Theme.S(38f));
            refresh.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            refresh.Click += delegate { LoadDlls(false); ShowToast("模块列表已刷新", ToastKind.Info); };
            _pageModules.Controls.Add(refresh);

            PillButton toggleAll = new PillButton();
            toggleAll.Text = "全部启用";
            toggleAll.Icon = IconGlyph.Check;
            toggleAll.Size = new Size(Theme.S(102f), Theme.S(38f));
            toggleAll.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            toggleAll.Click += delegate { ToggleAll(); };
            _pageModules.Controls.Add(toggleAll);

            _batchDllsButton = new PillButton();
            _batchDllsButton.Text = "批量管理";
            _batchDllsButton.Icon = IconGlyph.Check;
            _batchDllsButton.CornerRadius = 8f;
            _batchDllsButton.Size = new Size(Theme.S(92f), Theme.S(38f));
            _batchDllsButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _batchDllsButton.Click += delegate { ToggleDllBatch(); };
            _pageModules.Controls.Add(_batchDllsButton);

            _dllList = new DllListPanel();
            _dllList.ToggleRequested += DllListToggleRequested;
            _dllList.RemoveRequested += DllListRemoveRequested;
            _dllList.OpenFolderRequested += delegate { AppPaths.OpenDllFolder(); };
            _dllList.ContextRequested += DllListContextRequested;
            _dllList.FilesDropped += delegate(string[] files) { ImportFiles(files); };
            _dllList.SelectionChanged += delegate { UpdateDllBatchCount(); };
            _pageModules.Controls.Add(_dllList);

            _dllBatchBar = new BatchBar();
            _dllBatchBar.Visible = false;
            _dllBatchBar.AddAction("全选", IconGlyph.Check, 76, delegate { _dllList.SelectAll(true); });
            _dllBatchBar.AddAction("启用", IconGlyph.Play, 76, delegate { SetSelectedDllsEnabled(true); });
            _dllBatchBar.AddAction("禁用", IconGlyph.Close, 76, delegate { SetSelectedDllsEnabled(false); });
            _dllBatchBar.AddAction("移除", IconGlyph.Trash, 88, delegate { RemoveSelectedDlls(); });
            _pageModules.Controls.Add(_dllBatchBar);
            _pageModules.AllowDrop = true;
            _pageModules.DragEnter += MainFormDragEnter;
            _pageModules.DragDrop += MainFormDragDrop;

            _moduleFooter = MakeLabel("提示：直接拖入 .dll 文件即可导入；双击模块打开所在文件夹，右键可移除。按 " +
                _config.InjectHotkey + " 可注入运行中的游戏。",
                Theme.Ui(8.9f), Theme.Muted2);
            _moduleFooter.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            _pageModules.Controls.Add(_moduleFooter);

            _pageModules.Tag = new object[] { add, open, refresh, toggleAll, _batchDllsButton };
            LayoutModulesPage();
        }

        private void LayoutModulesPage()
        {
            if (_dllList == null || _modulesHeader == null) return;
            int pad = Theme.S(26f);
            int width = _pageModules.ClientSize.Width - pad * 2;
            _modulesHeader.Bounds = new Rectangle(pad, Theme.S(12f), width, Theme.S(66f));
            object[] buttons = _pageModules.Tag as object[];
            if (buttons != null)
            {
                PillButton add = (PillButton)buttons[0];
                PillButton open = (PillButton)buttons[1];
                PillButton refresh = (PillButton)buttons[2];
                PillButton toggleAll = (PillButton)buttons[3];
                PillButton batch = (PillButton)buttons[4];
                int gap = Theme.S(8f);
                int x = _pageModules.ClientSize.Width - pad - add.Width;
                add.Location = new Point(x, Theme.S(84f));
                x -= open.Width + gap;
                open.Location = new Point(x, Theme.S(84f));
                x -= refresh.Width + gap;
                refresh.Location = new Point(x, Theme.S(84f));
                x -= toggleAll.Width + gap;
                toggleAll.Location = new Point(x, Theme.S(84f));
                x -= batch.Width + gap;
                batch.Location = new Point(x, Theme.S(84f));
            }
            int y = Theme.S(132f);
            if (_dllBatchBar != null && _dllBatchBar.Visible)
            {
                _dllBatchBar.Bounds = new Rectangle(pad, y, width, Theme.S(46f));
                _dllBatchBar.LayoutBar(width);
                y = _dllBatchBar.Bottom + Theme.S(8f);
            }
            _dllList.Bounds = new Rectangle(pad, y, Math.Max(Theme.S(300f), width), Math.Max(Theme.S(180f), _pageModules.ClientSize.Height - y - Theme.S(42f)));
            _moduleFooter.Location = new Point(pad + Theme.S(2f), _pageModules.ClientSize.Height - Theme.S(27f));
            _moduleFooter.Size = new Size(Math.Max(Theme.S(300f), width), Theme.S(18f));
        }

        private void BuildResourcesPage()
        {
            _pageResources = new BufferedPanel();
            _pageResources.Dock = DockStyle.Fill;
            _pageResources.BackColor = Theme.Bg;
            _pageResources.Resize += delegate { LayoutResourcesPage(); };
            _pageHost.Controls.Add(_pageResources);

            _resourcesHeader = new PageHeader();
            _resourcesHeader.Text = "资源库";
            _resourcesHeader.Subtitle = "添加资源包、行为包、模板和世界：前三类进入版本的共享目录，世界进入所选账号。";
            _resourcesHeader.Location = new Point(Theme.S(26f), Theme.S(12f));
            _resourcesHeader.Size = new Size(Theme.S(760f), Theme.S(66f));
            _resourcesHeader.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            _pageResources.Controls.Add(_resourcesHeader);

            _addResourceButton = new PillButton();
            _addResourceButton.Text = "添加资源";
            _addResourceButton.Icon = IconGlyph.Plus;
            _addResourceButton.Primary = true;
            _addResourceButton.Size = new Size(Theme.S(118f), Theme.S(38f));
            _addResourceButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _addResourceButton.Click += delegate { AddResources(); };
            _pageResources.Controls.Add(_addResourceButton);

            _openResourceFolderButton = new PillButton();
            _openResourceFolderButton.Text = "打开目录";
            _openResourceFolderButton.Icon = IconGlyph.Folder;
            _openResourceFolderButton.Size = new Size(Theme.S(124f), Theme.S(38f));
            _openResourceFolderButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _openResourceFolderButton.Click += delegate { OpenProfileFolder(); };
            _pageResources.Controls.Add(_openResourceFolderButton);

            _refreshResourceButton = new PillButton();
            _refreshResourceButton.Text = "刷新";
            _refreshResourceButton.Icon = IconGlyph.Refresh;
            _refreshResourceButton.Size = new Size(Theme.S(88f), Theme.S(38f));
            _refreshResourceButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _refreshResourceButton.Click += delegate { RefreshContentAsync(true); };
            _pageResources.Controls.Add(_refreshResourceButton);

            _batchContentButton = new PillButton();
            _batchContentButton.Text = "批量管理";
            _batchContentButton.Icon = IconGlyph.Check;
            _batchContentButton.CornerRadius = 8f;
            _batchContentButton.Size = new Size(Theme.S(92f), Theme.S(38f));
            _batchContentButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _batchContentButton.Click += delegate { ToggleContentBatch(); };
            _pageResources.Controls.Add(_batchContentButton);

            _profileCard = new RoundedPanel();
            _profileCard.Radius = 13;
            _profileCard.BackColor = Theme.Surface;
            _pageResources.Controls.Add(_profileCard);

            _profileCaption = MakeLabel("目标账号 / 数据目录", Theme.Ui(8.6f, FontStyle.Bold), Theme.Muted2, Theme.Surface);
            _profileCard.Controls.Add(_profileCaption);

            _profileName = MakeLabel("未选择目录", Theme.Ui(11.5f, FontStyle.Bold), Theme.Text, Theme.Surface);
            _profileCard.Controls.Add(_profileName);

            _profilePath = MakeLabel(string.Empty, Theme.Mono(8.8f), Theme.Muted2, Theme.Surface);
            _profileCard.Controls.Add(_profilePath);

            _profileSwitch = new PillButton();
            _profileSwitch.Text = "切换";
            _profileSwitch.Icon = IconGlyph.ChevronDown;
            _profileSwitch.Font = Theme.Ui(9.2f, FontStyle.Bold);
            _profileSwitch.Size = new Size(Theme.S(98f), Theme.S(30f));
            _profileSwitch.Click += delegate { ShowProfileMenu(); };
            _profileCard.Controls.Add(_profileSwitch);

            _tabTexture = MakeContentTab("资源包", delegate { SelectContentTab(ContentKind.TexturePack); });
            _pageResources.Controls.Add(_tabTexture);
            _tabBehavior = MakeContentTab("行为包", delegate { SelectContentTab(ContentKind.Mod); });
            _pageResources.Controls.Add(_tabBehavior);
            _tabWorld = MakeContentTab("世界", delegate { SelectContentTab(ContentKind.World); });
            _pageResources.Controls.Add(_tabWorld);
            _tabTemplate = MakeContentTab("模板", delegate { SelectContentTab(ContentKind.Template); });
            _pageResources.Controls.Add(_tabTemplate);

            _contentList = new ContentListPanel();
            _contentList.RemoveRequested += ContentListRemoveRequested;
            _contentList.OpenRequested += ContentListOpenRequested;
            _contentList.SelectionChanged += delegate { UpdateContentBatchCount(); };
            _pageResources.Controls.Add(_contentList);

            _contentBatchBar = new BatchBar();
            _contentBatchBar.Visible = false;
            _contentBatchBar.AddAction("全选", IconGlyph.Check, 76, delegate { _contentList.SelectAll(true); });
            _contentBatchBar.AddAction("清空", IconGlyph.Close, 76, delegate { _contentList.SelectAll(false); });
            _contentBatchBar.AddAction("移除选中", IconGlyph.Trash, 100, delegate { RemoveSelectedContent(); });
            _pageResources.Controls.Add(_contentBatchBar);
            _pageResources.AllowDrop = true;
            _pageResources.DragEnter += MainFormDragEnter;
            _pageResources.DragDrop += MainFormDragDrop;

            _contentFooter = MakeLabel("资源包 / 行为包 / 模板安装到共享目录，世界安装到所选账号；悬停可移除，双击打开目录，安装后请重启游戏。",
                Theme.Ui(8.9f), Theme.Muted2);
            _contentFooter.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            _pageResources.Controls.Add(_contentFooter);

            _importOverlay = new RoundedPanel();
            _importOverlay.Radius = 13;
            _importOverlay.BackColor = Theme.Surface;
            _importOverlay.Visible = false;
            _pageResources.Controls.Add(_importOverlay);

            _importTitle = MakeLabel("正在导入资源", Theme.Ui(13f, FontStyle.Bold), Theme.Text, Theme.Surface);
            _importOverlay.Controls.Add(_importTitle);

            _importDetail = MakeLabel(string.Empty, Theme.Ui(9.2f), Theme.Muted2, Theme.Surface);
            _importOverlay.Controls.Add(_importDetail);

            _importPercent = MakeLabel("0%", Theme.Ui(9.2f, FontStyle.Bold), Theme.AccentLight, Theme.Surface);
            _importPercent.TextAlign = ContentAlignment.MiddleRight;
            _importOverlay.Controls.Add(_importPercent);

            _importBar = new ThinProgressBar();
            _importBar.BackColor = Theme.Surface;
            _importOverlay.Controls.Add(_importBar);

            _importCancelButton = new PillButton();
            _importCancelButton.Text = "取消导入";
            _importCancelButton.Icon = IconGlyph.Close;
            _importCancelButton.Font = Theme.Ui(9f, FontStyle.Bold);
            _importCancelButton.Size = new Size(Theme.S(104f), Theme.S(30f));
            _importCancelButton.Click += delegate
            {
                if (_importCts == null) return;
                try { _importCts.Cancel(); } catch { }
                _importCancelButton.Enabled = false;
                _importDetail.Text = "正在取消导入，请稍候…";
                _importPercent.Text = string.Empty;
            };
            _importOverlay.Controls.Add(_importCancelButton);

            _pageResources.Tag = new object[] { _addResourceButton, _openResourceFolderButton, _refreshResourceButton, _profileCard, _profileSwitch, _batchContentButton };
            LayoutResourcesPage();
            ReloadProfiles();
        }

        private void LayoutResourcesPage()
        {
            if (_pageResources == null || _resourcesHeader == null || _profileCard == null || _profileSwitch == null) return;
            int pad = Theme.S(26f);
            int width = Math.Max(Theme.S(560f), _pageResources.ClientSize.Width - pad * 2);
            _resourcesHeader.Bounds = new Rectangle(pad, Theme.S(12f), width, Theme.S(66f));

            int gap = Theme.S(8f);
            int x = pad + width - _addResourceButton.Width;
            _addResourceButton.Location = new Point(x, Theme.S(84f));
            x -= _openResourceFolderButton.Width + gap;
            _openResourceFolderButton.Location = new Point(x, Theme.S(84f));
            x -= _refreshResourceButton.Width + gap;
            _refreshResourceButton.Location = new Point(x, Theme.S(84f));
            x -= _batchContentButton.Width + gap;
            _batchContentButton.Location = new Point(x, Theme.S(84f));

            int cardY = Theme.S(132f);
            int cardH = Theme.S(66f);
            _profileCard.Bounds = new Rectangle(pad, cardY, width, cardH);
            int textWidth = Math.Max(Theme.S(180f), width - Theme.S(150f));
            _profileCaption.Location = new Point(Theme.S(16f), Theme.S(6f));
            _profileCaption.Size = new Size(textWidth, Theme.S(16f));
            _profileName.Location = new Point(Theme.S(16f), Theme.S(21f));
            _profileName.Size = new Size(textWidth, Theme.S(22f));
            _profilePath.Location = new Point(Theme.S(16f), Theme.S(43f));
            _profilePath.Size = new Size(textWidth, Theme.S(16f));
            _profileSwitch.Location = new Point(width - Theme.S(16f) - _profileSwitch.Width, Theme.S(18f));

            int tabsY = cardY + cardH + Theme.S(10f);
            int tabGap = Theme.S(8f);
            int tabH = Theme.S(38f);
            int tabW = Math.Max(Theme.S(100f), (width - tabGap * 3) / 4);
            _tabTexture.Bounds = new Rectangle(pad, tabsY, tabW, tabH);
            _tabBehavior.Bounds = new Rectangle(pad + tabW + tabGap, tabsY, tabW, tabH);
            _tabWorld.Bounds = new Rectangle(pad + (tabW + tabGap) * 2, tabsY, tabW, tabH);
            _tabTemplate.Bounds = new Rectangle(pad + (tabW + tabGap) * 3, tabsY, tabW, tabH);

            int listY = tabsY + tabH + Theme.S(10f);
            if (_contentBatchBar != null && _contentBatchBar.Visible)
            {
                _contentBatchBar.Bounds = new Rectangle(pad, listY, width, Theme.S(46f));
                _contentBatchBar.LayoutBar(width);
                listY = _contentBatchBar.Bottom + Theme.S(8f);
            }
            _contentList.Bounds = new Rectangle(pad, listY, Math.Max(Theme.S(300f), width),
                Math.Max(Theme.S(160f), _pageResources.ClientSize.Height - listY - Theme.S(42f)));
            _contentFooter.Location = new Point(pad + Theme.S(2f), _pageResources.ClientSize.Height - Theme.S(27f));
            _contentFooter.Size = new Size(Math.Max(Theme.S(300f), width), Theme.S(18f));

            if (_importOverlay != null)
            {
                int overlayW = Theme.S(460f);
                int overlayH = Theme.S(142f);
                int overlayX = pad + Math.Max(0, (width - overlayW) / 2);
                int overlayY = _contentList.Top + Math.Max(0, (_contentList.Height - overlayH) / 2);
                _importOverlay.Bounds = new Rectangle(overlayX, overlayY, overlayW, overlayH);
                _importTitle.Location = new Point(Theme.S(20f), Theme.S(14f));
                _importTitle.Size = new Size(overlayW - Theme.S(40f), Theme.S(24f));
                _importDetail.Location = new Point(Theme.S(20f), Theme.S(42f));
                _importDetail.Size = new Size(overlayW - Theme.S(108f), Theme.S(18f));
                _importPercent.Location = new Point(overlayW - Theme.S(86f), Theme.S(42f));
                _importPercent.Size = new Size(Theme.S(66f), Theme.S(18f));
                _importBar.Bounds = new Rectangle(Theme.S(20f), Theme.S(70f), overlayW - Theme.S(40f), Theme.S(10f));
                _importCancelButton.Location = new Point(overlayW - Theme.S(20f) - _importCancelButton.Width,
                    overlayH - Theme.S(20f) - _importCancelButton.Height);
                _importOverlay.BringToFront();
            }
        }

        private void ReloadProfiles()
        {
            _profiles = ContentProfiles.Discover(_config);
            if (_profiles.Count == 0) _profiles.Add(ContentProfiles.CreateFallback());

            ContentProfile saved = null;
            if (!string.IsNullOrEmpty(_config.ResourceDataDir))
            {
                foreach (ContentProfile profile in _profiles)
                {
                    if (string.Equals(profile.DataDir, _config.ResourceDataDir, StringComparison.OrdinalIgnoreCase))
                    {
                        saved = profile;
                        break;
                    }
                }
            }
            ContentProfile pick = null;
            if (saved != null && !saved.IsReadOnly && (saved.Exists || saved.IsCustom)) pick = saved;
            if (pick == null)
            {
                foreach (ContentProfile profile in _profiles)
                    if (profile.IsCurrentUser && profile.Exists) { pick = profile; break; }
            }
            if (pick == null)
            {
                foreach (ContentProfile profile in _profiles)
                    if (profile.Exists) { pick = profile; break; }
            }
            if (pick == null && saved != null) pick = saved;
            if (pick == null) pick = _profiles[0];

            _profile = pick;
            if (!string.Equals(_config.ResourceDataDir, pick.DataDir, StringComparison.OrdinalIgnoreCase))
            {
                _config.ResourceDataDir = pick.DataDir;
                _config.ResourceCustom = false;
                _config.Save(AppPaths.ConfigFile);
            }
            UpdateProfileUi();
            RefreshContent(false);
        }

        private void UpdateProfileUi()
        {
            if (_profileName == null) return;
            if (_profile == null)
            {
                _profileName.Text = "未选择目录";
                _profilePath.Text = string.Empty;
                if (_contentList != null) _contentList.TargetHint = string.Empty;
                return;
            }
            _profileName.Text = _profile.DisplayName + (_profile.IsReadOnly ? "（只读扫描）" : string.Empty) +
                (_profile.Exists ? string.Empty : "（目录未创建）");
            _profilePath.Text = ContentProfiles.Shorten(_profile.DataDir);
            if (_contentList != null) _contentList.TargetHint = ContentProfiles.Shorten(_profile.DataDir);
            if (_addResourceButton != null) _addResourceButton.Enabled = !_profile.IsReadOnly;
        }

        private void UpdateResourceSummary()
        {
            if (_resourcesHeader == null) return;
            int mods = 0;
            int textures = 0;
            int worlds = 0;
            int templates = 0;
            foreach (ContentItem item in _content)
            {
                if (item.Kind == ContentKind.World) worlds++;
                else if (item.Kind == ContentKind.Template) templates++;
                else if (item.Kind == ContentKind.TexturePack) textures++;
                else mods++;
            }
            if (_content.Count == 0)
            {
                _resourcesHeader.Subtitle = "暂无资源：添加 .mcpack / .mcaddon / .mcworld / .mctemplate / .zip，或把文件拖进窗口。";
                return;
            }
            string mode = (_profile != null && _profile.IsReadOnly) ? "  ·  只读扫描目录" : string.Empty;
            _resourcesHeader.Subtitle = "共 " + _content.Count + " 项：" + textures + " 个资源包 · " +
                mods + " 个行为包 · " + worlds + " 个世界 · " + templates + " 个模板" + mode;
        }

        private PillButton MakeContentTab(string text, EventHandler click)
        {
            PillButton button = new PillButton();
            button.Text = text;
            button.Font = Theme.Ui(9.6f, FontStyle.Bold);
            button.Size = new Size(Theme.S(140f), Theme.S(38f));
            button.Click += click;
            return button;
        }

        private void SelectContentTab(ContentKind kind)
        {
            if (_contentTab == kind) return;
            _contentTab = kind;
            UpdateContentTabs();
            UpdateContentList();
        }

        private void UpdateContentTabs()
        {
            if (_tabTexture == null) return;
            int textures = 0;
            int behaviors = 0;
            int worlds = 0;
            int templates = 0;
            foreach (ContentItem item in _content)
            {
                if (item.Kind == ContentKind.World) worlds++;
                else if (item.Kind == ContentKind.Template) templates++;
                else if (item.Kind == ContentKind.TexturePack) textures++;
                else behaviors++;
            }
            _tabTexture.Text = "资源包 · " + textures;
            _tabBehavior.Text = "行为包 · " + behaviors;
            _tabWorld.Text = "世界 · " + worlds;
            _tabTemplate.Text = "模板 · " + templates;
            _tabTexture.Primary = _contentTab == ContentKind.TexturePack;
            _tabBehavior.Primary = _contentTab == ContentKind.Mod;
            _tabWorld.Primary = _contentTab == ContentKind.World;
            _tabTemplate.Primary = _contentTab == ContentKind.Template;
            _tabTexture.Invalidate();
            _tabBehavior.Invalidate();
            _tabWorld.Invalidate();
            _tabTemplate.Invalidate();
        }

        private void UpdateContentList()
        {
            if (_contentList == null) return;
            List<ContentItem> visible = new List<ContentItem>();
            foreach (ContentItem item in _content)
                if (item.Kind == _contentTab) visible.Add(item);

            if (_contentTab == ContentKind.TexturePack)
            {
                _contentList.EmptyTitle = "还没有资源包";
                _contentList.EmptyHint = "添加 .mcpack / .mcaddon / .zip，或把文件拖进窗口";
            }
            else if (_contentTab == ContentKind.Mod)
            {
                _contentList.EmptyTitle = "还没有行为包";
                _contentList.EmptyHint = "添加 .mcpack / .mcaddon / .zip，或把文件拖进窗口";
            }
            else if (_contentTab == ContentKind.Template)
            {
                _contentList.EmptyTitle = "还没有模板";
                _contentList.EmptyHint = "添加 .mctemplate，或把文件拖进窗口";
            }
            else
            {
                _contentList.EmptyTitle = "还没有世界";
                _contentList.EmptyHint = "添加 .mcworld / .zip，或把文件拖进窗口";
            }
            _contentList.SetItems(visible);
        }

        private void RefreshContent(bool toast, bool force = false)
        {
            if (_profile == null) ReloadProfiles();
            if (_profile == null) return;
            string cacheKey = ContentCacheKey(_profile);
            List<ContentItem> cached;
            if (!force && !_contentDirty && _contentMemoryCache.TryGetValue(cacheKey, out cached))
            {
                _content = cached;
                _contentCacheKey = cacheKey;
                UpdateProfileUi();
                UpdateResourceSummary();
                UpdateContentTabs();
                UpdateContentList();
                if (toast) ShowToast("资源库已刷新（" + _content.Count + " 项，缓存）", ToastKind.Info);
                return;
            }
            try { _content = ContentInstaller.Scan(_profile); }
            catch (Exception ex)
            {
                Log.Warn("扫描资源失败：" + ex.Message);
                _content = new List<ContentItem>();
            }
            _contentCacheKey = cacheKey;
            _contentMemoryCache[cacheKey] = _content;
            _contentDirty = false;
            UpdateProfileUi();
            UpdateResourceSummary();
            UpdateContentTabs();
            UpdateContentList();
            if (toast) ShowToast("资源库已刷新（" + _content.Count + " 项）", ToastKind.Info);
        }

        private static string ContentCacheKey(ContentProfile profile)
        {
            if (profile == null) return string.Empty;
            return (profile.DataDir ?? string.Empty) + "|" + (profile.SharedDir ?? string.Empty);
        }

        private async void RefreshContentAsync(bool toast)
        {
            if (_contentRefreshing || _profile == null) return;
            ContentProfile profile = _profile;
            string key = ContentCacheKey(profile);
            _contentRefreshing = true;
            try
            {
                List<ContentItem> items = await Task.Run(delegate
                {
                    return ContentInstaller.Scan(profile);
                });
                if (IsDisposed) return;
                _contentMemoryCache[key] = items;
                if (_profile == null ||
                    !string.Equals(ContentCacheKey(_profile), key, StringComparison.OrdinalIgnoreCase))
                    return;

                _content = items;
                _contentCacheKey = key;
                _contentDirty = false;
                UpdateProfileUi();
                UpdateResourceSummary();
                UpdateContentTabs();
                UpdateContentList();
                if (toast) ShowToast("资源库已刷新（" + _content.Count + " 项）", ToastKind.Info);
            }
            catch (Exception ex)
            {
                Log.Warn("后台扫描资源失败：" + ex.Message);
                if (toast) ShowToast("刷新资源失败：" + ex.Message, ToastKind.Warning);
            }
            finally
            {
                _contentRefreshing = false;
            }
        }

        private void ShowProfileMenu()
        {
            if (_profileMenu != null)
            {
                try { _profileMenu.Dispose(); } catch { }
                _profileMenu = null;
            }
            ContextMenuStrip menu = new ContextMenuStrip();
            _profileMenu = menu;
            menu.Renderer = new DarkMenuRenderer();
            menu.BackColor = Theme.Surface2;
            menu.ForeColor = Theme.TextSoft;
            menu.ShowImageMargin = false;
            foreach (ContentProfile profile in _profiles)
            {
                ContentProfile captured = profile;
                string text = profile.DisplayName;
                if (profile.IsReadOnly) text += "（只读）";
                else text += " · " + CountWorlds(profile) + " 世界";
                if (!profile.Exists) text += "（目录未创建）";
                ToolStripMenuItem item = new ToolStripMenuItem(text);
                item.Checked = _profile != null &&
                    string.Equals(_profile.DataDir, profile.DataDir, StringComparison.OrdinalIgnoreCase);
                item.Tag = captured;
                item.Click += delegate { SelectProfile((ContentProfile)item.Tag); };
                menu.Items.Add(item);
            }
            menu.Items.Add(new ToolStripSeparator());
            ToolStripMenuItem custom = new ToolStripMenuItem("选择自定义目录…");
            custom.Click += delegate { ChooseCustomDataDir(); };
            menu.Items.Add(custom);
            ToolStripMenuItem scanOther = new ToolStripMenuItem("扫描其他机器目录…");
            scanOther.Click += delegate { ScanOtherDirectory(); };
            menu.Items.Add(scanOther);
            if (!string.IsNullOrEmpty(_config.ResourceScanDir))
            {
                ToolStripMenuItem removeScan = new ToolStripMenuItem("移除外部扫描目录");
                removeScan.Click += delegate { RemoveExternalScan(); };
                menu.Items.Add(removeScan);
            }
            ToolStripMenuItem rescan = new ToolStripMenuItem("重新扫描账号");
            rescan.Click += delegate { ReloadProfiles(); ShowToast("已重新扫描账号目录", ToastKind.Info); };
            menu.Items.Add(rescan);
            menu.Show(_profileSwitch, new Point(0, _profileSwitch.Height + Theme.S(4f)));
        }

        private static int CountWorlds(ContentProfile profile)
        {
            if (profile == null || string.IsNullOrEmpty(profile.DataDir)) return 0;
            try
            {
                string root = Path.Combine(profile.DataDir, "minecraftWorlds");
                if (!Directory.Exists(root)) return 0;
                int count = 0;
                foreach (string dir in Directory.GetDirectories(root))
                    if (File.Exists(Path.Combine(dir, "level.dat"))) count++;
                return count;
            }
            catch { return 0; }
        }

        private void SelectProfile(ContentProfile profile)
        {
            if (profile == null) return;
            _profile = profile;
            _config.ResourceDataDir = profile.DataDir;
            _config.ResourceCustom = false;
            _config.Save(AppPaths.ConfigFile);
            UpdateProfileUi();
            RefreshContent(false);
            Log.Info("资源目标目录：" + profile.DisplayName + " · " + profile.DataDir);
        }

        private void ChooseCustomDataDir()
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                dialog.Description = "选择 Minecraft 数据目录（com.mojang 文件夹）";
                dialog.ShowNewFolderButton = false;
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                string path = NormalizeDataDir(dialog.SelectedPath);
                _config.ResourceDataDir = path;
                _config.ResourceCustom = true;
                _config.Save(AppPaths.ConfigFile);
                ReloadProfiles();
                Log.Info("已设置自定义资源目录：" + path);
                ShowToast("已切换资源目录", ToastKind.Info);
            }
        }

        private void ScanOtherDirectory()
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                dialog.Description = "选择其他机器 / 备份中的 com.mojang 目录（只读浏览）";
                dialog.ShowNewFolderButton = false;
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                string path = NormalizeDataDir(dialog.SelectedPath);
                if (!LooksLikeContentDir(path))
                {
                    DialogForm.Warning(this, "未找到资源",
                        "这个目录下没有 resource_packs、behavior_packs 或 minecraftWorlds。\n\n" +
                        "请选择其他机器上的 com.mojang 文件夹（或其上级目录）。");
                    return;
                }
                _config.ResourceScanDir = path;
                _config.Save(AppPaths.ConfigFile);
                ReloadProfiles();
                foreach (ContentProfile profile in _profiles)
                {
                    if (profile.IsReadOnly && string.Equals(profile.DataDir, path, StringComparison.OrdinalIgnoreCase))
                    {
                        SelectProfile(profile);
                        break;
                    }
                }
                Log.Info("已添加外部扫描目录：" + path);
                ShowToast("已添加外部扫描目录", ToastKind.Info);
            }
        }

        private void RemoveExternalScan()
        {
            _config.ResourceScanDir = string.Empty;
            _config.Save(AppPaths.ConfigFile);
            ReloadProfiles();
            ShowToast("已移除外部扫描目录", ToastKind.Info);
        }

        private static string NormalizeDataDir(string path)
        {
            if (string.IsNullOrEmpty(path)) return path;
            string trimmed = path.TrimEnd('\\');
            if (string.Equals(Path.GetFileName(trimmed), "com.mojang", StringComparison.OrdinalIgnoreCase)) return trimmed;
            string direct = Path.Combine(trimmed, "com.mojang");
            string nested = Path.Combine(trimmed, "games", "com.mojang");
            if (Directory.Exists(direct)) return direct;
            if (Directory.Exists(nested)) return nested;
            return direct;
        }

        private static bool LooksLikeContentDir(string path)
        {
            if (string.IsNullOrEmpty(path)) return false;
            return Directory.Exists(Path.Combine(path, "resource_packs")) ||
                   Directory.Exists(Path.Combine(path, "behavior_packs")) ||
                   Directory.Exists(Path.Combine(path, "minecraftWorlds"));
        }

        private void ToggleContentBatch()
        {
            _contentBatchMode = !_contentBatchMode;
            if (_contentBatchMode && _content.Count == 0)
            {
                _contentBatchMode = false;
                ShowToast("资源库为空，无法批量管理", ToastKind.Info);
                return;
            }
            _contentBatchBar.Visible = _contentBatchMode;
            _contentList.SetBatchMode(_contentBatchMode);
            _batchContentButton.Text = _contentBatchMode ? "退出批量" : "批量管理";
            _batchContentButton.Invalidate();
            _addResourceButton.Enabled = !_contentBatchMode;
            _openResourceFolderButton.Enabled = !_contentBatchMode;
            _refreshResourceButton.Enabled = !_contentBatchMode;
            _profileSwitch.Enabled = !_contentBatchMode;
            UpdateContentBatchCount();
            LayoutResourcesPage();
        }

        private void UpdateContentBatchCount()
        {
            if (_contentBatchBar != null && _contentList != null)
                _contentBatchBar.SetCount(_contentList.SelectedItems().Count);
        }

        private void RemoveSelectedContent()
        {
            List<ContentItem> selected = _contentList.SelectedItems();
            if (selected.Count == 0)
            {
                ShowToast("请先选择要移除的资源", ToastKind.Info);
                return;
            }
            bool ok = DialogForm.Confirm(this, "批量移除资源",
                "确定要移除选中的 " + selected.Count + " 项资源吗？\n\n" +
                "它们会被移动到对应目录的 .steve-client-trash，共享目录中的资源会影响所有账号。", "移除");
            if (!ok) return;
            int removed = 0;
            foreach (ContentItem item in selected)
            {
                string message;
                if (ContentInstaller.Remove(item, _profile, out message))
                {
                    removed++;
                    Log.Ok("已移除资源：" + item.Name);
                }
                else
                {
                    Log.Error("批量移除失败：" + item.Name + " - " + message);
                }
            }
            _contentDirty = true;
            _contentMemoryCache.Remove(_contentCacheKey);
            RefreshContentAsync(false);
            UpdateContentBatchCount();
            ShowToast("已移除 " + removed + " 项资源", ToastKind.Success);
        }

        private void AddResources()
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "选择要安装的资源（可多选）";
                dialog.Filter = "Minecraft 资源 (*.mcpack;*.mcaddon;*.mcworld;*.mctemplate;*.zip)|*.mcpack;*.mcaddon;*.mcworld;*.mctemplate;*.zip|所有文件 (*.*)|*.*";
                dialog.Multiselect = true;
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                ImportContent(dialog.FileNames);
            }
        }

        private async void ImportContent(IEnumerable<string> files)
        {
            if (_importing || files == null) return;
            List<string> list = new List<string>();
            foreach (string file in files)
                if (!string.IsNullOrEmpty(file)) list.Add(file);
            if (list.Count == 0) return;

            if (_profile == null) ReloadProfiles();
            if (_profile == null)
            {
                DialogForm.Error(this, "没有目标目录", "请先选择一个 Minecraft 数据目录。");
                return;
            }
            if (_profile.IsReadOnly)
            {
                DialogForm.Info(this, "只读扫描目录",
                    "当前选择的是外部扫描目录，只能浏览现有资源。\n\n请先在“切换”里选择一个账号，再安装资源。");
                return;
            }

            if (!Directory.Exists(_profile.DataDir))
            {
                bool create = DialogForm.Confirm(this, "目标目录不存在",
                    "尚未在以下位置找到游戏数据目录：\n\n" + _profile.DataDir +
                    "\n\n是否创建它并继续安装？", "创建并安装");
                if (!create) return;
            }

            ContentProfile profile = _profile;
            List<ContentItem> existing = _content != null ? new List<ContentItem>(_content) : null;
            _importing = true;
            _importCts = new CancellationTokenSource();
            CancellationToken token = _importCts.Token;
            ShowImportOverlay();
            SetResourceImportUi(true);

            List<ContentInstallResult> allResults = null;
            bool canceled = false;
            string fatalError = null;
            try
            {
                IProgress<ImportProgress> progress = new Progress<ImportProgress>(UpdateImportOverlay);
                Func<List<ContentConflict>, bool> confirm = delegate(List<ContentConflict> conflicts)
                {
                    if (token.IsCancellationRequested) return false;
                    try
                    {
                        return (bool)Invoke(new Func<bool>(delegate
                        {
                            return ConfirmOverwrite(conflicts);
                        }));
                    }
                    catch
                    {
                        return false;
                    }
                };

                allResults = await Task.Run(delegate
                {
                    List<ContentInstallResult> collected = new List<ContentInstallResult>();
                    foreach (string file in list)
                    {
                        token.ThrowIfCancellationRequested();
                        Action<ImportProgress> report = delegate(ImportProgress info)
                        {
                            progress.Report(info);
                        };
                        List<ContentInstallResult> results =
                            ContentInstaller.Install(file, profile, confirm, report, token, existing);
                        collected.AddRange(results);
                    }
                    return collected;
                }, token);
            }
            catch (OperationCanceledException)
            {
                canceled = true;
            }
            catch (Exception ex)
            {
                fatalError = ex.Message;
                Log.Error("导入资源失败：" + ex);
            }
            finally
            {
                _importing = false;
                if (_importCts != null)
                {
                    _importCts.Dispose();
                    _importCts = null;
                }
                SetResourceImportUi(false);
                HideImportOverlay();
            }

            if (canceled)
            {
                _contentDirty = true;
                ShowToast("已取消导入，已安装的内容会保留", ToastKind.Warning);
                if (_closeAfterImport) { Close(); return; }
                RefreshContentAsync(false);
                return;
            }

            if (fatalError != null)
            {
                _contentDirty = true;
                DialogForm.Error(this, "导入失败", fatalError);
                if (_closeAfterImport) { Close(); return; }
                RefreshContentAsync(false);
                return;
            }

            ApplyImportResults(allResults);
            _contentDirty = true;
            if (_closeAfterImport) { Close(); return; }
            RefreshContentAsync(false);
        }

        private void ApplyImportResults(List<ContentInstallResult> results)
        {
            int success = 0;
            int failed = 0;
            int skipped = 0;
            bool hasInstalledKind = false;
            ContentKind installedKind = ContentKind.TexturePack;
            List<string> errors = new List<string>();
            if (results != null)
            {
                foreach (ContentInstallResult result in results)
                {
                    if (result.Success && result.Skipped)
                    {
                        skipped++;
                        Log.Warn("导入：" + result.Message);
                    }
                    else if (result.Success)
                    {
                        success++;
                        if (!hasInstalledKind)
                        {
                            hasInstalledKind = true;
                            installedKind = result.Kind;
                        }
                        Log.Ok("导入：" + result.Message);
                    }
                    else
                    {
                        failed++;
                        errors.Add(result.Message);
                        Log.Error("资源安装失败：" + result.Message);
                    }
                }
            }

            if (hasInstalledKind) _contentTab = installedKind;
            if (success > 0) ShowToast("已安装 " + success + " 项资源", ToastKind.Success);
            if (skipped > 0) ShowToast("已跳过 " + skipped + " 项重复资源", ToastKind.Warning);
            if (failed > 0)
            {
                string detail = string.Join("\n", errors.ToArray());
                if (detail.Length > 700) detail = detail.Substring(0, 700) + "…";
                DialogForm.Error(this, "部分资源安装失败", detail + "\n\n详细信息已写入日志。");
            }
        }

        private void ShowImportOverlay()
        {
            if (_importOverlay == null) return;
            _importTitle.Text = "正在导入资源";
            _importDetail.Text = "正在准备…";
            _importPercent.Text = "0%";
            _importBar.SetProgress(0, true);
            _importCancelButton.Enabled = true;
            _importCancelButton.Text = "取消导入";
            _lastImportProgress = DateTime.MinValue;
            _importOverlay.Visible = true;
            _importOverlay.BringToFront();
        }

        private void HideImportOverlay()
        {
            if (_importOverlay != null) _importOverlay.Visible = false;
        }

        private void UpdateImportOverlay(ImportProgress info)
        {
            if (IsDisposed || info == null || _importOverlay == null || !_importOverlay.Visible) return;
            if (info.Indeterminate || info.TotalBytes <= 0)
            {
                _importBar.SetProgress(0, true);
                _importPercent.Text = "处理中…";
            }
            else
            {
                double fraction = info.Fraction;
                _importBar.SetProgress(fraction, false);
                _importPercent.Text = (fraction * 100).ToString("0") + "%";
            }
            _importDetail.Text = info.FileName + "  ·  " + info.Phase;
            _importOverlay.Invalidate();
        }

        private void SetResourceImportUi(bool importing)
        {
            if (_addResourceButton != null) _addResourceButton.Enabled = !importing;
            if (_refreshResourceButton != null) _refreshResourceButton.Enabled = !importing;
            if (_profileSwitch != null) _profileSwitch.Enabled = !importing;
            if (_contentList != null) _contentList.Enabled = !importing;
            if (_pageResources != null) _pageResources.AllowDrop = !importing;
        }

        private static string ContentKindName(ContentKind kind)
        {
            switch (kind)
            {
                case ContentKind.World: return "世界";
                case ContentKind.Template: return "模板";
                case ContentKind.TexturePack: return "资源包";
                default: return "行为包";
            }
        }

        private bool ConfirmOverwrite(List<ContentConflict> conflicts)
        {
            if (conflicts == null || conflicts.Count == 0) return true;
            string detail = string.Empty;
            int shown = 0;
            foreach (ContentConflict conflict in conflicts)
            {
                if (shown >= 6)
                {
                    detail += "…\n";
                    break;
                }
                detail += "· " + ContentKindName(conflict.Kind) + "「" + conflict.Name + "」\n";
                shown++;
            }
            bool overwrite = DialogForm.Confirm(this, "发现重复资源",
                "以下内容与现有资源冲突（相同 UUID 或同名世界）：\n\n" + detail +
                "\n覆盖会先把现有内容移动到 .steve-client-trash，再安装新内容。是否覆盖？", "覆盖");
            if (!overwrite)
                DialogForm.Info(this, "未覆盖", "请先删除现有的资源，然后再导入。");
            return overwrite;
        }

        private void ContentListRemoveRequested(object sender, ContentRow row)
        {
            if (row == null || row.Item == null || _profile == null) return;
            if (_profile.IsReadOnly)
            {
                DialogForm.Info(this, "只读扫描目录", "外部扫描目录中的资源只能浏览，不能在这里移除。");
                return;
            }
            ContentItem item = row.Item;
            string warning = "确定要移除 “" + item.Name + "” 吗？\n\n文件会移动到 .steve-client-trash，不会立即删除。";
            if (item.Kind != ContentKind.World && _profile.IsGDK)
                warning += "\n\n该资源位于共享目录，移除后所有账号都会失去它。";
            bool ok = DialogForm.Confirm(this, "移除资源", warning, "移除");
            if (!ok) return;
            string message;
            if (ContentInstaller.Remove(item, _profile, out message))
            {
                Log.Ok("已移除资源：" + item.Name);
                _contentDirty = true;
                RefreshContent(false);
                ShowToast("已移除 " + item.Name, ToastKind.Success);
            }
            else
            {
                Log.Error("移除资源失败：" + message);
                DialogForm.Error(this, "移除失败", message);
            }
        }

        private void ContentListOpenRequested(object sender, ContentRow row)
        {
            if (row == null || row.Item == null) return;
            if (File.Exists(row.Item.FolderPath)) OpenFileLocation(row.Item.FolderPath);
            else OpenFolder(row.Item.FolderPath);
        }

        private void OpenFileLocation(string path)
        {
            if (string.IsNullOrEmpty(path)) return;
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "explorer.exe",
                    Arguments = "/select,\"" + path + "\"",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                Log.Warn("打开文件位置失败：" + ex.Message);
            }
        }

        private void OpenProfileFolder()
        {
            if (_profile == null) return;
            try
            {
                if (!Directory.Exists(_profile.DataDir)) Directory.CreateDirectory(_profile.DataDir);
            }
            catch { }
            OpenFolder(_profile.DataDir);
        }

        private void OpenFolder(string path)
        {
            if (string.IsNullOrEmpty(path)) return;
            try
            {
                // Let the shell open the folder directly; spawning a new
                // explorer.exe process is noticeably slower on some systems.
                if (!Directory.Exists(path)) Directory.CreateDirectory(path);
                Process.Start(new ProcessStartInfo
                {
                    FileName = path,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                Log.Warn("打开目录失败：" + ex.Message);
            }
        }

        private void BuildLogPage()
        {
            _pageLogs = new BufferedPanel();
            _pageLogs.Dock = DockStyle.Fill;
            _pageLogs.BackColor = Theme.Bg;
            _pageLogs.Resize += delegate { LayoutLogsPage(); };
            _pageHost.Controls.Add(_pageLogs);

            _logsHeader = new PageHeader();
            _logsHeader.Text = "运行日志";
            _logsHeader.Subtitle = "启动、注入与错误详情都会记录到这里，滚轮可回看历史。";
            _logsHeader.Location = new Point(Theme.S(26f), Theme.S(12f));
            _logsHeader.Size = new Size(Theme.S(760f), Theme.S(66f));
            _logsHeader.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            _pageLogs.Controls.Add(_logsHeader);

            PillButton open = new PillButton();
            open.Text = "打开日志文件";
            open.Icon = IconGlyph.Folder;
            open.Size = new Size(Theme.S(132f), Theme.S(36f));
            open.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            open.Click += delegate { AppPaths.OpenLogFolder(); };
            _pageLogs.Controls.Add(open);

            PillButton clear = new PillButton();
            clear.Text = "清空显示";
            clear.Icon = IconGlyph.Trash;
            clear.Size = new Size(Theme.S(110f), Theme.S(36f));
            clear.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            clear.Click += delegate
            {
                _logView.Clear();
                Log.ClearMemory();
                ShowToast("日志显示已清空，磁盘日志仍然保留", ToastKind.Info);
            };
            _pageLogs.Controls.Add(clear);

            _pageLogs.Tag = new object[] { open, clear };

            RoundedPanel card = new RoundedPanel();
            card.Radius = 13;
            card.BackColor = Theme.Surface;
            card.Padding = new Padding(Theme.S(13f));
            _logView = new LogView();
            _logView.Dock = DockStyle.Fill;
            card.Controls.Add(_logView);
            _pageLogs.Controls.Add(card);
            _pageLogs.Tag = new object[] { open, clear, card };

            foreach (LogEntry entry in Log.Snapshot()) _logView.AppendEntry(entry);
            _logView.AppendRaw("—— 日志已就绪 ——", Theme.Muted2);
            LayoutLogsPage();
        }

        private void LayoutLogsPage()
        {
            if (_pageLogs == null || _logsHeader == null) return;
            int pad = Theme.S(26f);
            int width = _pageLogs.ClientSize.Width - pad * 2;
            _logsHeader.Bounds = new Rectangle(pad, Theme.S(12f), width, Theme.S(66f));
            object[] data = _pageLogs.Tag as object[];
            if (data == null) return;
            PillButton open = (PillButton)data[0];
            PillButton clear = (PillButton)data[1];
            RoundedPanel card = (RoundedPanel)data[2];
            open.Location = new Point(_pageLogs.ClientSize.Width - pad - open.Width, Theme.S(84f));
            clear.Location = new Point(open.Left - Theme.S(8f) - clear.Width, Theme.S(84f));
            card.Bounds = new Rectangle(pad, Theme.S(132f), width, Math.Max(Theme.S(200f), _pageLogs.ClientSize.Height - Theme.S(156f)));
        }

        private void BuildSettingsPage()
        {
            _pageSettings = new ScrollHostPanel();
            _pageSettings.Dock = DockStyle.Fill;
            _pageSettings.BackColor = Theme.Bg;
            _settingsContent = _pageSettings.Content;
            _pageSettings.Resize += delegate { LayoutSettingsPage(); };
            _pageHost.Controls.Add(_pageSettings);

            _settingsHeader = new PageHeader();
            _settingsHeader.Text = "设置";
            _settingsHeader.Subtitle = "调整启动与注入行为。修改会立即保存。";
            _settingsHeader.Location = new Point(Theme.S(26f), Theme.S(12f));
            _settingsHeader.Size = new Size(Theme.S(760f), Theme.S(66f));
            _settingsHeader.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            _settingsContent.Controls.Add(_settingsHeader);

            RoundedPanel injectCard = new RoundedPanel();
            injectCard.Radius = 13;
            injectCard.BackColor = Theme.Surface;
            _settingsContent.Controls.Add(injectCard);

            AddCardTitle(injectCard, "启动与注入", "控制游戏启动后的自动注入流程。");

            AddSettingLabel(injectCard, "注入延迟", "等待游戏窗口出现后再等待一段时间，给游戏初始化留出时间。", Theme.S(50f));
            int delayX = Theme.S(18f);
            int[] delays = new int[] { 1000, 2500, 4000, 6000 };
            string[] delayTexts = new string[] { "1 秒", "2.5 秒", "4 秒", "6 秒" };
            for (int i = 0; i < delays.Length; i++)
            {
                int value = delays[i];
                PillButton button = new PillButton();
                button.Text = delayTexts[i];
                button.Font = Theme.Ui(9f, FontStyle.Bold);
                button.Size = new Size(Theme.S(58f), Theme.S(30f));
                button.Location = new Point(injectCard.Width - Theme.S(18f) - (delays.Length - i) * (Theme.S(58f) + Theme.S(6f)), Theme.S(56f));
                button.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                button.Click += delegate
                {
                    _config.InjectDelayMs = value;
                    _config.Save(AppPaths.ConfigFile);
                    RefreshDelayButtons();
                };
                injectCard.Controls.Add(button);
                _delayButtons.Add(button);
            }

            AddSettingLabel(injectCard, "注入后最小化启动器", "注入完成后自动最小化，方便直接回到游戏。", Theme.S(98f));
            _minimizeToggle = new ToggleSwitch();
            _minimizeToggle.SetCheckedSilent(_config.MinimizeAfterInject);
            _minimizeToggle.Location = new Point(injectCard.Width - Theme.S(18f) - _minimizeToggle.Width, Theme.S(102f));
            _minimizeToggle.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _minimizeToggle.CheckedChanged += delegate
            {
                _config.MinimizeAfterInject = _minimizeToggle.Checked;
                _config.Save(AppPaths.ConfigFile);
            };
            injectCard.Controls.Add(_minimizeToggle);

            AddSettingLabel(injectCard, "注入后关闭启动器", "注入完成后退出启动器。若需要查看日志，请保持关闭。", Theme.S(146f));
            _closeToggle = new ToggleSwitch();
            _closeToggle.SetCheckedSilent(_config.CloseAfterInject);
            _closeToggle.Location = new Point(injectCard.Width - Theme.S(18f) - _closeToggle.Width, Theme.S(150f));
            _closeToggle.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _closeToggle.CheckedChanged += delegate
            {
                _config.CloseAfterInject = _closeToggle.Checked;
                _config.Save(AppPaths.ConfigFile);
            };
            injectCard.Controls.Add(_closeToggle);

            AddSettingLabel(injectCard, "检查 DLL 架构", "启动前阻止明显不是 64 位的 DLL，避免注入失败。", Theme.S(194f));
            _verifyToggle = new ToggleSwitch();
            _verifyToggle.SetCheckedSilent(_config.VerifyArchitecture);
            _verifyToggle.Location = new Point(injectCard.Width - Theme.S(18f) - _verifyToggle.Width, Theme.S(198f));
            _verifyToggle.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _verifyToggle.CheckedChanged += delegate
            {
                _config.VerifyArchitecture = _verifyToggle.Checked;
                _config.Save(AppPaths.ConfigFile);
            };
            injectCard.Controls.Add(_verifyToggle);

            AddSettingLabel(injectCard, "启动等待", "新启动游戏时等待初始化的时间，默认 10 秒；输入后按回车或点击其他位置生效。", Theme.S(242f));
            _warmupInput = new TextBox();
            _warmupInput.BorderStyle = BorderStyle.FixedSingle;
            _warmupInput.BackColor = Theme.Surface2;
            _warmupInput.ForeColor = Theme.Text;
            _warmupInput.Font = Theme.Mono(10f, FontStyle.Regular);
            _warmupInput.TextAlign = HorizontalAlignment.Center;
            _warmupInput.MaxLength = 2;
            _warmupInput.Size = new Size(Theme.S(46f), Theme.S(24f));
            _warmupInput.Text = CurrentWarmupSeconds().ToString();
            _warmupInput.KeyPress += delegate(object sender, KeyPressEventArgs e)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;
            };
            _warmupInput.KeyDown += delegate(object sender, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Enter)
                {
                    ApplyStartupWarmup(true);
                    e.SuppressKeyPress = true;
                }
            };
            _warmupInput.Leave += delegate { ApplyStartupWarmup(true); };
            injectCard.Controls.Add(_warmupInput);

            _warmupUnit = MakeLabel("秒", Theme.Ui(9.2f), Theme.Muted, Theme.Surface);
            injectCard.Controls.Add(_warmupUnit);

            _warmupResetButton = new PillButton();
            _warmupResetButton.Text = "重置";
            _warmupResetButton.Icon = IconGlyph.Reset;
            _warmupResetButton.Font = Theme.Ui(9f, FontStyle.Bold);
            _warmupResetButton.Size = new Size(Theme.S(64f), Theme.S(30f));
            _warmupResetButton.Click += delegate { ResetStartupWarmup(); };
            injectCard.Controls.Add(_warmupResetButton);

            AddSettingLabel(injectCard, "关闭窗口时隐藏到系统托盘",
                "开启后点击右上角关闭按钮会隐藏到任务栏通知区域；关闭则直接退出启动器。", Theme.S(290f));
            _hideToTrayToggle = new ToggleSwitch();
            _hideToTrayToggle.SetCheckedSilent(_config.HideToTrayOnClose);
            _hideToTrayToggle.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _hideToTrayToggle.CheckedChanged += delegate
            {
                _config.HideToTrayOnClose = _hideToTrayToggle.Checked;
                _config.CloseBehaviorAsked = true;
                _config.Save(AppPaths.ConfigFile);
            };
            injectCard.Controls.Add(_hideToTrayToggle);

            AddSettingLabel(injectCard, "直接注入快捷键",
                "游戏运行中按下组合键即可注入已启用的 DLL；点击右侧按钮重新设置。", Theme.S(336f));
            _injectHotkeyToggle = new ToggleSwitch();
            _injectHotkeyToggle.SetCheckedSilent(_config.EnableInjectHotkey);
            _injectHotkeyToggle.CheckedChanged += delegate
            {
                SetHotkeyEnabled(HotkeyTarget.Inject, _injectHotkeyToggle.Checked);
            };
            injectCard.Controls.Add(_injectHotkeyToggle);

            _hotkeyButton = new PillButton();
            _hotkeyButton.Text = HotkeyUtil.Format(_injectHotkeyModifiers, _injectHotkeyKey);
            _hotkeyButton.CornerRadius = 8f;
            _hotkeyButton.Font = Theme.Ui(9f, FontStyle.Bold);
            _hotkeyButton.Size = new Size(Theme.S(150f), Theme.S(30f));
            _hotkeyButton.Click += delegate { BeginCaptureHotkey(HotkeyTarget.Inject); };
            _hotkeyButton.KeyDown += HotkeyButtonKeyDown;
            _hotkeyButton.LostFocus += delegate { CancelHotkeyCapture(); };
            injectCard.Controls.Add(_hotkeyButton);

            _hotkeyResetButton = new PillButton();
            _hotkeyResetButton.Text = "重置";
            _hotkeyResetButton.Icon = IconGlyph.Reset;
            _hotkeyResetButton.CornerRadius = 8f;
            _hotkeyResetButton.Font = Theme.Ui(9f, FontStyle.Bold);
            _hotkeyResetButton.Size = new Size(Theme.S(64f), Theme.S(30f));
            _hotkeyResetButton.Click += delegate { ResetHotkey(HotkeyTarget.Inject); };
            injectCard.Controls.Add(_hotkeyResetButton);

            AddSettingLabel(injectCard, "直接启动快捷键",
                "按下组合键，按当前预设和启动模式快速启动游戏，跳过启动等待。", Theme.S(382f));
            _launchHotkeyToggle = new ToggleSwitch();
            _launchHotkeyToggle.SetCheckedSilent(_config.EnableLaunchHotkey);
            _launchHotkeyToggle.CheckedChanged += delegate
            {
                SetHotkeyEnabled(HotkeyTarget.Launch, _launchHotkeyToggle.Checked);
            };
            injectCard.Controls.Add(_launchHotkeyToggle);

            _launchHotkeyButton = new PillButton();
            _launchHotkeyButton.Text = _config.LaunchHotkey;
            _launchHotkeyButton.CornerRadius = 8f;
            _launchHotkeyButton.Font = Theme.Ui(9f, FontStyle.Bold);
            _launchHotkeyButton.Size = new Size(Theme.S(150f), Theme.S(30f));
            _launchHotkeyButton.Click += delegate { BeginCaptureHotkey(HotkeyTarget.Launch); };
            _launchHotkeyButton.KeyDown += HotkeyButtonKeyDown;
            _launchHotkeyButton.LostFocus += delegate { CancelHotkeyCapture(); };
            injectCard.Controls.Add(_launchHotkeyButton);

            _launchHotkeyResetButton = new PillButton();
            _launchHotkeyResetButton.Text = "重置";
            _launchHotkeyResetButton.Icon = IconGlyph.Reset;
            _launchHotkeyResetButton.CornerRadius = 8f;
            _launchHotkeyResetButton.Font = Theme.Ui(9f, FontStyle.Bold);
            _launchHotkeyResetButton.Size = new Size(Theme.S(64f), Theme.S(30f));
            _launchHotkeyResetButton.Click += delegate { ResetHotkey(HotkeyTarget.Launch); };
            injectCard.Controls.Add(_launchHotkeyResetButton);

            AddSettingLabel(injectCard, "直接关闭快捷键",
                "按下组合键，直接结束当前 Minecraft 游戏进程。", Theme.S(428f));
            _closeHotkeyToggle = new ToggleSwitch();
            _closeHotkeyToggle.SetCheckedSilent(_config.EnableCloseHotkey);
            _closeHotkeyToggle.CheckedChanged += delegate
            {
                SetHotkeyEnabled(HotkeyTarget.Close, _closeHotkeyToggle.Checked);
            };
            injectCard.Controls.Add(_closeHotkeyToggle);

            _closeHotkeyButton = new PillButton();
            _closeHotkeyButton.Text = _config.CloseHotkey;
            _closeHotkeyButton.CornerRadius = 8f;
            _closeHotkeyButton.Font = Theme.Ui(9f, FontStyle.Bold);
            _closeHotkeyButton.Size = new Size(Theme.S(150f), Theme.S(30f));
            _closeHotkeyButton.Click += delegate { BeginCaptureHotkey(HotkeyTarget.Close); };
            _closeHotkeyButton.KeyDown += HotkeyButtonKeyDown;
            _closeHotkeyButton.LostFocus += delegate { CancelHotkeyCapture(); };
            injectCard.Controls.Add(_closeHotkeyButton);

            _closeHotkeyResetButton = new PillButton();
            _closeHotkeyResetButton.Text = "重置";
            _closeHotkeyResetButton.Icon = IconGlyph.Reset;
            _closeHotkeyResetButton.CornerRadius = 8f;
            _closeHotkeyResetButton.Font = Theme.Ui(9f, FontStyle.Bold);
            _closeHotkeyResetButton.Size = new Size(Theme.S(64f), Theme.S(30f));
            _closeHotkeyResetButton.Click += delegate { ResetHotkey(HotkeyTarget.Close); };
            injectCard.Controls.Add(_closeHotkeyResetButton);

            RoundedPanel folderCard = new RoundedPanel();
            folderCard.Radius = 13;
            folderCard.BackColor = Theme.Surface;
            _settingsContent.Controls.Add(folderCard);
            AddCardTitle(folderCard, "文件夹", "启动器会自动创建并扫描这个目录。");
            _settingsPath = MakeLabel(AppPaths.DllDir, Theme.Mono(9.2f), Theme.TextSoft, Theme.Surface);
            _settingsPath.Location = new Point(Theme.S(20f), Theme.S(56f));
            _settingsPath.Size = new Size(folderCard.Width - Theme.S(40f), Theme.S(18f));
            _settingsPath.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            folderCard.Controls.Add(_settingsPath);

            PillButton openDll = new PillButton();
            openDll.Text = "打开 DLL 文件夹";
            openDll.Icon = IconGlyph.Folder;
            openDll.Size = new Size(Theme.S(148f), Theme.S(34f));
            openDll.Location = new Point(Theme.S(20f), Theme.S(76f));
            openDll.Click += delegate { AppPaths.OpenDllFolder(); };
            folderCard.Controls.Add(openDll);

            PillButton openLogs = new PillButton();
            openLogs.Text = "打开日志文件夹";
            openLogs.Icon = IconGlyph.Folder;
            openLogs.Size = new Size(Theme.S(148f), Theme.S(34f));
            openLogs.Location = new Point(Theme.S(20f) + openDll.Width + Theme.S(8f), Theme.S(76f));
            openLogs.Click += delegate { AppPaths.OpenLogFolder(); };
            folderCard.Controls.Add(openLogs);

            RoundedPanel aboutCard = new RoundedPanel();
            aboutCard.Radius = 13;
            aboutCard.BackColor = Theme.Surface;
            _settingsContent.Controls.Add(aboutCard);
            AddCardTitle(aboutCard, "关于", "一个轻量的 Minecraft for Windows 启动与注入器。");
            _settingsVersion = MakeLabel("STEVE CLIENT  v" + Theme.Version + "  ·  Build " + Theme.BuildDate,
                Theme.Ui(9.8f), Theme.TextSoft, Theme.Surface);
            _settingsVersion.Location = new Point(Theme.S(20f), Theme.S(54f));
            _settingsVersion.Size = new Size(Theme.S(360f), Theme.S(20f));
            aboutCard.Controls.Add(_settingsVersion);

            TextLabel author = MakeLabel("作者：神经蛙123  ·  DeepSeek",
                Theme.Ui(9.2f, FontStyle.Bold), Theme.AccentLight, Theme.Surface);
            author.Location = new Point(Theme.S(20f), Theme.S(78f));
            author.Size = new Size(Theme.S(360f), Theme.S(20f));
            aboutCard.Controls.Add(author);

            _settingsPermission = MakeLabel((_admin ? "当前以管理员权限运行" : "当前以标准权限运行") +
                "  ·  Win32 / x64", Theme.Ui(9.2f), _admin ? Theme.Success : Theme.Warning, Theme.Surface);
            _settingsPermission.Location = new Point(Theme.S(20f), Theme.S(102f));
            _settingsPermission.Size = new Size(Theme.S(360f), Theme.S(20f));
            aboutCard.Controls.Add(_settingsPermission);

            TextLabel disclaimer = MakeLabel("仅用于加载你信任的本地 DLL。使用第三方模块造成的封禁、崩溃或数据损失由使用者自行承担。",
                Theme.Ui(8.8f), Theme.Muted2, Theme.Surface);
            disclaimer.Location = new Point(Theme.S(20f), Theme.S(122f));
            disclaimer.Size = new Size(aboutCard.Width - Theme.S(40f), Theme.S(18f));
            disclaimer.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            aboutCard.Controls.Add(disclaimer);

            _adminButton = new PillButton();
            _adminButton.Text = "以管理员身份重启";
            _adminButton.Icon = IconGlyph.Shield;
            _adminButton.Primary = true;
            _adminButton.Size = new Size(Theme.S(156f), Theme.S(34f));
            _adminButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _adminButton.Click += delegate { AppPaths.RestartElevated(); };
            _adminButton.Visible = !_admin;
            aboutCard.Controls.Add(_adminButton);

            _pageSettings.Tag = new object[] { injectCard, folderCard, aboutCard, openDll, openLogs };
            RefreshDelayButtons();
            LayoutSettingsPage();
            _pageSettings.AttachMouseWheel(_settingsContent);
        }

        private void AddCardTitle(RoundedPanel card, string title, string subtitle)
        {
            TextLabel t = MakeLabel(title, Theme.Ui(13.2f, FontStyle.Bold), Theme.Text, Theme.Surface);
            t.Location = new Point(Theme.S(20f), Theme.S(14f));
            t.Size = new Size(Theme.S(300f), Theme.S(22f));
            card.Controls.Add(t);
            TextLabel s = MakeLabel(subtitle, Theme.Ui(8.9f), Theme.Muted2, Theme.Surface);
            s.Location = new Point(Theme.S(20f), Theme.S(36f));
            s.Size = new Size(card.Width - Theme.S(40f), Theme.S(18f));
            s.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            card.Controls.Add(s);
        }

        private void AddSettingLabel(RoundedPanel card, string title, string description, int y)
        {
            TextLabel t = MakeLabel(title, Theme.Ui(10.8f, FontStyle.Bold), Theme.TextSoft, Theme.Surface);
            t.Location = new Point(Theme.S(20f), y);
            t.Size = new Size(Theme.S(320f), Theme.S(20f));
            card.Controls.Add(t);
            TextLabel d = MakeLabel(description, Theme.Ui(8.8f), Theme.Muted2, Theme.Surface);
            d.Location = new Point(Theme.S(20f), y + Theme.S(20f));
            d.Size = new Size(Theme.S(380f), Theme.S(18f));
            card.Controls.Add(d);
        }

        private void RefreshDelayButtons()
        {
            int[] delays = new int[] { 1000, 2500, 4000, 6000 };
            for (int i = 0; i < _delayButtons.Count && i < delays.Length; i++)
            {
                bool selected = _config.InjectDelayMs == delays[i];
                _delayButtons[i].Primary = selected;
                _delayButtons[i].Invalidate();
            }
        }

        private void BeginCaptureHotkey(HotkeyTarget target)
        {
            if (_capturingHotkey)
            {
                if (_capturingHotkeyTarget == target)
                {
                    CancelHotkeyCapture();
                    return;
                }
                CancelHotkeyCapture();
            }
            _capturingHotkey = true;
            _capturingHotkeyTarget = target;
            PillButton button = HotkeyButton(target);
            if (button != null)
            {
                button.Text = "请按组合键…";
                button.Focus();
            }
        }

        private void CancelHotkeyCapture()
        {
            if (!_capturingHotkey) return;
            HotkeyTarget target = _capturingHotkeyTarget;
            _capturingHotkey = false;
            PillButton button = HotkeyButton(target);
            if (button == null) return;
            button.Text = HotkeyUtil.Format(HotkeyModifiers(target), HotkeyKey(target));
            button.Invalidate();
        }

        private void HotkeyButtonKeyDown(object sender, KeyEventArgs e)
        {
            if (!_capturingHotkey) return;
            e.SuppressKeyPress = true;
            e.Handled = true;

            if (e.KeyCode == Keys.Escape)
            {
                CancelHotkeyCapture();
                return;
            }
            if (HotkeyUtil.IsModifierKey(e.KeyCode)) return;

            uint modifiers = 0;
            if (e.Control) modifiers |= Native.MOD_CONTROL;
            if (e.Alt) modifiers |= Native.MOD_ALT;
            if (e.Shift) modifiers |= Native.MOD_SHIFT;
            if (modifiers == 0)
            {
                ShowToast("快捷键至少需要 Ctrl / Alt / Shift 之一", ToastKind.Warning);
                return;
            }

            HotkeyTarget target = _capturingHotkeyTarget;
            if (ApplyHotkey(target, modifiers, e.KeyCode, true))
            {
                _capturingHotkey = false;
                PillButton button = HotkeyButton(target);
                if (button != null) button.Invalidate();
            }
        }

        private bool ApplyHotkey(HotkeyTarget target, uint modifiers, Keys key, bool announce)
        {
            uint oldModifiers = HotkeyModifiers(target);
            Keys oldKey = HotkeyKey(target);
            bool oldRegistered = HotkeyRegistered(target);
            int id = HotkeyId(target);

            if (!HotkeyEnabled(target))
            {
                if (oldRegistered)
                {
                    try { Native.UnregisterHotKey(Handle, id); } catch { }
                }
                SetHotkeyState(target, modifiers, key, false);
                string disabledText = HotkeyUtil.Format(modifiers, key);
                SetHotkeyConfig(target, disabledText);
                _config.Save(AppPaths.ConfigFile);
                PillButton disabledButton = HotkeyButton(target);
                if (disabledButton != null) disabledButton.Text = disabledText;
                if (target == HotkeyTarget.Inject) UpdateHotkeyLabels(disabledText);
                Log.Info(HotkeyName(target) + "热键已更新但未启用：" + disabledText);
                if (announce) ShowToast(HotkeyName(target) + "快捷键已设置为 " + disabledText, ToastKind.Success);
                return true;
            }

            if (oldRegistered)
            {
                try { Native.UnregisterHotKey(Handle, id); } catch { }
                SetHotkeyState(target, oldModifiers, oldKey, false);
            }

            if (Native.RegisterHotKey(Handle, id, modifiers | Native.MOD_NOREPEAT, (uint)key))
            {
                SetHotkeyState(target, modifiers, key, true);
                string text = HotkeyUtil.Format(modifiers, key);
                SetHotkeyConfig(target, text);
                _config.Save(AppPaths.ConfigFile);
                PillButton button = HotkeyButton(target);
                if (button != null) button.Text = text;
                if (target == HotkeyTarget.Inject) UpdateHotkeyLabels(text);
                Log.Info(HotkeyName(target) + "热键已更新：" + text);
                if (announce) ShowToast(HotkeyName(target) + "快捷键已设置为 " + text, ToastKind.Success);
                return true;
            }

            if (oldRegistered)
            {
                try
                {
                    bool restored = Native.RegisterHotKey(Handle, id,
                        oldModifiers | Native.MOD_NOREPEAT, (uint)oldKey);
                    SetHotkeyState(target, oldModifiers, oldKey, restored);
                }
                catch { SetHotkeyState(target, oldModifiers, oldKey, false); }
            }
            PillButton oldButton = HotkeyButton(target);
            if (oldButton != null)
            {
                oldButton.Text = HotkeyUtil.Format(oldModifiers, oldKey);
                oldButton.Invalidate();
            }
            DialogForm.Warning(this, "快捷键不可用",
                "无法注册这个快捷键，它可能已被其他程序占用。\n\n请换一个组合键。");
            return false;
        }

        private void ResetHotkey(HotkeyTarget target)
        {
            string defaultText = HotkeyDefaultText(target);
            uint modifiers;
            Keys key;
            if (!HotkeyUtil.TryParse(defaultText, out modifiers, out key)) return;

            if (modifiers == HotkeyModifiers(target) && key == HotkeyKey(target))
            {
                PillButton button = HotkeyButton(target);
                if (button != null)
                {
                    button.Text = defaultText;
                    button.Invalidate();
                }
                ShowToast("当前已经是默认快捷键 " + defaultText, ToastKind.Info);
                return;
            }

            PillButton currentButton = HotkeyButton(target);
            if (currentButton != null)
            {
                currentButton.Text = defaultText;
                currentButton.Invalidate();
            }
            if (ApplyHotkey(target, modifiers, key, false))
                ShowToast(HotkeyName(target) + "快捷键已重置为 " + defaultText, ToastKind.Info);
        }

        private void SetHotkeyEnabled(HotkeyTarget target, bool enabled)
        {
            if (HotkeyEnabled(target) == enabled) return;
            SetHotkeyEnabledFlag(target, enabled);
            _config.Save(AppPaths.ConfigFile);

            if (!enabled)
            {
                UnregisterConfiguredHotkey(target);
                if (target == HotkeyTarget.Inject)
                    UpdateHotkeyLabels(HotkeyUtil.Format(HotkeyModifiers(target), HotkeyKey(target)));
                ShowToast(HotkeyName(target) + "快捷键已关闭", ToastKind.Info);
                return;
            }

            uint modifiers = HotkeyModifiers(target);
            Keys key = HotkeyKey(target);
            if (ApplyHotkey(target, modifiers, key, false))
            {
                ShowToast(HotkeyName(target) + "快捷键已启用", ToastKind.Success);
            }
            else
            {
                SetHotkeyEnabledFlag(target, false);
                _config.Save(AppPaths.ConfigFile);
                ToggleSwitch toggle = HotkeyEnableToggle(target);
                if (toggle != null) toggle.SetCheckedSilent(false);
            }
        }

        private bool HotkeyEnabled(HotkeyTarget target)
        {
            switch (target)
            {
                case HotkeyTarget.Launch: return _config.EnableLaunchHotkey;
                case HotkeyTarget.Close: return _config.EnableCloseHotkey;
                default: return _config.EnableInjectHotkey;
            }
        }

        private void SetHotkeyEnabledFlag(HotkeyTarget target, bool enabled)
        {
            switch (target)
            {
                case HotkeyTarget.Launch: _config.EnableLaunchHotkey = enabled; break;
                case HotkeyTarget.Close: _config.EnableCloseHotkey = enabled; break;
                default: _config.EnableInjectHotkey = enabled; break;
            }
        }

        private ToggleSwitch HotkeyEnableToggle(HotkeyTarget target)
        {
            switch (target)
            {
                case HotkeyTarget.Launch: return _launchHotkeyToggle;
                case HotkeyTarget.Close: return _closeHotkeyToggle;
                default: return _injectHotkeyToggle;
            }
        }

        private void RegisterConfiguredHotkey(HotkeyTarget target)
        {
            string fallback = HotkeyDefaultText(target);
            string configured = HotkeyConfig(target);
            uint modifiers;
            Keys key;
            if (!HotkeyUtil.TryParse(configured, out modifiers, out key))
            {
                HotkeyUtil.TryParse(fallback, out modifiers, out key);
                SetHotkeyConfig(target, fallback);
            }
            SetHotkeyState(target, modifiers, key, false);
            string text = HotkeyUtil.Format(modifiers, key);
            PillButton button = HotkeyButton(target);
            if (button != null) button.Text = text;
            if (target == HotkeyTarget.Inject) UpdateHotkeyLabels(text);
            if (!HotkeyEnabled(target))
            {
                Log.Info(HotkeyName(target) + "热键未启用：" + text);
                return;
            }
            bool registered = Native.RegisterHotKey(Handle, HotkeyId(target),
                modifiers | Native.MOD_NOREPEAT, (uint)key);
            SetHotkeyState(target, modifiers, key, registered);
            if (registered) Log.Info(HotkeyName(target) + "热键已注册：" + text);
            else
            {
                Log.Warn(HotkeyName(target) + "热键 " + text + " 注册失败，可能被其他程序占用");
                SetHotkeyEnabledFlag(target, false);
                ToggleSwitch toggle = HotkeyEnableToggle(target);
                if (toggle != null) toggle.SetCheckedSilent(false);
                _config.Save(AppPaths.ConfigFile);
            }
        }

        private void UnregisterConfiguredHotkey(HotkeyTarget target)
        {
            if (!HotkeyRegistered(target)) return;
            try { Native.UnregisterHotKey(Handle, HotkeyId(target)); } catch { }
            SetHotkeyState(target, HotkeyModifiers(target), HotkeyKey(target), false);
        }

        private int HotkeyId(HotkeyTarget target)
        {
            switch (target)
            {
                case HotkeyTarget.Launch: return HotkeyLaunchId;
                case HotkeyTarget.Close: return HotkeyCloseId;
                default: return HotkeyInjectId;
            }
        }

        private string HotkeyDefaultText(HotkeyTarget target)
        {
            switch (target)
            {
                case HotkeyTarget.Launch: return "Ctrl+2";
                case HotkeyTarget.Close: return "Ctrl+3";
                default: return HotkeyUtil.DefaultText;
            }
        }

        private string HotkeyName(HotkeyTarget target)
        {
            switch (target)
            {
                case HotkeyTarget.Launch: return "直接启动";
                case HotkeyTarget.Close: return "直接关闭";
                default: return "注入";
            }
        }

        private string HotkeyConfig(HotkeyTarget target)
        {
            switch (target)
            {
                case HotkeyTarget.Launch: return _config.LaunchHotkey;
                case HotkeyTarget.Close: return _config.CloseHotkey;
                default: return _config.InjectHotkey;
            }
        }

        private void SetHotkeyConfig(HotkeyTarget target, string text)
        {
            switch (target)
            {
                case HotkeyTarget.Launch: _config.LaunchHotkey = text; break;
                case HotkeyTarget.Close: _config.CloseHotkey = text; break;
                default: _config.InjectHotkey = text; break;
            }
        }

        private uint HotkeyModifiers(HotkeyTarget target)
        {
            switch (target)
            {
                case HotkeyTarget.Launch: return _launchHotkeyModifiers;
                case HotkeyTarget.Close: return _closeHotkeyModifiers;
                default: return _injectHotkeyModifiers;
            }
        }

        private Keys HotkeyKey(HotkeyTarget target)
        {
            switch (target)
            {
                case HotkeyTarget.Launch: return _launchHotkeyKey;
                case HotkeyTarget.Close: return _closeHotkeyKey;
                default: return _injectHotkeyKey;
            }
        }

        private bool HotkeyRegistered(HotkeyTarget target)
        {
            switch (target)
            {
                case HotkeyTarget.Launch: return _launchHotkeyRegistered;
                case HotkeyTarget.Close: return _closeHotkeyRegistered;
                default: return _hotkeyRegistered;
            }
        }

        private void SetHotkeyState(HotkeyTarget target, uint modifiers, Keys key, bool registered)
        {
            switch (target)
            {
                case HotkeyTarget.Launch:
                    _launchHotkeyModifiers = modifiers;
                    _launchHotkeyKey = key;
                    _launchHotkeyRegistered = registered;
                    break;
                case HotkeyTarget.Close:
                    _closeHotkeyModifiers = modifiers;
                    _closeHotkeyKey = key;
                    _closeHotkeyRegistered = registered;
                    break;
                default:
                    _injectHotkeyModifiers = modifiers;
                    _injectHotkeyKey = key;
                    _hotkeyRegistered = registered;
                    break;
            }
        }

        private PillButton HotkeyButton(HotkeyTarget target)
        {
            switch (target)
            {
                case HotkeyTarget.Launch: return _launchHotkeyButton;
                case HotkeyTarget.Close: return _closeHotkeyButton;
                default: return _hotkeyButton;
            }
        }

        private void UpdateHotkeyLabels(string text)
        {
            bool enabled = HotkeyEnabled(HotkeyTarget.Inject);
            if (_launchFooterNote != null)
                _launchFooterNote.Text = "所有 DLL 仅在本机加载；注入第三方模块前请确认来源可信。热键 " +
                    text + (enabled ? " 可注入运行中的游戏。" : "（快捷键未启用）");
            if (_moduleFooter != null)
                _moduleFooter.Text = "提示：直接拖入 .dll 文件即可导入；双击模块打开所在文件夹，右键可移除。按 " +
                    text + (enabled ? " 可注入运行中的游戏。" : "（快捷键未启用）");
        }

        private int CurrentWarmupSeconds()
        {
            int seconds = (int)Math.Round(_config.StartupWarmupMs / 1000.0, MidpointRounding.AwayFromZero);
            return Math.Max(0, Math.Min(60, seconds));
        }

        private void SetWarmupInput(int seconds)
        {
            if (_warmupInput == null) return;
            _warmupUpdating = true;
            _warmupInput.Text = seconds.ToString();
            _warmupUpdating = false;
        }

        private void ApplyStartupWarmup(bool showFeedback)
        {
            if (_warmupInput == null || _warmupUpdating) return;
            int seconds;
            if (!int.TryParse(_warmupInput.Text.Trim(), out seconds) || seconds < 0 || seconds > 60)
            {
                if (showFeedback) ShowToast("启动等待请输入 0-60 秒", ToastKind.Warning);
                SetWarmupInput(CurrentWarmupSeconds());
                return;
            }

            int milliseconds = seconds * 1000;
            if (milliseconds == _config.StartupWarmupMs)
            {
                if (showFeedback) ShowToast("启动等待已是 " + seconds + " 秒", ToastKind.Info);
                return;
            }
            _config.StartupWarmupMs = milliseconds;
            _config.Save(AppPaths.ConfigFile);
            Log.Info("启动等待已设置为 " + seconds + " 秒");
            if (showFeedback) ShowToast("启动等待已设置为 " + seconds + " 秒", ToastKind.Success);
        }

        private void ResetStartupWarmup()
        {
            _config.StartupWarmupMs = 10000;
            _config.Save(AppPaths.ConfigFile);
            SetWarmupInput(10);
            Log.Ok("启动等待已重置为默认 10 秒");
            ShowToast("启动等待已重置为 10 秒", ToastKind.Success);
        }

        private void LayoutSettingsPage()
        {
            if (_pageSettings == null || _settingsHeader == null) return;
            int pad = Theme.S(26f);
            int width = Math.Max(Theme.S(560f), _pageSettings.ClientSize.Width - pad * 2 - Theme.S(14f));
            _settingsHeader.Bounds = new Rectangle(pad, Theme.S(12f), width, Theme.S(66f));
            object[] data = _pageSettings.Tag as object[];
            if (data == null) return;
            RoundedPanel injectCard = (RoundedPanel)data[0];
            RoundedPanel folderCard = (RoundedPanel)data[1];
            RoundedPanel aboutCard = (RoundedPanel)data[2];
            PillButton openDll = (PillButton)data[3];
            PillButton openLogs = (PillButton)data[4];

            injectCard.Bounds = new Rectangle(pad, Theme.S(84f), width, Theme.S(472f));
            folderCard.Bounds = new Rectangle(pad, injectCard.Bottom + Theme.S(10f), width, Theme.S(114f));
            aboutCard.Bounds = new Rectangle(pad, folderCard.Bottom + Theme.S(10f), width, Theme.S(146f));

            int delayButtonW = Theme.S(58f);
            int delayGap = Theme.S(6f);
            int right = injectCard.Width - Theme.S(18f);
            for (int i = 0; i < _delayButtons.Count; i++)
            {
                int x = right - (_delayButtons.Count - i) * delayButtonW -
                        (_delayButtons.Count - 1 - i) * delayGap;
                _delayButtons[i].Location = new Point(x, Theme.S(56f));
            }
            if (_minimizeToggle != null)
                _minimizeToggle.Location = new Point(right - _minimizeToggle.Width, Theme.S(102f));
            if (_closeToggle != null)
                _closeToggle.Location = new Point(right - _closeToggle.Width, Theme.S(150f));
            if (_verifyToggle != null)
                _verifyToggle.Location = new Point(right - _verifyToggle.Width, Theme.S(198f));
            if (_warmupResetButton != null)
            {
                int warmupY = Theme.S(244f);
                _warmupResetButton.Location = new Point(right - _warmupResetButton.Width, warmupY);
                int unitWidth = Theme.S(16f);
                int rowCenter = warmupY + _warmupResetButton.Height / 2;
                int inputY = rowCenter - _warmupInput.Height / 2;
                if (inputY < warmupY) inputY = warmupY;
                int inputX = _warmupResetButton.Left - Theme.S(8f) - unitWidth -
                             Theme.S(4f) - _warmupInput.Width;
                _warmupInput.Location = new Point(inputX, inputY);
                int unitHeight = Theme.S(20f);
                _warmupUnit.Location = new Point(_warmupInput.Right + Theme.S(4f), rowCenter - unitHeight / 2);
                _warmupUnit.Size = new Size(unitWidth, unitHeight);
            }
            if (_hideToTrayToggle != null)
                _hideToTrayToggle.Location = new Point(right - _hideToTrayToggle.Width, Theme.S(294f));
            if (_hotkeyResetButton != null)
            {
                _hotkeyResetButton.Location = new Point(right - _hotkeyResetButton.Width, Theme.S(340f));
                _hotkeyButton.Location = new Point(_hotkeyResetButton.Left - Theme.S(8f) - _hotkeyButton.Width,
                    Theme.S(340f));
                if (_injectHotkeyToggle != null)
                    _injectHotkeyToggle.Location = new Point(
                        _hotkeyButton.Left - Theme.S(8f) - _injectHotkeyToggle.Width,
                        Theme.S(343f));
            }
            if (_launchHotkeyResetButton != null)
            {
                _launchHotkeyResetButton.Location = new Point(right - _launchHotkeyResetButton.Width, Theme.S(386f));
                _launchHotkeyButton.Location = new Point(_launchHotkeyResetButton.Left - Theme.S(8f) - _launchHotkeyButton.Width,
                    Theme.S(386f));
                if (_launchHotkeyToggle != null)
                    _launchHotkeyToggle.Location = new Point(
                        _launchHotkeyButton.Left - Theme.S(8f) - _launchHotkeyToggle.Width,
                        Theme.S(389f));
            }
            if (_closeHotkeyResetButton != null)
            {
                _closeHotkeyResetButton.Location = new Point(right - _closeHotkeyResetButton.Width, Theme.S(432f));
                _closeHotkeyButton.Location = new Point(_closeHotkeyResetButton.Left - Theme.S(8f) - _closeHotkeyButton.Width,
                    Theme.S(432f));
                if (_closeHotkeyToggle != null)
                    _closeHotkeyToggle.Location = new Point(
                        _closeHotkeyButton.Left - Theme.S(8f) - _closeHotkeyToggle.Width,
                        Theme.S(435f));
            }

            _settingsPath.Width = folderCard.Width - Theme.S(40f);
            openDll.Bounds = new Rectangle(Theme.S(20f), Theme.S(76f), Theme.S(148f), Theme.S(34f));
            openLogs.Bounds = new Rectangle(openDll.Right + Theme.S(8f), Theme.S(76f), Theme.S(148f), Theme.S(34f));
            openDll.BringToFront();
            openLogs.BringToFront();
            if (_adminButton != null)
            {
                _adminButton.Location = new Point(aboutCard.Width - Theme.S(20f) - _adminButton.Width, Theme.S(16f));
                _adminButton.BringToFront();
            }

            _pageSettings.SetContentHeight(aboutCard.Bottom + Theme.S(16f));
        }

        private TextLabel MakeLabel(string text, Font font, Color color)
        {
            return MakeLabel(text, font, color, Theme.Bg);
        }

        private TextLabel MakeLabel(string text, Font font, Color color, Color background)
        {
            TextLabel label = new TextLabel();
            label.Text = text;
            label.Font = font;
            label.ForeColor = color;
            label.BackColor = background;
            label.AutoSize = false;
            label.TextAlign = ContentAlignment.MiddleLeft;
            return label;
        }

        private void HookEvents()
        {
            EntryAdded();
            Log.EntryAdded += LogEntryAdded;
            _hero.LaunchModeToggleRequested += delegate { ToggleLaunchMode(); };

            _watcher = new FileSystemWatcher(AppPaths.DllDir, "*.dll");
            _watcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Size;
            _watcher.IncludeSubdirectories = false;
            _watcher.EnableRaisingEvents = true;
            _watcher.Created += WatcherChanged;
            _watcher.Changed += WatcherChanged;
            _watcher.Deleted += WatcherChanged;
            _watcher.Renamed += WatcherRenamed;

            _watchTimer = new System.Windows.Forms.Timer();
            _watchTimer.Interval = 500;
            _watchTimer.Tick += delegate
            {
                _watchTimer.Stop();
                if (_busy)
                {
                    _refreshPending = true;
                    return;
                }
                LoadDlls(false);
            };

            _gameWatchTimer = new System.Windows.Forms.Timer();
            _gameWatchTimer.Interval = 2000;
            _gameWatchTimer.Tick += GameWatchTick;
            _gameWatchTimer.Start();
        }

        private void GameWatchTick(object sender, EventArgs e)
        {
            bool running = GameLauncher.IsGameRunning();
            if (running == _lastGameRunning) return;
            _lastGameRunning = running;
            UpdateStats();
            UpdateHero();
            if (_busy) return;
            if (running)
            {
                SetStatus("游戏运行中", Theme.Success);
                SetActivity("游戏运行中");
                Log.Ok("检测到 Minecraft 已启动");
            }
            else
            {
                SetStatus("就绪", Theme.Success);
                SetActivity("等待启动");
                Log.Info("检测到 Minecraft 已退出");
            }
        }

        private void EntryAdded()
        {
            if (_logView == null) return;
            _logView.Clear();
            foreach (LogEntry entry in Log.Snapshot()) _logView.AppendEntry(entry);
            _logView.AppendRaw("—— 日志已就绪 ——", Theme.Muted2);
        }

        private void LogEntryAdded(LogEntry entry)
        {
            if (_logView == null) return;
            if (InvokeRequired)
            {
                try { BeginInvoke(new Action<LogEntry>(LogEntryAdded), entry); } catch { }
                return;
            }
            _logView.AppendEntry(entry);
        }

        private void WatcherChanged(object sender, FileSystemEventArgs e)
        {
            try
            {
                if (IsDisposed || !IsHandleCreated) return;
                BeginInvoke(new Action(delegate
                {
                    if (_watchTimer == null || IsDisposed) return;
                    _watchTimer.Stop();
                    _watchTimer.Start();
                }));
            }
            catch { }
        }

        private void WatcherRenamed(object sender, RenamedEventArgs e)
        {
            WatcherChanged(sender, e);
        }

        private void MainFormKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                if (_page == PageKind.Resources)
                {
                    RefreshContentAsync(true);
                }
                else
                {
                    LoadDlls(false);
                    ShowToast("模块列表已刷新", ToastKind.Info);
                }
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Escape && _busy)
            {
                e.Handled = true;
            }
        }

        private void SwitchPage(PageKind page)
        {
            _page = page;
            _pageLaunch.Visible = page == PageKind.Launch;
            if (_pageProfiles != null) _pageProfiles.Visible = page == PageKind.Profiles;
            _pageModules.Visible = page == PageKind.Modules;
            if (_pageResources != null) _pageResources.Visible = page == PageKind.Resources;
            _pageLogs.Visible = page == PageKind.Logs;
            _pageSettings.Visible = page == PageKind.Settings;
            if (_sidebar != null) _sidebar.Invalidate();
            switch (page)
            {
                case PageKind.Launch: _breadcrumb = "启动中心"; break;
                case PageKind.Profiles: _breadcrumb = "游戏档案"; break;
                case PageKind.Modules: _breadcrumb = "DLL 模块"; break;
                case PageKind.Resources: _breadcrumb = "资源库"; break;
                case PageKind.Logs: _breadcrumb = "运行日志"; break;
                case PageKind.Settings: _breadcrumb = "设置"; break;
            }
            _titlebar.Invalidate();
            if (page == PageKind.Profiles)
            {
                RefreshProfileList();
                if (_addProfileButton != null) _addProfileButton.Focus();
            }
            else if (page == PageKind.Modules && _dllList != null) _dllList.Focus();
            else if (page == PageKind.Resources && _contentList != null)
            {
                string key = ContentCacheKey(_profile);
                if (_content == null ||
                    !string.Equals(key, _contentCacheKey, StringComparison.OrdinalIgnoreCase))
                    RefreshContent(false);
                else if (_contentDirty)
                    RefreshContentAsync(false);
                _contentList.Focus();
            }
        }

        private void SetStatus(string text, Color color)
        {
            if (IsDisposed) return;
            _statusText = text;
            _statusColor = color;
            if (_titlebar != null) _titlebar.Invalidate();
            if (_launchBadge != null)
                _launchBadge.SetData(text, color, Theme.Alpha(color, 20), Theme.Alpha(color, 70));
            UpdateHero();
        }

        private void SetActivity(string text)
        {
            if (IsDisposed) return;
            _activityText = text;
            if (_sidebar != null) _sidebar.Invalidate();
        }

        private void UpdateEverything()
        {
            if (IsDisposed) return;
            UpdateDllUi();
            UpdateHero();
            UpdateStats();
        }

        private void EndRunningGame()
        {
            if (_busy)
            {
                ShowToast("正在启动或注入，暂时不能结束游戏", ToastKind.Warning);
                return;
            }
            if (!GameLauncher.IsGameRunning())
            {
                ShowToast("当前没有运行中的游戏", ToastKind.Info);
                return;
            }

            bool confirmed = DialogForm.Confirm(this, "结束游戏",
                "确定要结束正在运行的 Minecraft 吗？\n\n" +
                "这会强制关闭游戏进程，未保存的世界进度可能丢失。", "结束游戏");
            if (!confirmed) return;

            string error;
            int killed = GameLauncher.KillRunningGame(out error);
            if (killed > 0)
            {
                Log.Ok("已结束 " + killed + " 个 Minecraft 游戏进程");
                SetStatus("游戏已结束", Theme.Muted);
                SetActivity("游戏已结束");
                UpdateEverything();
                ShowToast("已结束游戏进程", ToastKind.Success);
                if (!string.IsNullOrEmpty(error)) Log.Warn("部分游戏进程结束失败：" + error);
            }
            else
            {
                Log.Error("结束游戏失败：" + (string.IsNullOrEmpty(error) ? "未找到可结束的进程" : error));
                DialogForm.Error(this, "结束游戏失败",
                    string.IsNullOrEmpty(error) ? "没有找到可结束的 Minecraft 游戏进程。" : error);
            }
        }

        private void EndGameFromTray(string source)
        {
            if (_busy)
            {
                ShowTrayNotice("正在启动或注入，暂时不能结束游戏");
                return;
            }
            if (!GameLauncher.IsGameRunning())
            {
                ShowTrayNotice("当前没有运行中的 Minecraft");
                return;
            }

            string error;
            int killed = GameLauncher.KillRunningGame(out error);
            if (killed > 0)
            {
                Log.Ok(source + "结束当前进程：已结束 " + killed + " 个 Minecraft 游戏进程");
                _lastGameRunning = false;
                UpdateEverything();
                SetStatus("游戏已结束", Theme.Muted);
                SetActivity("游戏已结束");
                ShowTrayNotice("已结束 Minecraft 游戏进程");
                if (!string.IsNullOrEmpty(error))
                    Log.Warn("部分游戏进程结束失败：" + error);
            }
            else
            {
                Log.Warn(source + "结束当前进程失败：" +
                    (string.IsNullOrEmpty(error) ? "未找到可结束的进程" : error));
                ShowTrayNotice("结束游戏失败");
            }
        }

        private void UpdateHero()
        {
            if (IsDisposed || _hero == null) return;
            int enabled = 0;
            foreach (DllInfo d in _dlls) if (d.Enabled) enabled++;
            bool running = GameLauncher.IsGameRunning();
            bool available = IsGameAvailable();
            string status = _busy ? "正在处理" : (running ? "游戏运行中" : (available ? "游戏未运行" : "档案不可用"));
            Color color = _busy ? Theme.Accent2 : (running ? Theme.Success : (available ? Theme.Muted : Theme.Warning));
            _hero.SetState(_minecraft.Version, enabled, _dlls.Count, available, status, color, _busy, running);
            _hero.SetLaunchMode(_config.LaunchWithDlls, _busy);
        }

        private void ToggleLaunchMode()
        {
            if (_busy) return;
            _config.LaunchWithDlls = !_config.LaunchWithDlls;
            _config.Save(AppPaths.ConfigFile);
            if (_hero != null) _hero.SetLaunchMode(_config.LaunchWithDlls, _busy);
            Log.Info("启动模式已切换为：" + (_config.LaunchWithDlls ? "带 DLL 启动" : "仅启动游戏"));
            ShowToast(_config.LaunchWithDlls ? "启动模式：带 DLL 注入" : "启动模式：仅启动游戏",
                ToastKind.Info);
        }

        private bool IsCustomProfileSelected()
        {
            GameProfile profile = _config.GetSelectedProfile();
            return profile != null && !profile.IsOfficial && !string.IsNullOrWhiteSpace(profile.LaunchPath);
        }

        private bool IsGameAvailable()
        {
            GameProfile profile = _config.GetSelectedProfile();
            if (profile == null) return _minecraft.Found;
            if (profile.IsOfficial) return _minecraft.Found;
            return !string.IsNullOrWhiteSpace(profile.LaunchPath) && File.Exists(profile.LaunchPath);
        }

        private void UpdateLaunchPathUi()
        {
            if (_launchPathValue == null) return;
            GameProfile profile = _config.GetSelectedProfile();
            if (profile == null)
            {
                _launchPathValue.Text = "未选择游戏档案";
                _launchPathValue.ForeColor = Theme.Warning;
                _tooltip.SetToolTip(_launchPathValue, string.Empty);
                return;
            }

            if (profile.IsOfficial)
            {
                _launchPathValue.Text = profile.Name + "  ·  Microsoft Store 官方启动";
                _launchPathValue.ForeColor = Theme.TextSoft;
                _tooltip.SetToolTip(_launchPathValue, "使用 Microsoft Store 官方启动方式");
            }
            else
            {
                bool exists = !string.IsNullOrWhiteSpace(profile.LaunchPath) && File.Exists(profile.LaunchPath);
                _launchPathValue.Text = profile.Name + "  ·  " +
                    (string.IsNullOrWhiteSpace(profile.LaunchPath) ? "未设置启动路径" : profile.LaunchPath) +
                    (exists ? string.Empty : "（路径不存在）");
                _launchPathValue.ForeColor = exists ? Theme.TextSoft : Theme.Warning;
                _tooltip.SetToolTip(_launchPathValue, profile.LaunchPath);
            }
            _launchPathResetButton.Enabled = true;
        }

        private void ShowLaunchProfileMenu()
        {
            if (_launchProfileMenu != null)
            {
                try { _launchProfileMenu.Dispose(); } catch { }
                _launchProfileMenu = null;
            }
            ContextMenuStrip menu = new ContextMenuStrip();
            _launchProfileMenu = menu;
            menu.Renderer = new DarkMenuRenderer();
            menu.BackColor = Theme.Surface2;
            menu.ForeColor = Theme.TextSoft;
            menu.ShowImageMargin = false;

            GameProfile selected = _config.GetSelectedProfile();
            foreach (GameProfile profile in _config.Profiles)
            {
                GameProfile captured = profile;
                ToolStripMenuItem item = new ToolStripMenuItem(profile.Name + (profile.IsOfficial ? "（官方）" : string.Empty));
                item.Checked = selected != null && string.Equals(selected.Id, profile.Id, StringComparison.OrdinalIgnoreCase);
                item.Tag = captured;
                item.Click += delegate { SelectGameProfile(captured); };
                menu.Items.Add(item);
            }
            menu.Items.Add(new ToolStripSeparator());
            ToolStripMenuItem manage = new ToolStripMenuItem("管理游戏档案…");
            manage.Click += delegate { SwitchPage(PageKind.Profiles); };
            menu.Items.Add(manage);
            menu.Show(_launchPathBrowseButton, new Point(0, _launchPathBrowseButton.Height + Theme.S(4f)));
        }

        private void UpdateStats()
        {
            if (IsDisposed) return;
            int enabled = 0;
            foreach (DllInfo d in _dlls) if (d.Enabled) enabled++;
            _statModules.SetData("已启用模块", enabled + " / " + _dlls.Count,
                _dlls.Count == 0 ? "等待添加 DLL" : "启动时自动注入", IconGlyph.Puzzle, Theme.Accent);

            bool running = GameLauncher.IsGameRunning();
            bool available = IsGameAvailable();
            GameProfile selectedProfile = _config.GetSelectedProfile();
            bool custom = selectedProfile != null && !selectedProfile.IsOfficial;
            _statGame.SetData("游戏状态", !available ? "不可用" : (running ? "运行中" : "未运行"),
                !available ? "请在游戏档案中检查" : (custom ? "档案：" + selectedProfile.Name : "Minecraft v" + _minecraft.Version),
                IconGlyph.Cube, running ? Theme.Success : Theme.Accent2);

            _statPermission.SetData("运行权限", _admin ? "管理员" : "标准",
                _admin ? "进程注入权限就绪" : "建议以管理员运行", IconGlyph.Shield,
                _admin ? Theme.Success : Theme.Warning);
            if (_sidebar != null) _sidebar.Invalidate();
        }

        private void UpdateDllUi()
        {
            if (_modulesHeader != null)
                _modulesHeader.Subtitle = _dlls.Count + " 个模块 · 所有已启用的 DLL 会在启动游戏后自动注入";
            if (_dllList != null) _dllList.SetDlls(_dlls);
            if (_moduleStrip != null) _moduleStrip.SetDlls(_dlls);
        }

        private void LoadDlls(bool initial)
        {
            _dlls = DllManager.Scan(AppPaths.DllDir, _config);
            // Prune config entries for files that no longer exist.
            List<string> keys = new List<string>(_config.DllStates.Keys);
            foreach (string key in keys)
            {
                bool exists = false;
                foreach (DllInfo d in _dlls) if (string.Equals(d.FileName, key, StringComparison.OrdinalIgnoreCase)) { exists = true; break; }
                if (!exists) _config.DllStates.Remove(key);
            }
            foreach (DllInfo d in _dlls)
            {
                if (!_config.DllStates.ContainsKey(d.FileName)) _config.DllStates[d.FileName] = d.Enabled;
            }
            try { _config.Save(AppPaths.ConfigFile); } catch { }
            UpdateEverything();
            if (_page == PageKind.Modules && _dllList != null) _dllList.Invalidate();
            if (!initial) SetStatus("已刷新", Theme.Success);
        }

        private void ToggleAll()
        {
            bool anyDisabled = false;
            foreach (DllInfo d in _dlls) if (!d.Enabled) { anyDisabled = true; break; }
            foreach (DllInfo d in _dlls)
            {
                d.Enabled = anyDisabled;
                _config.SetDllState(d.FileName, d.Enabled);
            }
            _config.Save(AppPaths.ConfigFile);
            UpdateEverything();
            ShowToast(anyDisabled ? "已启用全部模块" : "已禁用全部模块", ToastKind.Info);
        }

        private void DllListToggleRequested(object sender, DllRow row)
        {
            if (row == null || row.Item == null || _busy) return;
            DllInfo d = row.Item;
            d.Enabled = !d.Enabled;
            _config.SetDllState(d.FileName, d.Enabled);
            _config.Save(AppPaths.ConfigFile);
            if (!d.Enabled && (d.State == DllState.Failed || d.State == DllState.Loaded)) d.State = DllState.Ready;
            _dllList.RefreshStates();
            UpdateHero();
            UpdateStats();
            if (_moduleStrip != null) _moduleStrip.SetDlls(_dlls);
        }

        private void ToggleDllBatch()
        {
            _dllBatchMode = !_dllBatchMode;
            if (_dllBatchMode && _dlls.Count == 0)
            {
                _dllBatchMode = false;
                ShowToast("没有可批量管理的 DLL", ToastKind.Info);
                return;
            }
            _dllBatchBar.Visible = _dllBatchMode;
            _dllList.SetBatchMode(_dllBatchMode);
            _batchDllsButton.Text = _dllBatchMode ? "退出批量" : "批量管理";
            _batchDllsButton.Invalidate();
            object[] buttons = _pageModules.Tag as object[];
            if (buttons != null)
                for (int i = 0; i < 4; i++)
                    ((PillButton)buttons[i]).Enabled = !_dllBatchMode;
            UpdateDllBatchCount();
            LayoutModulesPage();
        }

        private void UpdateDllBatchCount()
        {
            if (_dllBatchBar != null && _dllList != null)
                _dllBatchBar.SetCount(_dllList.SelectedDlls().Count);
        }

        private void SetSelectedDllsEnabled(bool enabled)
        {
            List<DllInfo> selected = _dllList.SelectedDlls();
            if (selected.Count == 0)
            {
                ShowToast("请先选择 DLL", ToastKind.Info);
                return;
            }
            foreach (DllInfo dll in selected)
            {
                dll.Enabled = enabled;
                _config.SetDllState(dll.FileName, enabled);
                if (!enabled && (dll.State == DllState.Failed || dll.State == DllState.Loaded))
                    dll.State = DllState.Ready;
            }
            _config.Save(AppPaths.ConfigFile);
            _dllList.RefreshStates();
            UpdateHero();
            UpdateStats();
            if (_moduleStrip != null) _moduleStrip.SetDlls(_dlls);
            Log.Info("批量" + (enabled ? "启用" : "禁用") + "了 " + selected.Count + " 个 DLL");
            ShowToast("已" + (enabled ? "启用" : "禁用") + " " + selected.Count + " 个 DLL", ToastKind.Success);
        }

        private void RemoveSelectedDlls()
        {
            List<DllInfo> selected = _dllList.SelectedDlls();
            if (selected.Count == 0)
            {
                ShowToast("请先选择 DLL", ToastKind.Info);
                return;
            }
            bool ok = DialogForm.Confirm(this, "批量移除 DLL",
                "确定要把选中的 " + selected.Count + " 个 DLL 移到 DLLs\\.trash 吗？\n\n" +
                "游戏正在运行时可能无法移动已加载的 DLL。", "移除");
            if (!ok) return;
            int removed = 0;
            foreach (DllInfo dll in selected)
            {
                string message;
                if (DllManager.Archive(dll.FilePath, out message))
                {
                    _config.DllStates.Remove(dll.FileName);
                    removed++;
                }
                else
                {
                    Log.Error("批量移除失败：" + dll.FileName + " - " + message);
                }
            }
            _config.Save(AppPaths.ConfigFile);
            LoadDlls(false);
            UpdateDllBatchCount();
            Log.Ok("批量移除了 " + removed + " 个 DLL");
            ShowToast("已移除 " + removed + " 个 DLL", ToastKind.Success);
        }

        private void DllListRemoveRequested(object sender, DllRow row)
        {
            if (row == null || row.Item == null || _busy) return;
            DllInfo d = row.Item;
            bool ok = DialogForm.Confirm(this, "移除模块",
                "确定要把 “" + d.FileName + "” 移到 DLLs\\.trash 吗？\n\n游戏正在运行时可能无法移动已加载的 DLL。", "移除");
            if (!ok) return;
            string message;
            if (DllManager.Archive(d.FilePath, out message))
            {
                _config.DllStates.Remove(d.FileName);
                _config.Save(AppPaths.ConfigFile);
                Log.Ok("已移除 " + d.FileName);
                LoadDlls(false);
                ShowToast("已移除 " + d.FileName, ToastKind.Success);
            }
            else
            {
                Log.Error("移除失败：" + message);
                DialogForm.Error(this, "移除失败", "无法移动这个 DLL：\n" + message + "\n\n请关闭游戏后重试。");
            }
        }

        private void DllListContextRequested(object sender, DllRow row)
        {
            if (row == null || row.Item == null) return;
            ContextMenuStrip menu = new ContextMenuStrip();
            menu.Renderer = new DarkMenuRenderer();
            menu.BackColor = Theme.Surface2;
            menu.ForeColor = Theme.TextSoft;
            menu.ShowImageMargin = false;
            ToolStripMenuItem open = new ToolStripMenuItem("打开所在文件夹");
            open.Click += delegate { AppPaths.OpenDllFolder(); };
            ToolStripMenuItem toggle = new ToolStripMenuItem(row.Item.Enabled ? "禁用此模块" : "启用此模块");
            toggle.Click += delegate { DllListToggleRequested(sender, row); };
            ToolStripMenuItem remove = new ToolStripMenuItem("移除到回收目录");
            remove.ForeColor = Theme.Danger;
            remove.Click += delegate { DllListRemoveRequested(sender, row); };
            menu.Items.Add(open);
            menu.Items.Add(toggle);
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(remove);
            menu.Show(Cursor.Position);
        }

        private void AddDlls()
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "选择要注入的 DLL（可多选）";
                dialog.Filter = "DLL 文件 (*.dll)|*.dll";
                dialog.Multiselect = true;
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                ImportFiles(dialog.FileNames);
            }
        }

        private void ImportFiles(IEnumerable<string> files)
        {
            List<string> list = new List<string>(files);
            if (list.Count == 0) return;

            list.Sort(StringComparer.OrdinalIgnoreCase);
            string signature = string.Join("|", list.ToArray()).ToLowerInvariant();
            if (string.Equals(signature, _lastDropSignature, StringComparison.OrdinalIgnoreCase) &&
                (DateTime.Now - _lastDropTime).TotalMilliseconds < 1500)
                return;
            _lastDropSignature = signature;
            _lastDropTime = DateTime.Now;

            bool overwrite = false;
            bool hasExisting = false;
            foreach (string file in list)
            {
                string dest = Path.Combine(AppPaths.DllDir, Path.GetFileName(file));
                if (File.Exists(dest) && !string.Equals(Path.GetFullPath(dest), Path.GetFullPath(file), StringComparison.OrdinalIgnoreCase))
                {
                    hasExisting = true;
                    break;
                }
            }
            if (hasExisting)
            {
                bool replace = DialogForm.Confirm(this, "发现同名 DLL",
                    "DLLs 文件夹中已经存在同名文件。\n\n选择“覆盖”会替换旧文件，选择“取消”则跳过同名文件。", "覆盖");
                overwrite = replace;
            }

            ImportResult result = DllManager.Import(list, AppPaths.DllDir, overwrite);
            foreach (string name in result.Imported) Log.Ok("已导入 " + name);
            foreach (string name in result.Skipped) Log.Warn("跳过 " + name);
            foreach (string error in result.Errors) Log.Error("导入失败：" + error);
            LoadDlls(false);
            if (result.Imported.Count > 0)
            {
                ShowToast("已导入 " + result.Imported.Count + " 个 DLL", ToastKind.Success);
                SwitchPage(PageKind.Modules);
            }
            else if (result.Errors.Count > 0)
            {
                DialogForm.Error(this, "导入失败", string.Join("\n", result.Errors.ToArray()));
            }
            else
            {
                ShowToast("没有导入新文件", ToastKind.Warning);
            }
        }

        private static bool IsContentFile(string file)
        {
            string extension = Path.GetExtension(file).ToLowerInvariant();
            return extension == ".mcpack" || extension == ".mcaddon" || extension == ".mcworld" ||
                   extension == ".mctemplate" || extension == ".zip";
        }

        private void HandleDroppedFiles(IEnumerable<string> files)
        {
            if (files == null) return;
            List<string> dlls = new List<string>();
            List<string> content = new List<string>();
            foreach (string file in files)
            {
                if (string.IsNullOrEmpty(file)) continue;
                if (string.Equals(Path.GetExtension(file), ".dll", StringComparison.OrdinalIgnoreCase)) dlls.Add(file);
                else if (IsContentFile(file)) content.Add(file);
            }
            if (dlls.Count > 0) ImportFiles(dlls);
            if (content.Count > 0)
            {
                if (_page != PageKind.Resources) SwitchPage(PageKind.Resources);
                ImportContent(content);
            }
        }

        private void MainFormDragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = e.Data.GetData(DataFormats.FileDrop) as string[];
                if (files != null)
                {
                    foreach (string file in files)
                    {
                        if (string.Equals(Path.GetExtension(file), ".dll", StringComparison.OrdinalIgnoreCase) ||
                            IsContentFile(file))
                        {
                            e.Effect = DragDropEffects.Copy;
                            return;
                        }
                    }
                }
            }
            e.Effect = DragDropEffects.None;
        }

        private void MainFormDragDrop(object sender, DragEventArgs e)
        {
            string[] files = e.Data.GetData(DataFormats.FileDrop) as string[];
            if (files == null) return;
            HandleDroppedFiles(files);
        }

        private async Task StartFromTrayAsync()
        {
            await StartPresetAsync("托盘直接启动", false);
        }

        private async Task StartPresetAsync(string trigger, bool skipWait)
        {
            if (_busy)
            {
                ShowTrayNotice("正在启动或注入，请稍候");
                return;
            }

            GameProfile profile = _config.GetSelectedProfile();
            if (profile == null || !IsGameAvailable())
            {
                ShowTrayNotice("游戏档案不可用，请打开界面检查");
                RestoreFromTray();
                return;
            }

            int enabled = 0;
            foreach (DllInfo dll in _dlls) if (dll.Enabled) enabled++;
            if (enabled == 0 && _config.LaunchWithDlls)
            {
                bool ignored;
                bool launchWithoutDlls = DialogForm.ConfirmWithOption(this, "没有可注入的 DLL",
                    "DLLs 文件夹中没有已启用的模块。\n\n是否跳过 DLL，直接启动 Minecraft？",
                    "直接启动", "取消", null, out ignored);
                if (!launchWithoutDlls) return;
                Log.Info(trigger + "：档案 " + profile.Name + "，本次仅启动游戏");
                await StartGameAsync(true, skipWait);
                return;
            }
            if (enabled == 0)
            {
                Log.Info(trigger + "：档案 " + profile.Name + "，仅启动模式，未启用 DLL");
                await StartGameAsync(false, skipWait);
                return;
            }

            Log.Info(trigger + "：档案 " + profile.Name + "，启用 DLL " + enabled + " 个");
            await StartGameAsync(false, skipWait);
        }

        private async Task StartGameAsync(bool skipNoDllPrompt = false, bool skipWait = false, bool forceInject = false)
        {
            if (_busy) return;
            List<DllInfo> enabled = new List<DllInfo>();
            foreach (DllInfo d in _dlls) if (d.Enabled) enabled.Add(d);
            GameProfile launchProfile = _config.GetSelectedProfile();
            bool customLaunch = launchProfile != null && !launchProfile.IsOfficial;
            bool customPathValid = customLaunch && !string.IsNullOrWhiteSpace(launchProfile.LaunchPath) &&
                                   File.Exists(launchProfile.LaunchPath);
            bool available = launchProfile != null && (launchProfile.IsOfficial ? _minecraft.Found : customPathValid);
            bool launchOnly = !forceInject && !_config.LaunchWithDlls;
            if (enabled.Count == 0)
            {
                if (!available)
                {
                    if (customLaunch)
                    {
                        DialogForm.Error(this, "游戏档案不可用",
                            "档案 “" + launchProfile.Name + "” 的启动路径不存在：\n\n" +
                            (string.IsNullOrWhiteSpace(launchProfile.LaunchPath) ? "（未设置）" : launchProfile.LaunchPath) +
                            "\n\n请到“游戏档案”重新设置启动路径。");
                    }
                    else
                    {
                        bool openStore = DialogForm.Show(this, "未检测到 Minecraft",
                            "没有在系统中找到 Minecraft for Windows（基岩版）。\n\n请先从 Microsoft Store 安装正版游戏。",
                            DialogKind.Warning, "打开 Microsoft Store", "取消", true);
                        if (openStore) GameLauncher.OpenStore();
                    }
                    return;
                }

                if (_config.LaunchWithDlls && !skipNoDllPrompt)
                {
                    bool skipDlls = DialogForm.Show(this, "没有可注入的 DLL",
                        "DLLs 文件夹中没有已启用的模块。\n\n是否跳过 DLL，直接启动 Minecraft？\n\n" +
                        "选择“直接启动”后，本次不会注入任何 DLL。",
                        DialogKind.Question, "直接启动", "取消", true);
                    if (!skipDlls)
                    {
                        SwitchPage(PageKind.Modules);
                        return;
                    }
                }
                launchOnly = true;
            }

            if (!available)
            {
                if (customLaunch)
                {
                    DialogForm.Error(this, "游戏档案不可用",
                        "档案 “" + launchProfile.Name + "” 的启动路径不存在：\n\n" +
                        (string.IsNullOrWhiteSpace(launchProfile.LaunchPath) ? "（未设置）" : launchProfile.LaunchPath) +
                        "\n\n请到“游戏档案”重新设置启动路径。");
                }
                else
                {
                    bool openStore = DialogForm.Show(this, "未检测到 Minecraft",
                        "没有在系统中找到 Minecraft for Windows（基岩版）。\n\n请先从 Microsoft Store 安装正版游戏。",
                        DialogKind.Warning, "打开 Microsoft Store", "取消", true);
                    if (openStore) GameLauncher.OpenStore();
                }
                return;
            }

            if (!launchOnly && _config.VerifyArchitecture)
            {
                List<string> bad = new List<string>();
                foreach (DllInfo d in enabled)
                {
                    if (d.Pe == null || !d.Pe.Valid || !d.Pe.IsDll)
                        bad.Add(d.FileName + "（不是有效的 DLL）");
                    else if (d.Pe.Architecture != PeArchitecture.X64)
                        bad.Add(d.FileName + "（" + d.Pe.ArchitectureText + "）");
                }
                if (bad.Count > 0)
                {
                    DialogForm.Error(this, "DLL 架构不匹配",
                        "以下模块不是 64 位 DLL，无法注入 Minecraft for Windows：\n\n" +
                        string.Join("\n", bad.ToArray()) +
                        "\n\n请更换 64 位版本，或在设置中关闭架构检查。");
                    return;
                }
            }

            _busy = true;
            _cts = new CancellationTokenSource();
            CancellationToken token = _cts.Token;
            SetBusyUi(true);
            Process game = null;
            int success = 0;
            int failed = 0;
            int skipped = 0;
            bool minimizedForInjection = false;
            bool startedByUs = false;
            try
            {
                Log.Info("—— 开始启动流程 ——");
                foreach (DllInfo d in enabled) d.State = DllState.Ready;
                _dllList.RefreshStates();

                if (_config.MinimizeAfterInject && !_config.CloseAfterInject && WindowState == FormWindowState.Normal)
                {
                    WindowState = FormWindowState.Minimized;
                    minimizedForInjection = true;
                    Log.Info("启动器已按设置最小化，游戏启动和注入将在后台继续");
                }

                game = GameLauncher.FindRunningGame();
                if (game != null)
                {
                    if (launchOnly)
                    {
                        GameLauncher.Focus(game);
                        SetStatus("游戏运行中", Theme.Success);
                        SetActivity("未注入 DLL");
                        Log.Info("已跳过 DLL，Minecraft 已在运行，PID " + game.Id);
                        ShowToast("已跳过 DLL，游戏正在运行", ToastKind.Info);
                        ShowTrayNotice("Minecraft 正在运行");
                        await ApplyPostLaunchBehaviorAsync();
                        return;
                    }
                    SetStatus("连接游戏", Theme.Accent2);
                    SetActivity("检测到游戏运行中");
                    Log.Ok("检测到游戏已在运行，PID " + game.Id + "，将直接注入");
                    await Task.Delay(300, token);
                }
                else
                {
                    SetStatus("启动游戏", Theme.Accent2);
                    SetActivity("正在启动 " + (launchProfile != null ? launchProfile.Name : "Minecraft"));
                    Log.Info("正在启动档案：" + (launchProfile != null ? launchProfile.Name : "Minecraft") +
                             (customLaunch ? (" · " + launchProfile.LaunchPath) : " · Microsoft Store"));
                    int launchPid = GameLauncher.Launch(_minecraft, customLaunch ? launchProfile.LaunchPath : string.Empty);
                    startedByUs = true;
                    if (launchPid > 0) Log.Info("游戏激活进程 PID " + launchPid);
                    SetStatus("等待游戏窗口", Theme.Accent2);
                    game = await GameLauncher.WaitForWindowAsync(150000, delegate(int seconds)
                    {
                        SetStatus("等待窗口 " + seconds + "s", Theme.Accent2);
                        SetActivity("等待游戏窗口 " + seconds + " 秒");
                    }, token);
                    Log.Ok("检测到游戏窗口，PID " + game.Id);
                }

                if (launchOnly)
                {
                    SetStatus("游戏已启动", Theme.Success);
                    SetActivity("未注入 DLL");
                    Log.Ok("已跳过 DLL，Minecraft 已启动");
                    ShowToast("已跳过 DLL，游戏已启动", ToastKind.Info);
                    if (startedByUs) ShowTrayNotice("Minecraft 已启动");
                    await ApplyPostLaunchBehaviorAsync();
                    return;
                }

                // Injection only needs the target PID; the launcher was already
                // minimized right after the launch request.
                PrepareGameWindow(game);

                if (!skipWait && startedByUs && _config.StartupWarmupMs > 0)
                {
                    int warmup = _config.StartupWarmupMs;
                    SetStatus("等待游戏初始化", Theme.Accent2);
                    SetActivity("等待游戏加载 " + ((warmup + 500) / 1000) + " 秒");
                    Log.Info("等待游戏初始化 " + warmup + " ms 后再注入");
                    await Task.Delay(warmup, token);
                }

                if (skipWait)
                {
                    SetStatus("准备注入", Theme.Accent2);
                    SetActivity("快捷键启动，跳过等待");
                    Log.Info("快捷键启动：跳过启动等待和注入延迟");
                }
                else
                {
                    int delay = _config.InjectDelayMs;
                    SetStatus("等待初始化", Theme.Accent2);
                    SetActivity("等待游戏初始化 " + (delay / 1000.0).ToString("0.0") + " 秒");
                    Log.Info("等待 " + delay + " ms 后开始注入");
                    await Task.Delay(delay, token);
                }

                // The game may have been minimized while waiting; restore it
                // right before injecting so a suspended UWP process can run
                // the remote LoadLibrary call.
                PrepareGameWindow(game);

                int index = 0;
                foreach (DllInfo dll in enabled)
                {
                    token.ThrowIfCancellationRequested();
                    index++;
                    dll.State = DllState.Injecting;
                    dll.StateDetail = string.Empty;
                    _dllList.RefreshStates();
                    SetStatus("注入 " + index + "/" + enabled.Count, Theme.Accent2);
                    SetActivity("注入 " + dll.FileName);
                    Log.Info("正在注入 [" + index + "/" + enabled.Count + "] " + dll.FileName);
                    string path = dll.FilePath;
                    int pid = game.Id;
                    InjectResult result = await Task.Run(delegate { return Injector.Inject(pid, path, true); });
                    if (result.Success && result.Skipped)
                    {
                        dll.State = DllState.Skipped;
                        dll.StateDetail = result.Message;
                        skipped++;
                        success++;
                        Log.Warn(dll.FileName + "：" + result.Message);
                    }
                    else if (result.Success)
                    {
                        dll.State = DllState.Loaded;
                        dll.StateDetail = result.Message;
                        success++;
                        Log.Ok(dll.FileName + " 注入成功 · " + result.Message);
                    }
                    else
                    {
                        dll.State = DllState.Failed;
                        dll.StateDetail = result.Message;
                        failed++;
                        Log.Error(dll.FileName + " 注入失败 · " + result.Message);
                    }
                    _dllList.RefreshStates();
                    await Task.Delay(180, token);
                }

                if (failed == 0)
                {
                    string summary = "注入完成：" + success + "/" + enabled.Count + " 个模块";
                    if (skipped > 0) summary += "（" + skipped + " 个已存在）";
                    SetStatus("注入完成", Theme.Success);
                    SetActivity("注入完成");
                    Log.Ok(summary);
                    ShowToast(summary, ToastKind.Success);
                    ShowTrayNotice((startedByUs ? "Minecraft 已启动，" : string.Empty) +
                        "已注入 " + success + "/" + enabled.Count + " 个 DLL");
                    await ApplyPostLaunchBehaviorAsync();
                }
                else
                {
                    RestoreLauncherAfterError(minimizedForInjection);
                    SetStatus("部分失败", Theme.Warning);
                    SetActivity("有 " + failed + " 个模块失败");
                    Log.Warn("注入结束：成功 " + success + "，失败 " + failed);
                    ShowToast("有 " + failed + " 个 DLL 注入失败，请查看日志", ToastKind.Error);
                    ShowTrayNotice("DLL 注入失败：" + failed + "/" + enabled.Count + " 个，详情见日志");
                    SwitchPage(PageKind.Logs);
                }
            }
            catch (OperationCanceledException)
            {
                SetStatus("已取消", Theme.Muted);
                SetActivity("已取消");
                Log.Warn("启动流程已取消");
            }
            catch (TimeoutException ex)
            {
                RestoreLauncherAfterError(minimizedForInjection);
                SetStatus("等待超时", Theme.Warning);
                SetActivity("等待游戏窗口超时");
                Log.Error(ex.Message);
                ShowToast("等待游戏窗口超时，请查看日志", ToastKind.Warning);
                DialogForm.Error(this, "等待游戏窗口超时",
                    ex.Message + "\n\n如果游戏已经打开，可以再次点击“启动游戏”直接注入已运行的进程。");
            }
            catch (Exception ex)
            {
                RestoreLauncherAfterError(minimizedForInjection);
                SetStatus("发生错误", Theme.Danger);
                SetActivity("启动失败");
                Log.Error("启动流程异常：" + ex);
                DialogForm.Error(this, "启动失败", ex.Message);
            }
            finally
            {
                if (game != null) game.Dispose();
                _busy = false;
                SetBusyUi(false);
                if (_cts != null)
                {
                    _cts.Dispose();
                    _cts = null;
                }
                if (_refreshPending)
                {
                    _refreshPending = false;
                    LoadDlls(false);
                }
                UpdateEverything();
            }
        }

        private void HandleInjectHotkey()
        {
            string hotkeyText = HotkeyUtil.Format(_injectHotkeyModifiers, _injectHotkeyKey);
            if (_busy)
            {
                Log.Info("注入热键：当前启动/注入流程尚未结束，忽略本次触发");
                ShowTrayNotice("注入失败：正在处理其他任务");
                return;
            }
            int enabled = 0;
            foreach (DllInfo dll in _dlls) if (dll.Enabled) enabled++;
            if (enabled == 0)
            {
                Log.Warn("注入热键：没有已启用的 DLL");
                ShowTrayNotice("注入失败：没有已启用的 DLL");
                return;
            }
            if (!GameLauncher.IsGameRunning())
            {
                Log.Warn("注入热键：没有检测到运行中的 Minecraft");
                ShowTrayNotice("注入失败：未检测到运行中的 Minecraft");
                return;
            }
            Log.Info("注入热键 " + hotkeyText + " 已触发，开始注入运行中的游戏");
            Task ignored = StartGameAsync(false, true, true);
        }

        private void HandleLaunchHotkey()
        {
            if (_busy)
            {
                Log.Info("直接启动热键：当前启动/注入流程尚未结束，忽略本次触发");
                ShowTrayNotice("启动失败：正在处理其他任务");
                return;
            }
            Log.Info("直接启动热键已触发，使用当前预设启动");
            Task ignored = StartPresetAsync("直接启动快捷键", true);
        }

        private void HandleCloseHotkey()
        {
            Log.Info("直接关闭热键已触发");
            EndGameFromTray("直接关闭快捷键");
        }

        private void PrepareGameWindow(Process game)
        {
            if (game == null) return;
            try
            {
                IntPtr hwnd = game.MainWindowHandle;
                if (hwnd == IntPtr.Zero) return;
                if (Native.IsIconic(hwnd))
                {
                    Log.Info("游戏窗口处于最小化状态，先恢复窗口再注入");
                    Native.ShowWindowAsync(hwnd, Native.SW_RESTORE);
                    Native.SetForegroundWindow(hwnd);
                    Thread.Sleep(250);
                }
            }
            catch (Exception ex)
            {
                Log.Warn("恢复游戏窗口失败：" + ex.Message);
            }
        }

        private void RestoreLauncherAfterError(bool wasMinimized)
        {
            if (!wasMinimized) return;
            try
            {
                if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
                Show();
                Activate();
            }
            catch { }
        }

        private async Task ApplyPostLaunchBehaviorAsync()
        {
            if (_config.CloseAfterInject)
            {
                await Task.Delay(700);
                _busy = false;
                _skipCloseBehavior = true;
                Close();
            }
            else if (_config.MinimizeAfterInject)
            {
                await Task.Delay(900);
                WindowState = FormWindowState.Minimized;
            }
        }

        private void SetBusyUi(bool busy)
        {
            if (IsDisposed) return;
            _busy = busy;
            if (_hero != null) _hero.SetLaunchEnabled(!busy);
            if (busy)
            {
                SetStatus("准备中", Theme.Accent2);
                SetActivity("正在启动游戏");
            }
            else
            {
                if (_statusText == "准备中" || _statusText.StartsWith("等待窗口") || _statusText.StartsWith("注入 "))
                    SetStatus(_dlls.Count > 0 ? "就绪" : "等待模块", Theme.Success);
                SetActivity(_dlls.Count > 0 ? "等待启动" : "等待添加模块");
            }
            if (_dllList != null) _dllList.RefreshStates();
            UpdateHero();
        }

        private void ShowToast(string message, ToastKind kind)
        {
            if (IsDisposed || _toast == null || _toast.IsDisposed) return;
            _toast.ShowMessage(message, kind, this);
        }

        private void PositionToast()
        {
            if (_toast != null) _toast.PositionIn(this);
        }

        private void ApplyRoundedRegion()
        {
            if (!IsHandleCreated || WindowState != FormWindowState.Normal) return;
            try
            {
                int corner = 2;
                Native.DwmSetWindowAttribute(Handle, Native.DWMWA_WINDOW_CORNER_PREFERENCE, ref corner, sizeof(int));
                IntPtr rgn = Native.CreateRoundRectRgn(0, 0, Width + 1, Height + 1, Theme.S(16f), Theme.S(16f));
                if (rgn != IntPtr.Zero) Native.SetWindowRgn(Handle, rgn, true);
            }
            catch { }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using (Pen pen = new Pen(Theme.Border, 1f))
                e.Graphics.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
        }
    }
}
