using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("STEVE CLIENT")]
[assembly: AssemblyDescription("Minecraft for Windows launcher, DLL injector and resource installer")]
[assembly: AssemblyProduct("STEVE CLIENT")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyVersion("2.11.1.0")]
[assembly: AssemblyFileVersion("2.11.1.0")]
[assembly: ComVisible(false)]
