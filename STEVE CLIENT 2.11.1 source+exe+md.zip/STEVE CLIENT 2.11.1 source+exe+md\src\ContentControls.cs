using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Compression;
using System.Threading;
using System.Windows.Forms;

namespace SteveClient
{
    internal class ContentRow : Control
    {
        public ContentItem Item;
        public bool BatchMode;
        public bool Checked;
        public event EventHandler RemoveRequested;
        public event EventHandler OpenRequested;
        public event EventHandler SelectionRequested;
        private bool _hover;
        private RectangleF _removeRect;
        private Image _icon;
        private int _iconGeneration;
        private bool _iconRequested;

        public ContentRow()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor | ControlStyles.Selectable, true);
            BackColor = Theme.Bg;
            Cursor = Cursors.Hand;
            TabStop = true;
        }

        public void Bind(ContentItem item)
        {
            Item = item;
            AccessibleName = item != null ? item.Name : string.Empty;
            _iconGeneration++;
            _iconRequested = false;
            Checked = false;
            if (_icon != null)
            {
                _icon.Dispose();
                _icon = null;
            }
            Invalidate();
        }

        private void EnsureIcon()
        {
            if (Item == null || _icon != null || _iconRequested) return;
            bool fromArchive = !string.IsNullOrEmpty(Item.ArchivePath) &&
                               !string.IsNullOrEmpty(Item.ArchiveIconEntry);
            string iconPath = Item.IconPath;
            string archivePath = Item.ArchivePath;
            string archiveEntry = Item.ArchiveIconEntry;
            if (!fromArchive && string.IsNullOrEmpty(iconPath)) return;

            _iconRequested = true;
            int generation = _iconGeneration;
            ThreadPool.QueueUserWorkItem(delegate
            {
                Image image = fromArchive
                    ? LoadIconFromArchive(archivePath, archiveEntry)
                    : LoadIcon(iconPath);
                if (image == null) return;
                try
                {
                    BeginInvoke((MethodInvoker)delegate
                    {
                        if (IsDisposed || generation != _iconGeneration)
                        {
                            image.Dispose();
                            return;
                        }
                        _icon = image;
                        Invalidate();
                    });
                }
                catch
                {
                    image.Dispose();
                }
            });
        }

        private static Image LoadIcon(string path)
        {
            if (string.IsNullOrEmpty(path) || !File.Exists(path)) return null;
            try
            {
                using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (Image image = Image.FromStream(stream))
                    return ScaleImage(image);
            }
            catch { return null; }
        }

        private static Image LoadIconFromArchive(string archivePath, string entryName)
        {
            try
            {
                if (string.IsNullOrEmpty(archivePath) || !File.Exists(archivePath)) return null;
                using (ZipArchive archive = ZipFile.OpenRead(archivePath))
                {
                    foreach (ZipArchiveEntry entry in archive.Entries)
                    {
                        if (!string.Equals(entry.FullName, entryName, StringComparison.OrdinalIgnoreCase)) continue;
                        using (Stream stream = entry.Open())
                        using (Image image = Image.FromStream(stream))
                            return ScaleImage(image);
                    }
                }
            }
            catch { }
            return null;
        }

        private static Image ScaleImage(Image image)
        {
            const int max = 128;
            float scale = Math.Min(1f, (float)max / Math.Max(image.Width, image.Height));
            int width = Math.Max(1, (int)(image.Width * scale));
            int height = Math.Max(1, (int)(image.Height * scale));
            Bitmap copy = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(copy))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.DrawImage(image, 0, 0, width, height);
            }
            return copy;
        }

        internal static Color KindColor(ContentKind kind)
        {
            switch (kind)
            {
                case ContentKind.World: return Theme.Success;
                case ContentKind.Template: return Theme.Blue;
                case ContentKind.TexturePack: return Theme.Accent2;
                default: return Theme.Accent;
            }
        }

        internal static IconGlyph KindGlyph(ContentKind kind)
        {
            switch (kind)
            {
                case ContentKind.World: return IconGlyph.World;
                case ContentKind.Template: return IconGlyph.Template;
                case ContentKind.TexturePack: return IconGlyph.Image;
                default: return IconGlyph.Puzzle;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (Item == null) return;
            EnsureIcon();
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            RectangleF rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(11f)))
            {
                Color fill = _hover ? Theme.Surface2 : Theme.Surface;
                if (Checked) fill = Theme.Mix(fill, Theme.Accent, 0.16f);
                if (Focused) fill = Theme.Mix(fill, Theme.Accent, 0.06f);
                using (SolidBrush b = new SolidBrush(fill))
                    g.FillPath(b, path);
                Color border = BatchMode && Checked ? Theme.Alpha(Theme.Accent, 150)
                    : (_hover ? Theme.Mix(Theme.Border, Theme.Accent, 0.22f) : Theme.BorderSoft);
                using (Pen pen = new Pen(border, 1f))
                    g.DrawPath(pen, path);
            }

            if (BatchMode)
                DrawCheckbox(g, new RectangleF(Theme.SF(14f), (Height - Theme.SF(20f)) / 2f,
                    Theme.SF(20f), Theme.SF(20f)), Checked);

            Color accent = KindColor(Item.Kind);
            float pad = Theme.SF(BatchMode ? 42f : 12f);
            float tile = Theme.SF(44f);
            RectangleF tileRect = new RectangleF(pad, (Height - tile) / 2f, tile, tile);
            if (_icon != null)
            {
                using (GraphicsPath path = Theme.RoundRect(tileRect, Theme.SF(9f)))
                {
                    GraphicsState state = g.Save();
                    g.SetClip(path);
                    float scale = Math.Max(tileRect.Width / _icon.Width, tileRect.Height / _icon.Height);
                    float w = _icon.Width * scale;
                    float h = _icon.Height * scale;
                    g.DrawImage(_icon, tileRect.X + (tileRect.Width - w) / 2f, tileRect.Y + (tileRect.Height - h) / 2f, w, h);
                    g.Restore(state);
                }
                using (GraphicsPath path = Theme.RoundRect(tileRect, Theme.SF(9f)))
                using (Pen pen = new Pen(Theme.Border, 1f))
                    g.DrawPath(pen, path);
            }
            else
            {
                using (GraphicsPath path = Theme.RoundRect(tileRect, Theme.SF(9f)))
                using (SolidBrush b = new SolidBrush(Theme.Alpha(accent, 26)))
                    g.FillPath(b, path);
                float icon = Theme.SF(20f);
                PillButton.DrawGlyph(g, KindGlyph(Item.Kind),
                    new RectangleF(tileRect.X + (tile - icon) / 2f, tileRect.Y + (tile - icon) / 2f, icon, icon), accent, 1.4f);
            }

            float textX = tileRect.Right + Theme.SF(12f);
            float textW = Math.Max(Theme.SF(80f), Width - textX - Theme.SF(240f));
            using (SolidBrush b = new SolidBrush(Theme.Text))
                g.DrawString(Item.Name, Theme.Ui(12.2f, FontStyle.Bold), b,
                    new RectangleF(textX, Theme.SF(9f), textW, Theme.SF(22f)), Theme.Near);
            using (SolidBrush b = new SolidBrush(Theme.Muted2))
                g.DrawString(Item.MetaText, Theme.Ui(9.2f), b,
                    new RectangleF(textX, Theme.SF(31f), textW, Theme.SF(18f)), Theme.Near);

            float rightPad = Theme.SF(14f);
            float kindW = Theme.SF(58f);
            RectangleF kindRect = new RectangleF(Width - rightPad - kindW, 0, kindW, Height);
            using (SolidBrush b = new SolidBrush(accent))
                g.DrawString(Item.KindText, Theme.Ui(9.4f), b, kindRect, RightCenterFormat());

            _removeRect = RectangleF.Empty;
            if (_hover && !BatchMode)
            {
                float size = Theme.SF(24f);
                _removeRect = new RectangleF(kindRect.X - Theme.SF(34f), (Height - size) / 2f, size, size);
                using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Danger, 18)))
                    g.FillEllipse(b, _removeRect);
                float glyph = Theme.SF(13f);
                PillButton.DrawGlyph(g, IconGlyph.Trash,
                    new RectangleF(_removeRect.X + (size - glyph) / 2f, _removeRect.Y + (size - glyph) / 2f, glyph, glyph),
                    Theme.Danger, 1.1f);
            }
        }

        private static StringFormat RightCenterFormat()
        {
            StringFormat format = new StringFormat(StringFormat.GenericTypographic);
            format.Alignment = StringAlignment.Far;
            format.LineAlignment = StringAlignment.Center;
            format.Trimming = StringTrimming.EllipsisCharacter;
            format.FormatFlags |= StringFormatFlags.NoWrap;
            return format;
        }

        private static void DrawCheckbox(Graphics g, RectangleF rect, bool selected)
        {
            Theme.Prepare(g);
            using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(5f)))
            {
                using (SolidBrush b = new SolidBrush(selected ? Theme.Accent : Theme.Surface2))
                    g.FillPath(b, path);
                using (Pen pen = new Pen(selected ? Theme.AccentLight : Theme.Border, 1f))
                    g.DrawPath(pen, path);
            }
            if (selected)
            {
                float glyph = rect.Width * 0.58f;
                PillButton.DrawGlyph(g, IconGlyph.Check,
                    new RectangleF(rect.X + (rect.Width - glyph) / 2f,
                        rect.Y + (rect.Height - glyph) / 2f, glyph, glyph),
                    Color.White, 1.8f);
            }
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (BatchMode)
                {
                    Checked = !Checked;
                    if (SelectionRequested != null) SelectionRequested(this, EventArgs.Empty);
                    Invalidate();
                }
                else if (!_removeRect.IsEmpty && _removeRect.Contains(e.Location))
                {
                    if (RemoveRequested != null) RemoveRequested(this, EventArgs.Empty);
                }
                else
                {
                    Focus();
                }
            }
            base.OnMouseClick(e);
        }

        protected override void OnDoubleClick(EventArgs e)
        {
            if (!BatchMode && OpenRequested != null) OpenRequested(this, EventArgs.Empty);
            base.OnDoubleClick(e);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            if (BatchMode && e.KeyCode == Keys.Space)
            {
                Checked = !Checked;
                if (SelectionRequested != null) SelectionRequested(this, EventArgs.Empty);
                Invalidate();
                e.Handled = true;
            }
            else if (!BatchMode && e.KeyCode == Keys.Delete)
            {
                if (RemoveRequested != null) RemoveRequested(this, EventArgs.Empty);
                e.Handled = true;
            }
            else if (!BatchMode && e.KeyCode == Keys.Enter)
            {
                if (OpenRequested != null) OpenRequested(this, EventArgs.Empty);
                e.Handled = true;
            }
            base.OnKeyUp(e);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.ApplyDarkTheme(Handle);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _iconGeneration++;
                if (_icon != null)
                {
                    _icon.Dispose();
                    _icon = null;
                }
            }
            base.Dispose(disposing);
        }
    }

    internal class ContentListPanel : Panel
    {
        private readonly List<ContentRow> _rows = new List<ContentRow>();
        private List<ContentItem> _items = new List<ContentItem>();
        private int _scrollOffset;
        private int _contentHeight;
        private bool _draggingThumb;
        private int _dragStartY;
        private int _dragStartOffset;
        private RectangleF _thumbRect;
        private bool _batchMode;

        public string TargetHint = string.Empty;
        public string EmptyTitle = "把资源文件拖到这里";
        public string EmptyHint = "支持 .mcpack / .mcaddon / .mcworld / .zip，或点击右上角“添加资源”";
        public event EventHandler<ContentRow> RemoveRequested;
        public event EventHandler<ContentRow> OpenRequested;
        public event EventHandler SelectionChanged;

        public ContentListPanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            AutoScroll = false;
            BackColor = Theme.Bg;
            DoubleBuffered = true;
            Padding = new Padding(0);
            TabStop = true;
        }

        public List<ContentItem> Items
        {
            get { return _items; }
        }

        public void SetItems(List<ContentItem> items)
        {
            _items = items ?? new List<ContentItem>();
            _scrollOffset = 0;
            SuspendLayout();
            foreach (ContentRow row in _rows)
            {
                Controls.Remove(row);
                row.Dispose();
            }
            _rows.Clear();
            foreach (ContentItem item in _items)
            {
                ContentRow row = new ContentRow();
                row.Bind(item);
                row.BatchMode = _batchMode;
                row.SelectionRequested += delegate { if (SelectionChanged != null) SelectionChanged(this, EventArgs.Empty); };
                row.RemoveRequested += delegate { if (RemoveRequested != null) RemoveRequested(row, row); };
                row.OpenRequested += delegate { if (OpenRequested != null) OpenRequested(row, row); };
                row.MouseWheel += delegate(object sender, MouseEventArgs e) { ScrollBy(-e.Delta); };
                Controls.Add(row);
                _rows.Add(row);
            }
            ResumeLayout(true);
            LayoutRows();
            if (SelectionChanged != null) SelectionChanged(this, EventArgs.Empty);
            Invalidate();
        }

        public void SetBatchMode(bool enabled)
        {
            _batchMode = enabled;
            foreach (ContentRow row in _rows)
            {
                row.BatchMode = enabled;
                row.Checked = false;
                row.Invalidate();
            }
            if (SelectionChanged != null) SelectionChanged(this, EventArgs.Empty);
            Invalidate();
        }

        public List<ContentItem> SelectedItems()
        {
            List<ContentItem> list = new List<ContentItem>();
            foreach (ContentRow row in _rows)
                if (row.Checked && row.Item != null) list.Add(row.Item);
            return list;
        }

        public void SelectAll(bool selected)
        {
            foreach (ContentRow row in _rows)
            {
                row.Checked = selected;
                row.Invalidate();
            }
            if (SelectionChanged != null) SelectionChanged(this, EventArgs.Empty);
        }

        private void LayoutRows()
        {
            int gap = Theme.S(8f);
            int rowHeight = Theme.S(64f);
            _contentHeight = _rows.Count == 0 ? 0 : _rows.Count * (rowHeight + gap) - gap;
            int maxOffset = Math.Max(0, _contentHeight - ClientSize.Height);
            if (_scrollOffset > maxOffset) _scrollOffset = maxOffset;
            if (_scrollOffset < 0) _scrollOffset = 0;

            bool scrollable = _contentHeight > ClientSize.Height;
            int width = ClientSize.Width - Theme.S(4f) - (scrollable ? Theme.S(8f) : 0);
            width = Math.Max(Theme.S(200f), width);
            int y = -_scrollOffset;
            foreach (ContentRow row in _rows)
            {
                row.Bounds = new Rectangle(0, y, width, rowHeight);
                y += rowHeight + gap;
            }
            Invalidate();
        }

        private void ScrollBy(int amount)
        {
            int maxOffset = Math.Max(0, _contentHeight - ClientSize.Height);
            int next = Math.Max(0, Math.Min(maxOffset, _scrollOffset + amount));
            if (next == _scrollOffset) return;
            _scrollOffset = next;
            LayoutRows();
        }

        protected override void OnResize(EventArgs eventargs)
        {
            base.OnResize(eventargs);
            LayoutRows();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Theme.Bg))
                e.Graphics.FillRectangle(b, ClientRectangle);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (_items.Count == 0)
            {
                Graphics g = e.Graphics;
                Theme.Prepare(g);
                float margin = Theme.SF(8f);
                RectangleF rect = new RectangleF(margin, margin, Width - margin * 2f, Math.Max(Theme.SF(240f), Height - margin * 2f));
                using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(14f)))
                using (Pen pen = new Pen(Theme.Border, 1f))
                {
                    pen.DashStyle = DashStyle.Dash;
                    g.DrawPath(pen, path);
                }
                float icon = Theme.SF(42f);
                float centerX = rect.X + rect.Width / 2f;
                float top = rect.Y + Math.Max(Theme.SF(34f), (rect.Height - Theme.SF(170f)) / 2f);
                using (GraphicsPath path = Theme.RoundRect(new RectangleF(centerX - icon / 2f, top, icon, icon), Theme.SF(11f)))
                using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Accent, 24)))
                    g.FillPath(b, path);
                PillButton.DrawGlyph(g, IconGlyph.Download,
                    new RectangleF(centerX - Theme.SF(11f), top + Theme.SF(11f), Theme.SF(20f), Theme.SF(20f)), Theme.AccentLight, 1.5f);
                using (SolidBrush b = new SolidBrush(Theme.TextSoft))
                    g.DrawString(EmptyTitle, Theme.Ui(15f, FontStyle.Bold), b,
                        new RectangleF(rect.X, top + Theme.SF(58f), rect.Width, Theme.SF(28f)), Theme.Center);
                using (SolidBrush b = new SolidBrush(Theme.Muted))
                    g.DrawString(EmptyHint, Theme.Ui(10.2f), b,
                        new RectangleF(rect.X, top + Theme.SF(88f), rect.Width, Theme.SF(24f)), Theme.Center);
                using (SolidBrush b = new SolidBrush(Theme.Muted2))
                    g.DrawString("当前目标：" + (string.IsNullOrEmpty(TargetHint) ? "未选择目录" : TargetHint), Theme.Ui(9.3f), b,
                        new RectangleF(rect.X, top + Theme.SF(112f), rect.Width, Theme.SF(20f)), Theme.Center);
            }
            DrawScrollbar(e.Graphics);
        }

        private void DrawScrollbar(Graphics g)
        {
            if (_contentHeight <= ClientSize.Height || ClientSize.Height <= 0) return;
            Theme.Prepare(g);
            float trackW = Theme.SF(4f);
            float x = Width - Theme.SF(9f);
            float top = Theme.SF(4f);
            float trackH = Height - Theme.SF(8f);
            using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Border, 120)))
                Theme.FillRound(g, b, new RectangleF(x, top, trackW, trackH), trackW / 2f);
            float thumbH = Math.Max(Theme.SF(32f), trackH * (float)Height / _contentHeight);
            float maxOffset = Math.Max(1, _contentHeight - Height);
            float thumbY = top + (trackH - thumbH) * ((float)_scrollOffset / maxOffset);
            _thumbRect = new RectangleF(x, thumbY, trackW, thumbH);
            using (SolidBrush b = new SolidBrush(_draggingThumb ? Theme.AccentLight : Theme.Accent))
                Theme.FillRound(g, b, _thumbRect, trackW / 2f);
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            ScrollBy(-e.Delta * Theme.S(1) / 2);
            base.OnMouseWheel(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && !_thumbRect.IsEmpty && _thumbRect.Contains(e.Location))
            {
                _draggingThumb = true;
                _dragStartY = e.Y;
                _dragStartOffset = _scrollOffset;
                Invalidate();
            }
            base.OnMouseDown(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (_draggingThumb)
            {
                float trackH = Height - Theme.SF(8f);
                float thumbH = _thumbRect.Height;
                float range = Math.Max(1f, trackH - thumbH);
                int maxOffset = Math.Max(1, _contentHeight - Height);
                int target = _dragStartOffset + (int)((e.Y - _dragStartY) / range * maxOffset);
                target = Math.Max(0, Math.Min(maxOffset, target));
                if (target != _scrollOffset)
                {
                    _scrollOffset = target;
                    LayoutRows();
                }
            }
            base.OnMouseMove(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (_draggingThumb)
            {
                _draggingThumb = false;
                Invalidate();
            }
            base.OnMouseUp(e);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.ApplyDarkTheme(Handle);
        }
    }
}
