using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace SteveClient
{
    internal static class HotkeyUtil
    {
        public const string DefaultText = "Ctrl+1";

        public static bool TryParse(string text, out uint modifiers, out Keys key)
        {
            modifiers = 0;
            key = Keys.None;
            if (string.IsNullOrWhiteSpace(text)) return false;

            string[] parts = text.Split(new char[] { '+' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length < 2) return false;
            for (int i = 0; i < parts.Length; i++)
            {
                string part = parts[i].Trim();
                if (part.Equals("Ctrl", StringComparison.OrdinalIgnoreCase) ||
                    part.Equals("Control", StringComparison.OrdinalIgnoreCase))
                    modifiers |= Native.MOD_CONTROL;
                else if (part.Equals("Alt", StringComparison.OrdinalIgnoreCase))
                    modifiers |= Native.MOD_ALT;
                else if (part.Equals("Shift", StringComparison.OrdinalIgnoreCase))
                    modifiers |= Native.MOD_SHIFT;
                else if (i == parts.Length - 1 && !IsModifierName(part))
                {
                    if (part.Length == 1 && part[0] >= '0' && part[0] <= '9')
                    {
                        key = (Keys)((int)Keys.D0 + (part[0] - '0'));
                    }
                    else
                    {
                        Keys parsed;
                        if (!Enum.TryParse<Keys>(part, true, out parsed)) return false;
                        key = parsed;
                    }
                }
                else
                {
                    return false;
                }
            }
            return modifiers != 0 && key != Keys.None && !IsModifierKey(key);
        }

        public static string Format(uint modifiers, Keys key)
        {
            List<string> parts = new List<string>();
            if ((modifiers & Native.MOD_CONTROL) != 0) parts.Add("Ctrl");
            if ((modifiers & Native.MOD_ALT) != 0) parts.Add("Alt");
            if ((modifiers & Native.MOD_SHIFT) != 0) parts.Add("Shift");
            if (key >= Keys.D0 && key <= Keys.D9)
                parts.Add(((int)key - (int)Keys.D0).ToString());
            else
                parts.Add(key.ToString());
            return string.Join("+", parts.ToArray());
        }

        public static bool IsModifierKey(Keys key)
        {
            return key == Keys.ControlKey || key == Keys.LControlKey || key == Keys.RControlKey ||
                   key == Keys.Menu || key == Keys.LMenu || key == Keys.RMenu ||
                   key == Keys.ShiftKey || key == Keys.LShiftKey || key == Keys.RShiftKey ||
                   key == Keys.LWin || key == Keys.RWin || key == Keys.None;
        }

        private static bool IsModifierName(string text)
        {
            return text.Equals("Ctrl", StringComparison.OrdinalIgnoreCase) ||
                   text.Equals("Control", StringComparison.OrdinalIgnoreCase) ||
                   text.Equals("Alt", StringComparison.OrdinalIgnoreCase) ||
                   text.Equals("Shift", StringComparison.OrdinalIgnoreCase);
        }
    }
}
