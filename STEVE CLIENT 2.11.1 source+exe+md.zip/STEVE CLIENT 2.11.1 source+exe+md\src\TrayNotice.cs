using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SteveClient
{
    internal sealed class TrayNotice : Form
    {
        private readonly Timer _timer;
        private readonly string _message;

        public TrayNotice(string message)
        {
            _message = message ?? string.Empty;
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            TopMost = true;
            BackColor = Theme.Border;
            Padding = new Padding(1);
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(Theme.S(320), Theme.S(64));
            DoubleBuffered = true;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);

            Rectangle area = Screen.PrimaryScreen.WorkingArea;
            Location = new Point(area.Right - Width - Theme.S(18), area.Bottom - Height - Theme.S(18));

            _timer = new Timer();
            _timer.Interval = 2000;
            _timer.Tick += delegate
            {
                _timer.Stop();
                Close();
            };
            Click += delegate { Close(); };
            Shown += delegate { _timer.Start(); };
            FormClosed += delegate { _timer.Dispose(); };
        }

        protected override bool ShowWithoutActivation
        {
            get { return true; }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x08000000; // WS_EX_NOACTIVATE
                cp.ExStyle |= 0x00000080; // WS_EX_TOOLWINDOW
                return cp;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            Rectangle rect = new Rectangle(0, 0, Width, Height);
            using (SolidBrush b = new SolidBrush(Theme.Surface))
                g.FillRectangle(b, rect);

            float pad = Theme.SF(14f);
            float icon = Theme.SF(28f);
            RectangleF iconRect = new RectangleF(pad, (Height - icon) / 2f, icon, icon);
            using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Accent, 30)))
                g.FillEllipse(b, iconRect);
            PillButton.DrawGlyph(g, IconGlyph.Info,
                new RectangleF(iconRect.X + Theme.SF(7f), iconRect.Y + Theme.SF(7f),
                    Theme.SF(14f), Theme.SF(14f)), Theme.AccentLight, 1.4f);

            using (SolidBrush b = new SolidBrush(Theme.TextSoft))
                g.DrawString(_message, Theme.Ui(9.2f), b,
                    new RectangleF(iconRect.Right + Theme.SF(10f), 0,
                        Width - iconRect.Right - Theme.SF(24f), Height), Theme.LeftCenter);

            using (Pen pen = new Pen(Theme.Border, 1f))
                g.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
        }
    }
}
