using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace SteveClient
{
    internal class LogView : Panel
    {
        private const int WM_MOUSEWHEEL = 0x020A;
        private const int EM_GETFIRSTVISIBLELINE = 0x00CE;
        private const int EM_LINESCROLL = 0x00B6;
        private const int EM_GETSCROLLPOS = 0x04DD;
        private const int EM_SETSCROLLPOS = 0x04DE;
        private const int EM_GETLINECOUNT = 0x00BA;

        [StructLayout(LayoutKind.Sequential)]
        private struct ScrollPoint
        {
            public int X;
            public int Y;
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, ref ScrollPoint lParam);

        private sealed class LogTextBox : RichTextBox
        {
            private readonly LogView _owner;

            public LogTextBox(LogView owner)
            {
                _owner = owner;
            }

            protected override void WndProc(ref Message m)
            {
                if (m.Msg == WM_MOUSEWHEEL)
                {
                    long value = m.WParam.ToInt64();
                    int delta = unchecked((short)((value >> 16) & 0xffff));
                    _owner.HandleWheel(delta);
                    return;
                }
                base.WndProc(ref m);
            }
        }

        private readonly LogTextBox _box;
        private bool _draggingThumb;
        private bool _atBottom;
        private RectangleF _thumbRect;

        public LogView()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Surface;
            DoubleBuffered = true;

            _box = new LogTextBox(this);
            _box.BorderStyle = BorderStyle.None;
            _box.BackColor = Theme.Surface;
            _box.ForeColor = Theme.TextSoft;
            _box.Font = Theme.Mono(10.5f, FontStyle.Regular);
            _box.ReadOnly = true;
            _box.DetectUrls = false;
            _box.WordWrap = true;
            _box.ScrollBars = RichTextBoxScrollBars.None;
            _box.TabStop = false;
            _box.TextChanged += delegate { LayoutBox(); Invalidate(); };
            _box.SelectionChanged += delegate { Invalidate(); };
            _box.KeyUp += delegate { Invalidate(); };
            _box.MouseUp += delegate { Invalidate(); };
            Controls.Add(_box);

            Resize += delegate { LayoutBox(); Invalidate(); };
            MouseWheel += delegate(object sender, MouseEventArgs e) { HandleWheel(e.Delta); };
        }

        public void AppendEntry(LogEntry entry)
        {
            if (entry == null) return;
            Color color;
            switch (entry.Level)
            {
                case LogLevel.Success: color = Theme.Success; break;
                case LogLevel.Warning: color = Theme.Warning; break;
                case LogLevel.Error: color = Theme.Danger; break;
                default: color = Theme.TextSoft; break;
            }
            bool stickToBottom = IsAtBottom();
            int firstLine = FirstVisibleLine();
            ScrollPoint scrollPoint = new ScrollPoint();
            bool hasScrollPoint = !stickToBottom && GetScrollPoint(out scrollPoint);
            _box.SelectionStart = _box.TextLength;
            _box.SelectionLength = 0;
            _box.SelectionColor = Theme.Muted2;
            _box.AppendText(entry.Time.ToString("HH:mm:ss") + "  ");
            _box.SelectionColor = color;
            _box.AppendText(entry.Message + Environment.NewLine);
            if (stickToBottom) ScrollToBottom();
            else if (hasScrollPoint) SetScrollPoint(scrollPoint);
            else RestoreFirstLine(firstLine);
            LayoutBox();
            Invalidate();
        }

        public void AppendRaw(string message, Color color)
        {
            bool stickToBottom = IsAtBottom();
            int firstLine = FirstVisibleLine();
            ScrollPoint scrollPoint = new ScrollPoint();
            bool hasScrollPoint = !stickToBottom && GetScrollPoint(out scrollPoint);
            _box.SelectionStart = _box.TextLength;
            _box.SelectionLength = 0;
            _box.SelectionColor = color;
            _box.AppendText(message + Environment.NewLine);
            if (stickToBottom) ScrollToBottom();
            else if (hasScrollPoint) SetScrollPoint(scrollPoint);
            else RestoreFirstLine(firstLine);
            LayoutBox();
            Invalidate();
        }

        public void Clear()
        {
            _box.Clear();
            _atBottom = false;
            LayoutBox();
            Invalidate();
        }

        private void LayoutBox()
        {
            if (_box == null) return;
            bool scrollable = IsScrollable();
            int gutter = scrollable ? Theme.S(12f) : 0;
            _box.Bounds = new Rectangle(0, 0, Math.Max(0, Width - gutter), Height);
        }

        private bool IsScrollable()
        {
            return MaxScrollY() > 0;
        }

        private int MaxScrollY()
        {
            if (_box == null || !_box.IsHandleCreated || _box.TextLength == 0) return 0;
            try
            {
                Point last = _box.GetPositionFromCharIndex(_box.TextLength - 1);
                int lineHeight = Math.Max(1, _box.Font.Height);
                int contentBottom = last.Y + CurrentScrollY() + lineHeight;
                return Math.Max(0, contentBottom - _box.ClientSize.Height + Theme.S(4f));
            }
            catch { return 0; }
        }

        private int CurrentScrollY()
        {
            ScrollPoint point;
            if (GetScrollPoint(out point)) return Math.Max(0, point.Y);
            return Math.Max(0, FirstVisibleLine() * Math.Max(1, _box.Font.Height));
        }

        private void ScrollToY(int y)
        {
            ScrollPoint point;
            if (!GetScrollPoint(out point)) point = new ScrollPoint();
            point.Y = Math.Max(0, Math.Min(MaxScrollY(), y));
            SetScrollPoint(point);
            _atBottom = false;
            Invalidate();
        }

        private int VisibleLines()
        {
            int lineHeight = Math.Max(1, _box.Font.Height);
            return Math.Max(1, _box.ClientSize.Height / lineHeight);
        }

        private int TotalLines()
        {
            if (!_box.IsHandleCreated) return 0;
            try { return SendMessage(_box.Handle, EM_GETLINECOUNT, IntPtr.Zero, IntPtr.Zero).ToInt32(); }
            catch { return 0; }
        }

        private int FirstVisibleLine()
        {
            if (!_box.IsHandleCreated) return 0;
            try { return SendMessage(_box.Handle, EM_GETFIRSTVISIBLELINE, IntPtr.Zero, IntPtr.Zero).ToInt32(); }
            catch { return 0; }
        }

        private void ScrollToFirstLine(int line)
        {
            int maxLine = Math.Max(0, TotalLines() - VisibleLines());
            int target = Math.Max(0, Math.Min(maxLine, line));
            int current = FirstVisibleLine();
            if (target == current) return;
            try { SendMessage(_box.Handle, EM_LINESCROLL, IntPtr.Zero, new IntPtr(target - current)); }
            catch { }
            Invalidate();
        }

        internal void HandleWheel(int delta)
        {
            int max = MaxScrollY();
            if (max <= 0) return;
            int notches = delta / 120;
            if (notches == 0) notches = delta > 0 ? 1 : -1;
            int lines = SystemInformation.MouseWheelScrollLines;
            if (lines <= 0) lines = 3;
            int lineHeight = Math.Max(1, _box.Font.Height);
            int current = CurrentScrollY();
            if (delta < 0 && _atBottom)
            {
                // Already at the true bottom; ignore further wheel-down
                // events instead of repeatedly re-triggering caret scrolling.
                return;
            }
            if (delta < 0 && current >= max - lineHeight * 2)
            {
                // Let the native RichEdit caret reach the true bottom; the
                // wrapped-line scroll range is not always exactly equal to
                // the control's reported character position.
                ScrollToBottom();
                return;
            }
            ScrollToY(current - notches * lines * lineHeight);
        }

        private void ScrollToBottom()
        {
            _box.SelectionStart = _box.TextLength;
            _box.SelectionLength = 0;
            _box.ScrollToCaret();
            _atBottom = true;
            Invalidate();
        }

        private bool IsAtBottom()
        {
            if (_atBottom) return true;
            int max = MaxScrollY();
            if (max <= 0) return true;
            return CurrentScrollY() >= max - Theme.S(2f);
        }

        private void RestoreFirstLine(int firstLine)
        {
            if (firstLine < 0) return;
            try
            {
                int current = FirstVisibleLine();
                if (current != firstLine)
                    SendMessage(_box.Handle, EM_LINESCROLL, IntPtr.Zero, new IntPtr(firstLine - current));
            }
            catch { }
        }

        private bool GetScrollPoint(out ScrollPoint point)
        {
            point = new ScrollPoint();
            if (!_box.IsHandleCreated) return false;
            try
            {
                SendMessage(_box.Handle, EM_GETSCROLLPOS, IntPtr.Zero, ref point);
                return true;
            }
            catch { return false; }
        }

        private void SetScrollPoint(ScrollPoint point)
        {
            try { SendMessage(_box.Handle, EM_SETSCROLLPOS, IntPtr.Zero, ref point); }
            catch { }
            _atBottom = false;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Theme.Surface))
                e.Graphics.FillRectangle(b, ClientRectangle);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            DrawScrollbar(e.Graphics);
        }

        private void DrawScrollbar(Graphics g)
        {
            int maxScroll = MaxScrollY();
            if (maxScroll <= 0 || Height <= 0)
            {
                _thumbRect = RectangleF.Empty;
                return;
            }
            Theme.Prepare(g);
            float trackW = Theme.SF(5f);
            float x = Width - Theme.SF(10f);
            float top = Theme.SF(4f);
            float trackH = Height - Theme.SF(8f);
            using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Border, 120)))
                Theme.FillRound(g, b, new RectangleF(x, top, trackW, trackH), trackW / 2f);

            int viewport = Math.Max(1, _box.ClientSize.Height);
            int total = viewport + maxScroll;
            float thumbH = Math.Max(Theme.SF(32f), trackH * viewport / total);
            float progress = (float)CurrentScrollY() / maxScroll;
            progress = Math.Max(0f, Math.Min(1f, progress));
            float thumbY = top + (trackH - thumbH) * progress;
            _thumbRect = new RectangleF(x, thumbY, trackW, thumbH);
            using (SolidBrush b = new SolidBrush(_draggingThumb ? Theme.AccentLight : Theme.Accent))
                Theme.FillRound(g, b, _thumbRect, trackW / 2f);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && !_thumbRect.IsEmpty && _thumbRect.Contains(e.Location))
            {
                _draggingThumb = true;
                Invalidate();
            }
            base.OnMouseDown(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (_draggingThumb)
            {
                int maxScroll = MaxScrollY();
                float trackH = Height - Theme.SF(8f);
                float thumbH = _thumbRect.Height;
                float range = Math.Max(1f, trackH - thumbH);
                float relative = (e.Y - Theme.SF(4f) - thumbH / 2f) / range;
                relative = Math.Max(0f, Math.Min(1f, relative));
                if (relative >= 0.999f) ScrollToBottom();
                else ScrollToY((int)(relative * maxScroll));
            }
            base.OnMouseMove(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (_draggingThumb)
            {
                _draggingThumb = false;
                Invalidate();
            }
            base.OnMouseUp(e);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.ApplyDarkTheme(Handle);
            if (_box.IsHandleCreated) Native.ApplyDarkTheme(_box.Handle);
        }
    }
}
