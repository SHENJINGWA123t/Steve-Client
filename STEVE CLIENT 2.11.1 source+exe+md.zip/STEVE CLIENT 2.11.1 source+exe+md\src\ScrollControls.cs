using System;
using System.Drawing;
using System.Windows.Forms;

namespace SteveClient
{
    internal class ScrollHostPanel : Panel
    {
        private int _scrollOffset;
        private int _contentHeight;
        private bool _draggingThumb;
        private int _dragStartY;
        private int _dragStartOffset;
        private RectangleF _thumbRect;

        public readonly Panel Content;

        public ScrollHostPanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            AutoScroll = false;
            BackColor = Theme.Bg;
            DoubleBuffered = true;

            Content = new Panel();
            Content.BackColor = Theme.Bg;
            Content.Location = new Point(0, 0);
            Controls.Add(Content);
            MouseWheel += HostMouseWheel;
        }

        public int ContentWidth
        {
            get
            {
                bool scrollable = _contentHeight > ClientSize.Height;
                return Math.Max(Theme.S(240f), ClientSize.Width - Theme.S(4f) - (scrollable ? Theme.S(10f) : 0));
            }
        }

        public void SetContentHeight(int height)
        {
            _contentHeight = Math.Max(0, height);
            LayoutContent();
        }

        public void AttachMouseWheel(Control root)
        {
            if (root == null) return;
            root.MouseWheel += HostMouseWheel;
            foreach (Control child in root.Controls)
                AttachMouseWheel(child);
        }

        private void HostMouseWheel(object sender, MouseEventArgs e)
        {
            ScrollBy(-e.Delta * Theme.S(1) / 2);
        }

        private void LayoutContent()
        {
            int maxOffset = Math.Max(0, _contentHeight - ClientSize.Height);
            if (_scrollOffset > maxOffset) _scrollOffset = maxOffset;
            if (_scrollOffset < 0) _scrollOffset = 0;

            int width = ContentWidth;
            int height = Math.Max(_contentHeight, ClientSize.Height);
            Content.Bounds = new Rectangle(0, -_scrollOffset, width, height);
            Invalidate();
        }

        private void ScrollBy(int amount)
        {
            int maxOffset = Math.Max(0, _contentHeight - ClientSize.Height);
            int next = Math.Max(0, Math.Min(maxOffset, _scrollOffset + amount));
            if (next == _scrollOffset) return;
            _scrollOffset = next;
            LayoutContent();
        }

        protected override void OnResize(EventArgs eventargs)
        {
            base.OnResize(eventargs);
            LayoutContent();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Theme.Bg))
                e.Graphics.FillRectangle(b, ClientRectangle);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            DrawScrollbar(e.Graphics);
        }

        private void DrawScrollbar(Graphics g)
        {
            if (_contentHeight <= ClientSize.Height || ClientSize.Height <= 0)
            {
                _thumbRect = RectangleF.Empty;
                return;
            }
            Theme.Prepare(g);
            float trackW = Theme.SF(5f);
            float x = Width - Theme.SF(10f);
            float top = Theme.SF(4f);
            float trackH = Height - Theme.SF(8f);
            using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Border, 120)))
                Theme.FillRound(g, b, new RectangleF(x, top, trackW, trackH), trackW / 2f);

            float thumbH = Math.Max(Theme.SF(32f), trackH * (float)Height / _contentHeight);
            float maxOffset = Math.Max(1, _contentHeight - Height);
            float thumbY = top + (trackH - thumbH) * ((float)_scrollOffset / maxOffset);
            _thumbRect = new RectangleF(x, thumbY, trackW, thumbH);
            using (SolidBrush b = new SolidBrush(_draggingThumb ? Theme.AccentLight : Theme.Accent))
                Theme.FillRound(g, b, _thumbRect, trackW / 2f);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && !_thumbRect.IsEmpty && _thumbRect.Contains(e.Location))
            {
                _draggingThumb = true;
                _dragStartY = e.Y;
                _dragStartOffset = _scrollOffset;
                Invalidate();
            }
            base.OnMouseDown(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (_draggingThumb)
            {
                float trackH = Height - Theme.SF(8f);
                float thumbH = _thumbRect.Height;
                float range = Math.Max(1f, trackH - thumbH);
                int maxOffset = Math.Max(1, _contentHeight - Height);
                int target = _dragStartOffset + (int)((e.Y - _dragStartY) / range * maxOffset);
                target = Math.Max(0, Math.Min(maxOffset, target));
                if (target != _scrollOffset)
                {
                    _scrollOffset = target;
                    LayoutContent();
                }
            }
            base.OnMouseMove(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (_draggingThumb)
            {
                _draggingThumb = false;
                Invalidate();
            }
            base.OnMouseUp(e);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.ApplyDarkTheme(Handle);
        }
    }
}
