using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace SteveClient
{
    internal sealed class ProfileDialog : Form
    {
        public string ProfileName { get; private set; }
        public string ProfilePath { get; private set; }

        private readonly TextBox _name;
        private readonly TextBox _path;
        private readonly TextLabel _warning;
        private readonly PillButton _browse;
        private bool _drag;
        private Point _dragPoint;

        public ProfileDialog()
        {
            Text = Theme.ProductName;
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            BackColor = Theme.Border;
            Padding = new Padding(1);
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(Theme.S(460), Theme.S(300));
            DoubleBuffered = true;
            KeyPreview = true;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);

            Panel body = new Panel();
            body.Dock = DockStyle.Fill;
            body.BackColor = Theme.Bg;
            body.Paint += BodyPaint;
            body.MouseDown += DragDown;
            body.MouseMove += DragMove;
            body.MouseUp += DragUp;
            Controls.Add(body);

            TextLabel title = MakeLabel("新增游戏档案", Theme.Display(18f, FontStyle.Bold), Theme.Text);
            title.Location = new Point(Theme.S(24f), Theme.S(18f));
            title.Size = new Size(Theme.S(360f), Theme.S(30f));
            body.Controls.Add(title);

            TextLabel subtitle = MakeLabel("给档案起一个名字，并选择它要启动的程序。",
                Theme.Ui(9.2f), Theme.Muted2);
            subtitle.Location = new Point(Theme.S(24f), Theme.S(49f));
            subtitle.Size = new Size(Theme.S(390f), Theme.S(20f));
            body.Controls.Add(subtitle);

            TextLabel nameLabel = MakeLabel("档案名称", Theme.Ui(8.8f, FontStyle.Bold), Theme.Muted2);
            nameLabel.Location = new Point(Theme.S(24f), Theme.S(82f));
            nameLabel.Size = new Size(Theme.S(200f), Theme.S(16f));
            body.Controls.Add(nameLabel);

            _name = MakeTextBox();
            _name.MaxLength = 48;
            _name.Location = new Point(Theme.S(24f), Theme.S(102f));
            _name.Size = new Size(Theme.S(390f), Theme.S(26f));
            body.Controls.Add(_name);

            TextLabel pathLabel = MakeLabel("启动路径", Theme.Ui(8.8f, FontStyle.Bold), Theme.Muted2);
            pathLabel.Location = new Point(Theme.S(24f), Theme.S(138f));
            pathLabel.Size = new Size(Theme.S(200f), Theme.S(16f));
            body.Controls.Add(pathLabel);

            _path = MakeTextBox();
            _path.Location = new Point(Theme.S(24f), Theme.S(158f));
            _path.Size = new Size(Theme.S(300f), Theme.S(26f));
            body.Controls.Add(_path);

            _browse = new PillButton();
            _browse.Text = "浏览";
            _browse.Icon = IconGlyph.Folder;
            _browse.Font = Theme.Ui(9.2f, FontStyle.Bold);
            _browse.Size = new Size(Theme.S(80f), Theme.S(30f));
            _browse.Location = new Point(Theme.S(334f), Theme.S(156f));
            _browse.Click += delegate { Browse(); };
            body.Controls.Add(_browse);

            _warning = MakeLabel(string.Empty, Theme.Ui(8.8f), Theme.Danger);
            _warning.Location = new Point(Theme.S(24f), Theme.S(196f));
            _warning.Size = new Size(Theme.S(400f), Theme.S(20f));
            body.Controls.Add(_warning);

            PillButton cancel = new PillButton();
            cancel.Text = "取消";
            cancel.Font = Theme.Ui(9.2f, FontStyle.Bold);
            cancel.Size = new Size(Theme.S(94f), Theme.S(38f));
            cancel.Location = new Point(ClientSize.Width - Theme.S(24f) - Theme.S(112f) - Theme.S(10f) - cancel.Width,
                ClientSize.Height - Theme.S(24f) - cancel.Height);
            cancel.Click += delegate { DialogResult = DialogResult.Cancel; Close(); };
            body.Controls.Add(cancel);

            PillButton add = new PillButton();
            add.Text = "添加档案";
            add.Icon = IconGlyph.Plus;
            add.Primary = true;
            add.Font = Theme.Ui(9.2f, FontStyle.Bold);
            add.Size = new Size(Theme.S(112f), Theme.S(38f));
            add.Location = new Point(ClientSize.Width - Theme.S(24f) - add.Width,
                ClientSize.Height - Theme.S(24f) - add.Height);
            add.Click += delegate { Confirm(); };
            body.Controls.Add(add);

            IconButton close = new IconButton();
            close.Glyph = IconGlyph.Close;
            close.CloseStyle = true;
            close.Size = new Size(Theme.S(30f), Theme.S(30f));
            close.Location = new Point(ClientSize.Width - Theme.S(42f), Theme.S(12f));
            close.Click += delegate { DialogResult = DialogResult.Cancel; Close(); };
            body.Controls.Add(close);

            KeyDown += delegate(object sender, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Escape)
                {
                    DialogResult = DialogResult.Cancel;
                    Close();
                }
                else if (e.KeyCode == Keys.Enter)
                {
                    Confirm();
                    e.SuppressKeyPress = true;
                }
            };
            Shown += delegate
            {
                try
                {
                    int corner = 2;
                    Native.DwmSetWindowAttribute(Handle, Native.DWMWA_WINDOW_CORNER_PREFERENCE, ref corner, sizeof(int));
                }
                catch { }
                ApplyRegion();
                _browse.Top = _path.Top + (_path.Height - _browse.Height) / 2;
                _name.Focus();
            };
        }

        private TextLabel MakeLabel(string text, Font font, Color color)
        {
            TextLabel label = new TextLabel();
            label.Text = text;
            label.Font = font;
            label.ForeColor = color;
            label.BackColor = Theme.Bg;
            label.AutoSize = false;
            label.TextAlign = ContentAlignment.MiddleLeft;
            return label;
        }

        private TextBox MakeTextBox()
        {
            TextBox box = new TextBox();
            box.BorderStyle = BorderStyle.FixedSingle;
            box.BackColor = Theme.Surface2;
            box.ForeColor = Theme.Text;
            box.Font = Theme.Mono(9.8f, FontStyle.Regular);
            return box;
        }

        private void Browse()
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "选择该档案的启动程序";
                dialog.Filter = "可执行文件 (*.exe;*.lnk;*.bat;*.cmd)|*.exe;*.lnk;*.bat;*.cmd|所有文件 (*.*)|*.*";
                dialog.CheckFileExists = true;
                dialog.Multiselect = false;
                if (!string.IsNullOrWhiteSpace(_path.Text) && File.Exists(_path.Text))
                {
                    string directory = Path.GetDirectoryName(_path.Text);
                    if (!string.IsNullOrEmpty(directory)) dialog.InitialDirectory = directory;
                }
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                _path.Text = dialog.FileName;
                if (string.IsNullOrWhiteSpace(_name.Text))
                    _name.Text = Path.GetFileNameWithoutExtension(dialog.FileName);
            }
        }

        private void Confirm()
        {
            string name = _name.Text.Trim();
            string path = _path.Text.Trim();
            if (name.Length == 0)
            {
                _warning.Text = "请先填写档案名称。";
                _name.Focus();
                return;
            }
            if (path.Length == 0)
            {
                _warning.Text = "请选择该档案的启动程序。";
                _path.Focus();
                return;
            }
            if (!File.Exists(path))
            {
                _warning.Text = "启动路径不存在，请重新选择。";
                _path.Focus();
                return;
            }

            ProfileName = name;
            ProfilePath = path;
            DialogResult = DialogResult.OK;
            Close();
        }

        private void BodyPaint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            using (LinearGradientBrush b = new LinearGradientBrush(
                new Rectangle(0, 0, Width, Theme.S(3)), Theme.Accent, Theme.Accent2, 0f))
                g.FillRectangle(b, 0, 0, Width, Theme.S(3));
        }

        private void DragDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                _drag = true;
                _dragPoint = e.Location;
            }
        }

        private void DragMove(object sender, MouseEventArgs e)
        {
            if (_drag)
                Location = new Point(Location.X + e.X - _dragPoint.X, Location.Y + e.Y - _dragPoint.Y);
        }

        private void DragUp(object sender, MouseEventArgs e) { _drag = false; }

        private void ApplyRegion()
        {
            try
            {
                IntPtr rgn = Native.CreateRoundRectRgn(0, 0, Width + 1, Height + 1, Theme.S(16), Theme.S(16));
                if (rgn != IntPtr.Zero) Native.SetWindowRgn(Handle, rgn, true);
            }
            catch { }
        }
    }
}
