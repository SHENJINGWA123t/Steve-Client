using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace SteveClient
{
    internal class ProfileRow : Control
    {
        public GameProfile Profile;
        public bool Selected;
        public bool BatchMode;
        public bool Checked;
        public bool Selectable = true;
        public event EventHandler ActivateRequested;
        public event EventHandler RemoveRequested;
        public event EventHandler SelectionRequested;

        private bool _hover;
        private RectangleF _removeRect;

        public ProfileRow()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor | ControlStyles.Selectable, true);
            BackColor = Theme.Bg;
            Cursor = Cursors.Hand;
            TabStop = true;
        }

        public void Bind(GameProfile profile, bool selected)
        {
            Profile = profile;
            Selected = selected;
            Checked = false;
            Selectable = profile != null && !profile.IsOfficial;
            AccessibleName = profile != null ? profile.Name : string.Empty;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (Profile == null) return;
            Graphics g = e.Graphics;
            Theme.Prepare(g);

            RectangleF rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(11f)))
            {
                Color fill = Selected ? Theme.Mix(Theme.Surface, Theme.Accent, 0.10f)
                    : (_hover ? Theme.Surface2 : Theme.Surface);
                if (Checked) fill = Theme.Mix(fill, Theme.Accent, 0.16f);
                if (Focused) fill = Theme.Mix(fill, Theme.Accent, 0.06f);
                using (SolidBrush b = new SolidBrush(fill))
                    g.FillPath(b, path);
                Color border = Selected || Checked ? Theme.Alpha(Theme.Accent, 150)
                    : (_hover ? Theme.Mix(Theme.Border, Theme.Accent, 0.22f) : Theme.BorderSoft);
                using (Pen pen = new Pen(border, 1f))
                    g.DrawPath(pen, path);
            }

            bool official = Profile.IsOfficial;
            Color accent = official ? Theme.Accent2 : Theme.Accent;
            float pad = Theme.SF(BatchMode ? 42f : 12f);
            float tile = Theme.SF(38f);
            RectangleF tileRect = new RectangleF(pad, (Height - tile) / 2f, tile, tile);
            if (BatchMode)
                DrawCheckbox(g, new RectangleF(Theme.SF(14f), (Height - Theme.SF(20f)) / 2f,
                    Theme.SF(20f), Theme.SF(20f)), Checked, Selectable);
            using (GraphicsPath path = Theme.RoundRect(tileRect, Theme.SF(9f)))
            using (SolidBrush b = new SolidBrush(Theme.Alpha(accent, 26)))
                g.FillPath(b, path);
            float icon = Theme.SF(18f);
            PillButton.DrawGlyph(g, IconGlyph.Profile,
                new RectangleF(tileRect.X + (tile - icon) / 2f, tileRect.Y + (tile - icon) / 2f, icon, icon),
                accent, 1.4f);

            float textX = tileRect.Right + Theme.SF(12f);
            float textW = Math.Max(Theme.SF(60f), Width - textX - Theme.SF(220f));
            using (SolidBrush b = new SolidBrush(Theme.Text))
                g.DrawString(Profile.Name, Theme.Ui(12.2f, FontStyle.Bold), b,
                    new RectangleF(textX, Theme.SF(9f), textW, Theme.SF(22f)), Theme.Near);

            string detail;
            Color detailColor;
            if (official)
            {
                detail = "Microsoft Store · 官方启动";
                detailColor = Theme.Muted2;
            }
            else if (string.IsNullOrWhiteSpace(Profile.LaunchPath))
            {
                detail = "未设置启动路径";
                detailColor = Theme.Warning;
            }
            else if (!File.Exists(Profile.LaunchPath))
            {
                detail = Profile.LaunchPath + "  （路径不存在）";
                detailColor = Theme.Warning;
            }
            else
            {
                detail = Profile.LaunchPath;
                detailColor = Theme.Muted2;
            }
            using (SolidBrush b = new SolidBrush(detailColor))
                g.DrawString(detail, Theme.Mono(8.8f), b,
                    new RectangleF(textX, Theme.SF(31f), textW, Theme.SF(18f)), Theme.Near);

            if (Selected && !BatchMode)
            {
                float badgeW = Theme.SF(72f);
                RectangleF badge = new RectangleF(Width - Theme.SF(92f), Theme.SF(18f), badgeW, Theme.SF(24f));
                using (GraphicsPath path = Theme.RoundRect(badge, Theme.SF(12f)))
                using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Accent, 30)))
                    g.FillPath(b, path);
                using (SolidBrush b = new SolidBrush(Theme.AccentLight))
                    g.DrawString("当前档案", Theme.Ui(8.6f, FontStyle.Bold), b, badge, Theme.Center);
            }

            _removeRect = RectangleF.Empty;
            if (_hover && !official && !BatchMode)
            {
                float size = Theme.SF(24f);
                float removeX = Selected ? Width - Theme.SF(128f) : Width - Theme.SF(40f);
                _removeRect = new RectangleF(removeX, (Height - size) / 2f, size, size);
                using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Danger, 18)))
                    g.FillEllipse(b, _removeRect);
                float glyph = Theme.SF(13f);
                PillButton.DrawGlyph(g, IconGlyph.Trash,
                    new RectangleF(_removeRect.X + (size - glyph) / 2f, _removeRect.Y + (size - glyph) / 2f, glyph, glyph),
                    Theme.Danger, 1.1f);
            }
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }

        private static void DrawCheckbox(Graphics g, RectangleF rect, bool selected, bool enabled)
        {
            Theme.Prepare(g);
            using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(5f)))
            {
                using (SolidBrush b = new SolidBrush(selected
                    ? Theme.Accent
                    : (enabled ? Theme.Surface2 : Theme.Alpha(Theme.Surface2, 90))))
                    g.FillPath(b, path);
                using (Pen pen = new Pen(selected ? Theme.AccentLight
                    : (enabled ? Theme.Border : Theme.Alpha(Theme.BorderSoft, 120)), 1f))
                    g.DrawPath(pen, path);
            }
            if (selected)
            {
                float glyph = rect.Width * 0.58f;
                PillButton.DrawGlyph(g, IconGlyph.Check,
                    new RectangleF(rect.X + (rect.Width - glyph) / 2f,
                        rect.Y + (rect.Height - glyph) / 2f, glyph, glyph),
                    Color.White, 1.8f);
            }
        }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (BatchMode)
                {
                    if (Selectable)
                    {
                        Checked = !Checked;
                        if (SelectionRequested != null) SelectionRequested(this, EventArgs.Empty);
                        Invalidate();
                    }
                }
                else if (!_removeRect.IsEmpty && _removeRect.Contains(e.Location))
                {
                    if (RemoveRequested != null) RemoveRequested(this, EventArgs.Empty);
                }
                else
                {
                    Focus();
                    if (ActivateRequested != null) ActivateRequested(this, EventArgs.Empty);
                }
            }
            base.OnMouseClick(e);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            if (BatchMode && e.KeyCode == Keys.Space && Selectable)
            {
                Checked = !Checked;
                if (SelectionRequested != null) SelectionRequested(this, EventArgs.Empty);
                Invalidate();
                e.Handled = true;
            }
            else if (!BatchMode && e.KeyCode == Keys.Delete && !Profile.IsOfficial)
            {
                if (RemoveRequested != null) RemoveRequested(this, EventArgs.Empty);
                e.Handled = true;
            }
            else if (!BatchMode && e.KeyCode == Keys.Enter)
            {
                if (ActivateRequested != null) ActivateRequested(this, EventArgs.Empty);
                e.Handled = true;
            }
            base.OnKeyUp(e);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.ApplyDarkTheme(Handle);
        }
    }

    internal class ProfileListPanel : Panel
    {
        private readonly List<ProfileRow> _rows = new List<ProfileRow>();
        private List<GameProfile> _profiles = new List<GameProfile>();
        private string _selectedId = string.Empty;
        private int _scrollOffset;
        private int _contentHeight;
        private bool _draggingThumb;
        private int _dragStartY;
        private int _dragStartOffset;
        private RectangleF _thumbRect;
        private bool _batchMode;

        public event Action<GameProfile> SelectRequested;
        public event Action<GameProfile> RemoveRequested;
        public event EventHandler SelectionChanged;

        public ProfileListPanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            AutoScroll = false;
            BackColor = Theme.Bg;
            DoubleBuffered = true;
            TabStop = true;
        }

        public void SetProfiles(List<GameProfile> profiles, string selectedId)
        {
            _profiles = profiles ?? new List<GameProfile>();
            _selectedId = selectedId ?? string.Empty;
            SuspendLayout();
            foreach (ProfileRow row in _rows)
            {
                Controls.Remove(row);
                row.Dispose();
            }
            _rows.Clear();
            foreach (GameProfile profile in _profiles)
            {
                GameProfile captured = profile;
                ProfileRow row = new ProfileRow();
                row.Bind(profile, string.Equals(profile.Id, _selectedId, StringComparison.OrdinalIgnoreCase));
                row.BatchMode = _batchMode;
                row.ActivateRequested += delegate { if (SelectRequested != null) SelectRequested(captured); };
                row.RemoveRequested += delegate { if (RemoveRequested != null) RemoveRequested(captured); };
                row.SelectionRequested += delegate { if (SelectionChanged != null) SelectionChanged(this, EventArgs.Empty); };
                row.MouseWheel += delegate(object sender, MouseEventArgs e) { ScrollBy(-e.Delta * Theme.S(1) / 2); };
                Controls.Add(row);
                _rows.Add(row);
            }
            ResumeLayout(true);
            LayoutRows();
            Invalidate();
        }

        public void SetBatchMode(bool enabled)
        {
            _batchMode = enabled;
            foreach (ProfileRow row in _rows)
            {
                row.BatchMode = enabled;
                row.Checked = false;
                row.Invalidate();
            }
            if (SelectionChanged != null) SelectionChanged(this, EventArgs.Empty);
            Invalidate();
        }

        public List<GameProfile> SelectedProfiles()
        {
            List<GameProfile> list = new List<GameProfile>();
            foreach (ProfileRow row in _rows)
                if (row.Checked && row.Profile != null) list.Add(row.Profile);
            return list;
        }

        public void SelectAll(bool selected)
        {
            foreach (ProfileRow row in _rows)
            {
                if (!row.Selectable) continue;
                row.Checked = selected;
                row.Invalidate();
            }
            if (SelectionChanged != null) SelectionChanged(this, EventArgs.Empty);
        }

        private void LayoutRows()
        {
            int gap = Theme.S(8f);
            int rowHeight = Theme.S(66f);
            _contentHeight = _rows.Count == 0 ? 0 : _rows.Count * (rowHeight + gap) - gap;
            int maxOffset = Math.Max(0, _contentHeight - ClientSize.Height);
            if (_scrollOffset > maxOffset) _scrollOffset = maxOffset;
            if (_scrollOffset < 0) _scrollOffset = 0;

            bool scrollable = _contentHeight > ClientSize.Height;
            int width = ClientSize.Width - Theme.S(4f) - (scrollable ? Theme.S(10f) : 0);
            width = Math.Max(Theme.S(240f), width);

            int y = -_scrollOffset;
            foreach (ProfileRow row in _rows)
            {
                row.Bounds = new Rectangle(0, y, width, rowHeight);
                y += rowHeight + gap;
            }
            Invalidate();
        }

        private void ScrollBy(int amount)
        {
            int maxOffset = Math.Max(0, _contentHeight - ClientSize.Height);
            int next = Math.Max(0, Math.Min(maxOffset, _scrollOffset + amount));
            if (next == _scrollOffset) return;
            _scrollOffset = next;
            LayoutRows();
        }

        protected override void OnResize(EventArgs eventargs)
        {
            base.OnResize(eventargs);
            LayoutRows();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Theme.Bg))
                e.Graphics.FillRectangle(b, ClientRectangle);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            DrawScrollbar(e.Graphics);
        }

        private void DrawScrollbar(Graphics g)
        {
            if (_contentHeight <= ClientSize.Height || ClientSize.Height <= 0)
            {
                _thumbRect = RectangleF.Empty;
                return;
            }
            Theme.Prepare(g);
            float trackW = Theme.SF(5f);
            float x = Width - Theme.SF(10f);
            float top = Theme.SF(4f);
            float trackH = Height - Theme.SF(8f);
            using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Border, 120)))
                Theme.FillRound(g, b, new RectangleF(x, top, trackW, trackH), trackW / 2f);

            float thumbH = Math.Max(Theme.SF(32f), trackH * (float)Height / _contentHeight);
            float maxOffset = Math.Max(1, _contentHeight - Height);
            float thumbY = top + (trackH - thumbH) * ((float)_scrollOffset / maxOffset);
            _thumbRect = new RectangleF(x, thumbY, trackW, thumbH);
            using (SolidBrush b = new SolidBrush(_draggingThumb ? Theme.AccentLight : Theme.Accent))
                Theme.FillRound(g, b, _thumbRect, trackW / 2f);
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            ScrollBy(-e.Delta * Theme.S(1) / 2);
            base.OnMouseWheel(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && !_thumbRect.IsEmpty && _thumbRect.Contains(e.Location))
            {
                _draggingThumb = true;
                _dragStartY = e.Y;
                _dragStartOffset = _scrollOffset;
                Invalidate();
            }
            base.OnMouseDown(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (_draggingThumb)
            {
                float trackH = Height - Theme.SF(8f);
                float thumbH = _thumbRect.Height;
                float range = Math.Max(1f, trackH - thumbH);
                int maxOffset = Math.Max(1, _contentHeight - Height);
                int target = _dragStartOffset + (int)((e.Y - _dragStartY) / range * maxOffset);
                target = Math.Max(0, Math.Min(maxOffset, target));
                if (target != _scrollOffset)
                {
                    _scrollOffset = target;
                    LayoutRows();
                }
            }
            base.OnMouseMove(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (_draggingThumb)
            {
                _draggingThumb = false;
                Invalidate();
            }
            base.OnMouseUp(e);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.ApplyDarkTheme(Handle);
        }
    }
}
