using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace SteveClient
{
    internal class BatchBar : RoundedPanel
    {
        private readonly List<PillButton> _buttons = new List<PillButton>();
        public readonly TextLabel CountLabel;

        public BatchBar()
        {
            Radius = 10;
            BackColor = Theme.Surface;
            CountLabel = new TextLabel();
            CountLabel.Text = "已选择 0 项";
            CountLabel.Font = Theme.Ui(9.2f, FontStyle.Bold);
            CountLabel.ForeColor = Theme.TextSoft;
            CountLabel.BackColor = Theme.Surface;
            CountLabel.AutoSize = false;
            CountLabel.TextAlign = ContentAlignment.MiddleLeft;
            Controls.Add(CountLabel);
        }

        public PillButton AddAction(string text, IconGlyph icon, int width, EventHandler handler)
        {
            PillButton button = new PillButton();
            button.Text = text;
            button.Icon = icon;
            button.CornerRadius = 7f;
            button.Font = Theme.Ui(9f, FontStyle.Bold);
            button.Size = new Size(Theme.S((float)width), Theme.S(30f));
            button.Click += handler;
            Controls.Add(button);
            _buttons.Add(button);
            return button;
        }

        public void SetCount(int count)
        {
            CountLabel.Text = "已选择 " + count + " 项";
        }

        public void LayoutBar(int width)
        {
            int gap = Theme.S(8f);
            int x = width - Theme.S(14f);
            int y = (Height - Theme.S(30f)) / 2;
            for (int i = _buttons.Count - 1; i >= 0; i--)
            {
                x -= _buttons[i].Width;
                _buttons[i].Location = new Point(x, y);
                x -= gap;
            }
            CountLabel.Location = new Point(Theme.S(16f), 0);
            CountLabel.Size = new Size(Math.Max(Theme.S(150f), x - Theme.S(12f)), Height);
        }
    }
}
