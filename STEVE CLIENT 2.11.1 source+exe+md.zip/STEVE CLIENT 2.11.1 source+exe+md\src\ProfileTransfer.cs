using System;
using System.Collections.Generic;
using System.Text;

namespace SteveClient
{
    internal sealed class ProfileImportData
    {
        public List<GameProfile> Profiles = new List<GameProfile>();
        public int SelectedIndex = -1;
        public string Error = string.Empty;
    }

    internal static class ProfileTransfer
    {
        public const string FormatName = "steve-client-profiles";
        public const string Extension = ".steveprofiles";

        public static string Export(AppConfig config)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("{");
            sb.AppendLine("  \"format\": \"" + FormatName + "\",");
            sb.AppendLine("  \"version\": 1,");
            int selectedIndex = 0;
            for (int i = 0; i < config.Profiles.Count; i++)
            {
                if (string.Equals(config.Profiles[i].Id, config.SelectedProfileId,
                    StringComparison.OrdinalIgnoreCase))
                {
                    selectedIndex = i;
                    break;
                }
            }
            sb.AppendLine("  \"selected\": " + selectedIndex + ",");
            sb.AppendLine("  \"profiles\": [");
            for (int i = 0; i < config.Profiles.Count; i++)
            {
                GameProfile profile = config.Profiles[i];
                sb.Append("    { \"name\": \"" + Escape(profile.Name) +
                          "\", \"path\": \"" + Escape(profile.LaunchPath) +
                          "\", \"official\": " + (profile.IsOfficial ? "true" : "false") + " }");
                if (i < config.Profiles.Count - 1) sb.Append(",");
                sb.AppendLine();
            }
            sb.AppendLine("  ]");
            sb.AppendLine("}");
            return sb.ToString();
        }

        public static ProfileImportData Parse(string text)
        {
            ProfileImportData data = new ProfileImportData();
            if (string.IsNullOrWhiteSpace(text))
            {
                data.Error = "文件内容为空。";
                return data;
            }
            try
            {
                Dictionary<string, object> root = JsonLite.AsObject(JsonLite.Parse(text));
                if (root == null)
                {
                    data.Error = "不是有效的 JSON 文件。";
                    return data;
                }
                string format = JsonLite.GetString(root, "format");
                if (!string.IsNullOrEmpty(format) &&
                    !string.Equals(format, FormatName, StringComparison.OrdinalIgnoreCase))
                {
                    data.Error = "不是 STEVE CLIENT 游戏档案文件。";
                    return data;
                }
                List<object> nodes = JsonLite.AsArray(JsonLite.Get(root, "profiles"));
                if (nodes == null)
                {
                    data.Error = "文件中没有 profiles 列表。";
                    return data;
                }
                foreach (object node in nodes)
                {
                    Dictionary<string, object> item = JsonLite.AsObject(node);
                    if (item == null) continue;
                    string name = (JsonLite.GetString(item, "name") ?? string.Empty).Trim();
                    string path = (JsonLite.GetString(item, "path") ?? string.Empty).Trim();
                    bool official = GetBool(item, "official");
                    if (name.Length == 0) continue;
                    GameProfile profile = new GameProfile();
                    profile.Name = name;
                    profile.LaunchPath = path;
                    profile.IsOfficial = official;
                    data.Profiles.Add(profile);
                }
                object selected = JsonLite.Get(root, "selected");
                if (selected is double)
                    data.SelectedIndex = (int)(double)selected;
                else if (selected is long)
                    data.SelectedIndex = (int)(long)selected;
                if (data.Profiles.Count == 0)
                    data.Error = "文件中没有可导入的游戏档案。";
            }
            catch (Exception ex)
            {
                data.Error = "读取失败：" + ex.Message;
            }
            return data;
        }

        private static bool GetBool(Dictionary<string, object> obj, string key)
        {
            object value = JsonLite.Get(obj, key);
            if (value is bool) return (bool)value;
            string text = value as string;
            return text != null && string.Equals(text, "true", StringComparison.OrdinalIgnoreCase);
        }

        private static string Escape(string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            return value.Replace("\\", "\\\\").Replace("\"", "\\\"")
                .Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t");
        }
    }
}
