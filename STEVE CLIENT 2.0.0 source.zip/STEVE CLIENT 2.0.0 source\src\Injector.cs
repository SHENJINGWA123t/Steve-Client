using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

namespace SteveClient
{
    internal sealed class InjectResult
    {
        public bool Success;
        public bool Skipped;
        public string Message;

        public static InjectResult Ok(string message)
        {
            return new InjectResult { Success = true, Message = message };
        }

        public static InjectResult Skip(string message)
        {
            return new InjectResult { Success = true, Skipped = true, Message = message };
        }

        public static InjectResult Fail(string message)
        {
            return new InjectResult { Success = false, Message = message };
        }
    }

    internal static class Injector
    {
        private static bool _debugPrivilegeTried;
        private static bool _debugPrivilegeEnabled;

        public static InjectResult Inject(int processId, string dllPath, bool skipIfLoaded)
        {
            if (!File.Exists(dllPath))
                return InjectResult.Fail("DLL 文件不存在：" + dllPath);

            string fullPath = Path.GetFullPath(dllPath);
            if (!Environment.Is64BitProcess)
                return InjectResult.Fail("启动器不是 64 位进程，无法注入 64 位游戏");

            EnsureDebugPrivilege();

            Process process = null;
            IntPtr hProcess = IntPtr.Zero;
            IntPtr remoteMemory = IntPtr.Zero;
            IntPtr hThread = IntPtr.Zero;
            try
            {
                process = Process.GetProcessById(processId);
                if (process.HasExited) return InjectResult.Fail("游戏进程已经退出");

                bool wow64;
                if (Native.IsWow64Process(process.Handle, out wow64) && wow64)
                    return InjectResult.Fail("目标游戏是 32 位进程，不能注入 64 位 DLL");

                if (skipIfLoaded && IsModuleLoaded(process, fullPath))
                    return InjectResult.Skip("DLL 已经在游戏进程中，跳过重复注入");

                const uint access = Native.PROCESS_CREATE_THREAD | Native.PROCESS_QUERY_INFORMATION |
                                    Native.PROCESS_VM_OPERATION | Native.PROCESS_VM_WRITE | Native.PROCESS_VM_READ;
                hProcess = Native.OpenProcess(access, false, processId);
                if (hProcess == IntPtr.Zero)
                {
                    int err = Marshal.GetLastWin32Error();
                    if (err == 5)
                        return InjectResult.Fail("拒绝访问。请右键启动器，选择“以管理员身份运行”");
                    return InjectResult.Fail("无法打开游戏进程（错误 " + err + "：" + new Win32Exception(err).Message + "）");
                }

                IntPtr loadLibrary = Native.GetProcAddress(Native.GetModuleHandleW("kernel32.dll"), "LoadLibraryW");
                if (loadLibrary == IntPtr.Zero)
                    return InjectResult.Fail("无法获取 LoadLibraryW 地址");

                byte[] pathBytes = System.Text.Encoding.Unicode.GetBytes(fullPath + "\0");
                UIntPtr size = new UIntPtr((uint)pathBytes.Length);
                remoteMemory = Native.VirtualAllocEx(hProcess, IntPtr.Zero, size,
                    Native.MEM_COMMIT | Native.MEM_RESERVE, Native.PAGE_READWRITE);
                if (remoteMemory == IntPtr.Zero)
                    return InjectResult.Fail("在游戏进程中分配内存失败（错误 " + Marshal.GetLastWin32Error() + "）");

                UIntPtr written;
                if (!Native.WriteProcessMemory(hProcess, remoteMemory, pathBytes, size, out written) ||
                    written.ToUInt64() != (ulong)pathBytes.Length)
                    return InjectResult.Fail("写入 DLL 路径失败（错误 " + Marshal.GetLastWin32Error() + "）");

                hThread = Native.CreateRemoteThread(hProcess, IntPtr.Zero, 0, loadLibrary, remoteMemory, 0, IntPtr.Zero);
                if (hThread == IntPtr.Zero)
                {
                    int err = Marshal.GetLastWin32Error();
                    if (err == 5)
                        return InjectResult.Fail("创建远程线程被拒绝，请以管理员身份运行");
                    return InjectResult.Fail("创建远程线程失败（错误 " + err + "：" + new Win32Exception(err).Message + "）");
                }

                uint wait = Native.WaitForSingleObject(hThread, 20000);
                if (wait == Native.WAIT_TIMEOUT)
                    return InjectResult.Fail("注入超时（20 秒）。DLL 可能在初始化时卡住");

                UIntPtr exitCode;
                if (!Native.GetExitCodeThread(hThread, out exitCode))
                    return InjectResult.Fail("读取注入结果失败（错误 " + Marshal.GetLastWin32Error() + "）");

                if (exitCode.ToUInt64() == 0)
                {
                    return InjectResult.Fail("LoadLibrary 返回失败。常见原因：DLL 位数不匹配、缺少依赖、" +
                                             "DLL 与当前游戏版本不兼容，或被安全软件拦截。详情见日志。");
                }

                // Verify that the module is actually present in the target.
                // LoadLibrary returning a handle alone is not enough.
                bool? verified = CheckModuleLoaded(processId, fullPath);
                for (int i = 0; i < 8 && verified == false; i++)
                {
                    Thread.Sleep(250);
                    verified = CheckModuleLoaded(processId, fullPath);
                }
                if (verified == false)
                {
                    return InjectResult.Fail("LoadLibrary 返回成功，但 DLL 未出现在 Minecraft 模块列表中。" +
                                             "可能被游戏卸载或安全软件拦截。");
                }
                if (verified == true)
                    return InjectResult.Ok("LoadLibrary 成功并已确认模块加载，句柄 0x" + exitCode.ToUInt64().ToString("X"));

                return InjectResult.Ok("LoadLibrary 成功，模块句柄 0x" + exitCode.ToUInt64().ToString("X") +
                                       "（无法枚举模块列表进行确认）");
            }
            catch (ArgumentException)
            {
                return InjectResult.Fail("游戏进程不存在或已经退出");
            }
            catch (Exception ex)
            {
                return InjectResult.Fail("注入异常：" + ex.Message);
            }
            finally
            {
                if (hThread != IntPtr.Zero) Native.CloseHandle(hThread);
                if (remoteMemory != IntPtr.Zero && hProcess != IntPtr.Zero)
                    Native.VirtualFreeEx(hProcess, remoteMemory, UIntPtr.Zero, Native.MEM_RELEASE);
                if (hProcess != IntPtr.Zero) Native.CloseHandle(hProcess);
                if (process != null) process.Dispose();
            }
        }

        private static bool IsModuleLoaded(Process process, string fullPath)
        {
            bool? loaded = CheckModuleLoaded(process.Id, fullPath);
            return loaded == true;
        }

        private static bool? CheckModuleLoaded(int processId, string fullPath)
        {
            try
            {
                using (Process process = Process.GetProcessById(processId))
                {
                    string fileName = Path.GetFileName(fullPath);
                    foreach (ProcessModule module in process.Modules)
                    {
                        try
                        {
                            if (string.Equals(module.FileName, fullPath, StringComparison.OrdinalIgnoreCase) ||
                                string.Equals(module.ModuleName, fileName, StringComparison.OrdinalIgnoreCase))
                                return true;
                        }
                        catch { }
                    }
                    return false;
                }
            }
            catch
            {
                // Access denied or the process exited. The caller treats this
                // as "could not verify" instead of claiming failure.
                return null;
            }
        }

        public static bool EnsureDebugPrivilege()
        {
            if (_debugPrivilegeTried) return _debugPrivilegeEnabled;
            _debugPrivilegeTried = true;
            IntPtr token = IntPtr.Zero;
            try
            {
                if (!Native.OpenProcessToken(Process.GetCurrentProcess().Handle,
                    Native.TOKEN_ADJUST_PRIVILEGES | Native.TOKEN_QUERY, out token))
                    return false;

                Native.LUID luid;
                if (!Native.LookupPrivilegeValue(null, "SeDebugPrivilege", out luid))
                    return false;

                Native.TOKEN_PRIVILEGES tp = new Native.TOKEN_PRIVILEGES();
                tp.PrivilegeCount = 1;
                tp.Privilege.Luid = luid;
                tp.Privilege.Attributes = Native.SE_PRIVILEGE_ENABLED;

                if (!Native.AdjustTokenPrivileges(token, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero))
                    return false;

                _debugPrivilegeEnabled = Marshal.GetLastWin32Error() == 0;
                return _debugPrivilegeEnabled;
            }
            catch { return false; }
            finally
            {
                if (token != IntPtr.Zero) Native.CloseHandle(token);
            }
        }
    }
}
