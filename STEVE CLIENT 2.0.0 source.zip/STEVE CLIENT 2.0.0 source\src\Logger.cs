using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SteveClient
{
    internal enum LogLevel
    {
        Info,
        Success,
        Warning,
        Error
    }

    internal sealed class LogEntry
    {
        public DateTime Time;
        public LogLevel Level;
        public string Message;

        public LogEntry(DateTime time, LogLevel level, string message)
        {
            Time = time;
            Level = level;
            Message = message;
        }

        public override string ToString()
        {
            return Time.ToString("HH:mm:ss") + "  " + Message;
        }
    }

    internal static class Log
    {
        private static readonly object Sync = new object();
        private static readonly List<LogEntry> Entries = new List<LogEntry>();
        private static StreamWriter _writer;
        private static string _currentFile;
        private static DateTime _currentDate;
        private static bool _initialized;

        public static event Action<LogEntry> EntryAdded;

        public static string CurrentFile
        {
            get { lock (Sync) return _currentFile; }
        }

        public static void Initialize()
        {
            lock (Sync)
            {
                if (_initialized) return;
                _initialized = true;
                try
                {
                    Directory.CreateDirectory(AppPaths.LogDir);
                    OpenWriter(DateTime.Now);
                }
                catch { }
            }
        }

        private static void OpenWriter(DateTime now)
        {
            if (_writer != null)
            {
                try { _writer.Flush(); _writer.Dispose(); } catch { }
            }
            _currentDate = now.Date;
            _currentFile = Path.Combine(AppPaths.LogDir, "steve-client-" + now.ToString("yyyyMMdd") + ".log");
            _writer = new StreamWriter(new FileStream(_currentFile, FileMode.Append, FileAccess.Write, FileShare.ReadWrite), new UTF8Encoding(false));
            _writer.AutoFlush = true;
        }

        public static void Info(string message) { Write(LogLevel.Info, message); }
        public static void Ok(string message) { Write(LogLevel.Success, message); }
        public static void Warn(string message) { Write(LogLevel.Warning, message); }
        public static void Error(string message) { Write(LogLevel.Error, message); }

        public static void Write(LogLevel level, string message)
        {
            LogEntry entry = new LogEntry(DateTime.Now, level, message ?? string.Empty);
            lock (Sync)
            {
                Entries.Add(entry);
                if (Entries.Count > 1500) Entries.RemoveRange(0, Entries.Count - 1500);
                try
                {
                    Initialize();
                    if (_writer == null || _currentDate != DateTime.Now.Date)
                        OpenWriter(DateTime.Now);
                    _writer.WriteLine(entry.Time.ToString("yyyy-MM-dd HH:mm:ss.fff") + " [" + LevelName(level) + "] " + entry.Message);
                }
                catch { }
            }
            Action<LogEntry> handler = EntryAdded;
            if (handler != null)
            {
                try { handler(entry); } catch { }
            }
        }

        public static string LevelName(LogLevel level)
        {
            switch (level)
            {
                case LogLevel.Success: return " OK ";
                case LogLevel.Warning: return "WARN";
                case LogLevel.Error: return "FAIL";
                default: return "INFO";
            }
        }

        public static LogEntry[] Snapshot()
        {
            lock (Sync) return Entries.ToArray();
        }

        public static void ClearMemory()
        {
            lock (Sync) Entries.Clear();
        }
    }
}
