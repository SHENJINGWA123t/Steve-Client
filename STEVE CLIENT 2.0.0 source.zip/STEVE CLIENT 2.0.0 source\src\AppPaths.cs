using System;
using System.Diagnostics;
using System.IO;
using System.Security.Principal;
using System.Text;
using System.Windows.Forms;

namespace SteveClient
{
    internal static class AppPaths
    {
        public const string DataFolderName = "STEVE CLIENT";

        public static readonly string BaseDir = ResolveBaseDir();
        public static readonly string DataDir = Path.Combine(BaseDir, DataFolderName);
        public static readonly string DllDir = Path.Combine(DataDir, "DLLs");
        public static readonly string LogDir = Path.Combine(DataDir, "logs");
        public static readonly string ConfigFile = Path.Combine(DataDir, "config.ini");
        public static readonly string TrashDir = Path.Combine(DllDir, ".trash");

        public static bool IsFirstRun { get; private set; }

        private static string ResolveBaseDir()
        {
            try
            {
                string dir = AppDomain.CurrentDomain.BaseDirectory;
                if (!string.IsNullOrWhiteSpace(dir)) return dir.TrimEnd('\\', '/');
            }
            catch { }
            return Path.GetDirectoryName(Application.ExecutablePath);
        }

        public static void Ensure()
        {
            IsFirstRun = !File.Exists(ConfigFile);
            Directory.CreateDirectory(DataDir);
            Directory.CreateDirectory(DllDir);
            Directory.CreateDirectory(LogDir);
            Directory.CreateDirectory(TrashDir);

            string guide = Path.Combine(DllDir, "把 DLL 放在这里.txt");
            if (!File.Exists(guide))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("STEVE CLIENT / DLL 文件夹");
                sb.AppendLine("================================");
                sb.AppendLine();
                sb.AppendLine("把需要注入的 .dll 文件直接放到这个文件夹里。");
                sb.AppendLine("启动器会自动扫描、按名称排序并注入所有已启用的 DLL。");
                sb.AppendLine();
                sb.AppendLine("提示：");
                sb.AppendLine("1. Minecraft for Windows（基岩版）是 64 位程序，DLL 也必须是 64 位。");
                sb.AppendLine("2. 修改文件夹后启动器会自动刷新，也可以点击“刷新”。");
                sb.AppendLine("3. 移除的 DLL 会被移动到 DLLs\\.trash，不会立即删除。");
                sb.AppendLine("4. 游戏更新后，部分客户端 DLL 可能需要同步更新。");
                File.WriteAllText(guide, sb.ToString(), new UTF8Encoding(true));
            }
        }

        public static void OpenDllFolder()
        {
            Ensure();
            Process.Start(new ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = "\"" + DllDir + "\"",
                UseShellExecute = true
            });
        }

        public static void OpenLogFolder()
        {
            Directory.CreateDirectory(LogDir);
            Process.Start(new ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = "\"" + LogDir + "\"",
                UseShellExecute = true
            });
        }

        public static bool IsAdministrator()
        {
            try
            {
                using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
                {
                    WindowsPrincipal principal = new WindowsPrincipal(identity);
                    return principal.IsInRole(WindowsBuiltInRole.Administrator);
                }
            }
            catch { return false; }
        }

        public static void RestartElevated()
        {
            try
            {
                ProcessStartInfo info = new ProcessStartInfo(Application.ExecutablePath);
                info.UseShellExecute = true;
                info.Verb = "runas";
                Process.Start(info);
                Application.Exit();
            }
            catch (Exception ex)
            {
                Log.Warn("请求管理员权限失败：" + ex.Message);
            }
        }
    }
}
