from PIL import Image, ImageDraw, ImageFilter
import os

OUT = os.path.join(os.path.dirname(__file__), "app.ico")
S = 1024

# New default Steve skin face, taken from the official 8x8 head texture
# (rows 8..15, columns 8..15 of the vanilla steve.png skin).
FACE = [
    [(51, 36, 17), (51, 36, 17), (63, 42, 21), (63, 42, 21), (63, 42, 21), (63, 42, 21), (51, 36, 17), (43, 30, 13)],
    [(36, 24, 8), (51, 36, 17), (51, 36, 17), (63, 42, 21), (63, 42, 21), (51, 36, 17), (63, 42, 21), (51, 36, 17)],
    [(43, 30, 13), (155, 99, 73), (179, 121, 94), (183, 131, 107), (179, 121, 94), (170, 114, 89), (155, 99, 73), (52, 37, 18)],
    [(155, 99, 73), (170, 114, 89), (179, 121, 94), (179, 121, 94), (170, 114, 89), (170, 114, 89), (170, 114, 89), (155, 99, 73)],
    [(170, 114, 89), (255, 255, 255), (82, 61, 137), (170, 114, 89), (155, 99, 73), (82, 61, 137), (255, 255, 255), (170, 114, 89)],
    [(155, 99, 73), (170, 114, 89), (170, 114, 89), (106, 64, 48), (106, 64, 48), (170, 114, 89), (170, 114, 89), (155, 99, 73)],
    [(144, 89, 63), (143, 94, 62), (73, 37, 16), (119, 66, 53), (119, 66, 53), (66, 29, 10), (143, 94, 62), (129, 83, 57)],
    [(148, 96, 62), (129, 83, 57), (66, 29, 10), (73, 37, 16), (66, 29, 10), (73, 37, 16), (129, 83, 57), (143, 94, 62)],
]

TOP_HAIR = (47, 32, 17)
SIDE_HAIR = (29, 19, 10)
EDGE_LIGHT = (176, 148, 112)
EDGE_DARK = (16, 10, 6)


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(len(a)))


def gradient(size, top_left, bottom_right):
    img = Image.new("RGBA", (size, size))
    px = img.load()
    for y in range(size):
        for x in range(size):
            t = min(1.0, max(0.0, (x + y) / (2.0 * (size - 1)) * 1.10))
            px[x, y] = lerp(top_left, bottom_right, t)
    return img


def rounded_mask(size, margin, radius):
    mask = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(mask)
    d.rounded_rectangle((margin, margin, size - 1 - margin, size - 1 - margin), radius=radius, fill=255)
    return mask


def draw_face(base, x, y, cell, outline):
    """Paste the official 8x8 face with crisp pixel boundaries."""
    d = ImageDraw.Draw(base)
    # Dark backing / bevel.
    d.rectangle((x - outline, y - outline, x + cell * 8 + outline, y + cell * 8 + outline), fill=EDGE_DARK)
    for row in range(8):
        for col in range(8):
            color = FACE[row][col]
            x0 = x + col * cell
            y0 = y + row * cell
            d.rectangle((x0, y0, x0 + cell - 1, y0 + cell - 1), fill=color + (255,))
    # A soft highlight catches the upper-left edge of the head.
    d.line((x, y, x + cell * 8, y), fill=EDGE_LIGHT + (170,), width=max(2, cell // 18))
    d.line((x, y, x, y + cell * 8), fill=EDGE_LIGHT + (90,), width=max(2, cell // 24))


def build_large(size):
    outer = gradient(S, (124, 58, 237, 255), (6, 182, 212, 255))
    mask = rounded_mask(S, 26, 218)
    icon = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    icon.paste(outer, (0, 0), mask)

    d = ImageDraw.Draw(icon)
    # Inner dark plate, leaving the gradient as a thin premium rim.
    d.rounded_rectangle((78, 78, S - 78, S - 78), radius=186, fill=(9, 12, 20, 255))
    d.rounded_rectangle((78, 78, S - 78, S - 78), radius=186, outline=(255, 255, 255, 38), width=8)

    # Ambient glow around the head.
    glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((210, 250, 850, 860), fill=(34, 211, 238, 42))
    glow = glow.filter(ImageFilter.GaussianBlur(58))
    icon = Image.alpha_composite(icon, glow)
    d = ImageDraw.Draw(icon)

    # Isometric Minecraft head: front face + hair top + hair right side.
    fx, fy = 214, 286
    cell = 68
    face_size = cell * 8
    dx, dy = 104, -104
    top = [(fx, fy), (fx + face_size, fy), (fx + face_size + dx, fy + dy), (fx + dx, fy + dy)]
    right = [(fx + face_size, fy), (fx + face_size + dx, fy + dy),
             (fx + face_size + dx, fy + face_size + dy), (fx + face_size, fy + face_size)]

    # Soft shadow under the block.
    shadow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    sd.ellipse((220, 790, 880, 930), fill=(0, 0, 0, 125))
    shadow = shadow.filter(ImageFilter.GaussianBlur(25))
    icon = Image.alpha_composite(icon, shadow)
    d = ImageDraw.Draw(icon)

    d.polygon(top, fill=TOP_HAIR + (255,))
    d.polygon(right, fill=SIDE_HAIR + (255,))

    # Block edges.
    d.line(top + [top[0]], fill=(123, 89, 57, 255), width=7)
    d.line(right + [right[0]], fill=(88, 59, 34, 255), width=7)
    d.line((fx, fy, fx + face_size, fy), fill=EDGE_LIGHT + (210,), width=7)
    d.line((fx, fy, fx, fy + face_size), fill=EDGE_LIGHT + (135,), width=7)

    draw_face(icon, fx, fy, cell, 9)

    # A few subtle hair pixels on the top face, matching the skin's pixel feel.
    small = ImageDraw.Draw(icon)
    for i in range(9):
        px = fx + 20 + i * 44
        py = fy - 40 - (i % 3) * 8
        small.rectangle((px, py, px + 22, py + 16), fill=(59, 40, 21, 255))
    for i in range(5):
        px = fx + face_size + 18
        py = fy - 42 + i * 55
        small.rectangle((px, py, px + 34, py + 22), fill=(38, 25, 13, 255))

    if size != S:
        icon = icon.resize((size, size), Image.LANCZOS)
    return icon


def build_small(size):
    base_size = 512
    outer = gradient(base_size, (124, 58, 237, 255), (6, 182, 212, 255))
    mask = rounded_mask(base_size, 10, 112)
    icon = Image.new("RGBA", (base_size, base_size), (0, 0, 0, 0))
    icon.paste(outer, (0, 0), mask)
    d = ImageDraw.Draw(icon)
    d.rounded_rectangle((36, 36, base_size - 36, base_size - 36), radius=94, fill=(9, 12, 20, 255))
    d.rounded_rectangle((36, 36, base_size - 36, base_size - 36), radius=94, outline=(255, 255, 255, 34), width=5)

    face_x, face_y = 69, 69
    cell = 47
    draw_face(icon, face_x, face_y, cell, 7)

    # Make the head feel built from blocks even at tiny sizes.
    d.line((face_x, face_y, face_x + cell * 8, face_y), fill=EDGE_LIGHT + (200,), width=4)
    d.line((face_x, face_y, face_x, face_y + cell * 8), fill=EDGE_LIGHT + (95,), width=4)
    return icon.resize((size, size), Image.LANCZOS)


def build(size):
    if size <= 32:
        return build_small(size)
    return build_large(size)


sizes = [16, 24, 32, 48, 64, 128, 256]
images = [build(s) for s in sizes]
images[-1].save(OUT, format="ICO", sizes=[(s, s) for s in sizes], append_images=images[:-1])
build(512).save(os.path.join(os.path.dirname(__file__), "icon-preview.png"))
print("wrote", OUT)
