using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SteveClient
{
    internal sealed class AppConfig
    {
        public bool FirstRunCompleted;
        public int InjectDelayMs = 2500;
        public bool MinimizeAfterInject = true;
        public bool CloseAfterInject = false;
        public bool VerifyArchitecture = true;
        public string ResourceDataDir = string.Empty;
        public bool ResourceCustom;
        public string ResourceScanDir = string.Empty;
        public readonly Dictionary<string, bool> DllStates = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);

        public static AppConfig Load(string path)
        {
            AppConfig config = new AppConfig();
            if (!File.Exists(path)) return config;

            string section = "general";
            try
            {
                foreach (string raw in File.ReadAllLines(path, Encoding.UTF8))
                {
                    string line = raw.Trim();
                    if (line.Length == 0 || line.StartsWith(";") || line.StartsWith("#")) continue;
                    if (line.StartsWith("[") && line.EndsWith("]"))
                    {
                        section = line.Substring(1, line.Length - 2).Trim().ToLowerInvariant();
                        continue;
                    }
                    int eq = line.IndexOf('=');
                    if (eq < 0) continue;
                    string key = line.Substring(0, eq).Trim();
                    string value = line.Substring(eq + 1).Trim();
                    if (section == "general")
                    {
                        if (key.Equals("firstRunCompleted", StringComparison.OrdinalIgnoreCase))
                            config.FirstRunCompleted = ParseBool(value, config.FirstRunCompleted);
                        else if (key.Equals("injectDelayMs", StringComparison.OrdinalIgnoreCase))
                            config.InjectDelayMs = ParseInt(value, config.InjectDelayMs);
                        else if (key.Equals("minimizeAfterInject", StringComparison.OrdinalIgnoreCase))
                            config.MinimizeAfterInject = ParseBool(value, config.MinimizeAfterInject);
                        else if (key.Equals("closeAfterInject", StringComparison.OrdinalIgnoreCase))
                            config.CloseAfterInject = ParseBool(value, config.CloseAfterInject);
                        else if (key.Equals("verifyArchitecture", StringComparison.OrdinalIgnoreCase))
                            config.VerifyArchitecture = ParseBool(value, config.VerifyArchitecture);
                        else if (key.Equals("resourceDataDir", StringComparison.OrdinalIgnoreCase))
                            config.ResourceDataDir = value;
                    }
                    else if (section == "resources")
                    {
                        if (key.Equals("dataDir", StringComparison.OrdinalIgnoreCase) ||
                            key.Equals("resourceDataDir", StringComparison.OrdinalIgnoreCase))
                            config.ResourceDataDir = value;
                        else if (key.Equals("custom", StringComparison.OrdinalIgnoreCase))
                            config.ResourceCustom = ParseBool(value, config.ResourceCustom);
                        else if (key.Equals("scanDir", StringComparison.OrdinalIgnoreCase))
                            config.ResourceScanDir = value;
                    }
                    else if (section == "dlls")
                    {
                        if (key.Length > 0) config.DllStates[key] = ParseBool(value, true);
                    }
                }
            }
            catch { }

            if (config.InjectDelayMs < 500) config.InjectDelayMs = 500;
            if (config.InjectDelayMs > 15000) config.InjectDelayMs = 15000;
            return config;
        }

        public void Save(string path)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("; STEVE CLIENT configuration");
                sb.AppendLine("; This file is generated automatically.");
                sb.AppendLine();
                sb.AppendLine("[general]");
                sb.AppendLine("firstRunCompleted=" + (FirstRunCompleted ? "true" : "false"));
                sb.AppendLine("injectDelayMs=" + InjectDelayMs);
                sb.AppendLine("minimizeAfterInject=" + (MinimizeAfterInject ? "true" : "false"));
                sb.AppendLine("closeAfterInject=" + (CloseAfterInject ? "true" : "false"));
                sb.AppendLine("verifyArchitecture=" + (VerifyArchitecture ? "true" : "false"));
                sb.AppendLine();
                sb.AppendLine("[dlls]");
                foreach (KeyValuePair<string, bool> pair in DllStates)
                {
                    if (string.IsNullOrWhiteSpace(pair.Key)) continue;
                    sb.AppendLine(pair.Key.Replace("=", "_") + "=" + (pair.Value ? "true" : "false"));
                }
                sb.AppendLine();
                sb.AppendLine("[resources]");
                sb.AppendLine("dataDir=" + (ResourceDataDir ?? string.Empty));
                sb.AppendLine("custom=" + (ResourceCustom ? "true" : "false"));
                sb.AppendLine("scanDir=" + (ResourceScanDir ?? string.Empty));

                string tmp = path + ".tmp";
                File.WriteAllText(tmp, sb.ToString(), new UTF8Encoding(false));
                if (File.Exists(path)) File.Delete(path);
                File.Move(tmp, path);
            }
            catch (Exception ex)
            {
                Log.Warn("保存配置失败：" + ex.Message);
            }
        }

        public bool? GetDllState(string fileName)
        {
            bool value;
            if (DllStates.TryGetValue(fileName, out value)) return value;
            return null;
        }

        public void SetDllState(string fileName, bool enabled)
        {
            DllStates[fileName] = enabled;
        }

        private static bool ParseBool(string value, bool fallback)
        {
            if (string.IsNullOrWhiteSpace(value)) return fallback;
            value = value.Trim();
            if (value.Equals("true", StringComparison.OrdinalIgnoreCase) || value == "1" || value.Equals("yes", StringComparison.OrdinalIgnoreCase)) return true;
            if (value.Equals("false", StringComparison.OrdinalIgnoreCase) || value == "0" || value.Equals("no", StringComparison.OrdinalIgnoreCase)) return false;
            return fallback;
        }

        private static int ParseInt(string value, int fallback)
        {
            int result;
            if (int.TryParse(value, out result)) return result;
            return fallback;
        }
    }
}
