param(
    [switch]$Test,
    [switch]$NoZip
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$src = Join-Path $root 'src'
$build = Join-Path $root 'build'
$dist = Join-Path $root 'dist'

New-Item -ItemType Directory -Force -Path $build, $dist | Out-Null

$csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path $csc)) { throw "C# compiler not found: $csc" }

$rc = $null
$kits = 'C:\Program Files (x86)\Windows Kits\10\bin'
if (Test-Path $kits) {
    $rcItem = Get-ChildItem $kits -Recurse -Filter 'rc.exe' -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -match '\\x64\\rc\.exe$' } |
        Sort-Object FullName -Descending |
        Select-Object -First 1
    if ($rcItem) { $rc = $rcItem.FullName }
}
if (-not $rc) {
    $found = Get-Command rc.exe -ErrorAction SilentlyContinue
    if ($found) { $rc = $found.Source }
}

$icon = Join-Path $root 'assets\app.ico'
if (-not (Test-Path $icon)) {
    $py = 'C:\Users\72425\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe'
    if (Test-Path $py) { & $py (Join-Path $root 'assets\make_icon.py') | Out-Null }
}
if (-not (Test-Path $icon)) { throw 'Missing assets\app.ico (run assets\make_icon.py)' }
$logoPng = Join-Path $root 'assets\icon-preview.png'
if (-not (Test-Path $logoPng)) { throw 'Missing assets\icon-preview.png (run assets\make_icon.py)' }

$res = Join-Path $build 'app.res'
if ($rc) {
    Push-Location $root
    try { & $rc /nologo /fo $res 'app.rc' | Out-Null } finally { $rcCode = $LASTEXITCODE; Pop-Location }
    if ($rcCode -ne 0) { throw 'rc.exe failed to compile resources' }
} else {
    $res = $null
}

$sources = @(
    'AssemblyInfo.cs',
    'Theme.cs',
    'Native.cs',
    'AppPaths.cs',
    'Logger.cs',
    'Config.cs',
    'DllManager.cs',
    'ContentManager.cs',
    'Injector.cs',
    'GameLauncher.cs',
    'Controls.cs',
    'ContentControls.cs',
    'DllControls.cs',
    'Dialogs.cs',
    'MainForm.cs',
    'Program.cs'
) | ForEach-Object { Join-Path $src $_ }

$versionMatch = Select-String -Path (Join-Path $src 'Theme.cs') -Pattern 'Version\s*=\s*"([0-9]+\.[0-9]+\.[0-9]+)"' | Select-Object -First 1
if (-not $versionMatch) { throw 'Could not read version from src\Theme.cs' }
$version = $versionMatch.Matches[0].Groups[1].Value
$baseName = "STEVE CLIENT $version"

$outName = if ($Test) { $baseName + '.test.exe' } else { $baseName + '.exe' }
$out = Join-Path $dist $outName
$manifest = if ($Test) { 'app.test.manifest' } else { 'app.manifest' }

$cscArgs = @(
    '/nologo',
    '/target:winexe',
    '/platform:x64',
    '/optimize+',
    '/codepage:65001',
    '/warn:4',
    ('/out:dist\' + $outName),
    '/reference:System.dll',
    '/reference:System.Core.dll',
    '/reference:System.Drawing.dll',
    '/reference:System.IO.Compression.dll',
    '/reference:System.IO.Compression.FileSystem.dll',
    '/reference:System.Windows.Forms.dll'
)
if ($Test) {
    $cscArgs += ('/win32manifest:' + $manifest)
    $cscArgs += '/win32icon:assets\app.ico'
} elseif ($res) {
    $cscArgs += '/win32res:build\app.res'
} else {
    $cscArgs += ('/win32manifest:' + $manifest)
    $cscArgs += '/win32icon:assets\app.ico'
}
$cscArgs += '/resource:assets\icon-preview.png,SteveIcon.png'
$cscArgs += $sources

Push-Location $root
try { & $csc $cscArgs } finally { $code = $LASTEXITCODE; Pop-Location }
if ($code -ne 0) { throw "Compile failed. csc exit code: $code" }

$hash = Get-FileHash $out -Algorithm SHA256
Write-Host ''
Write-Host "Build complete: $out"
Write-Host ("Size: {0:N0} bytes" -f (Get-Item $out).Length)
Write-Host "SHA256: $($hash.Hash)"

if (-not $Test) {
    $readmeName = "README $version.md"
    Copy-Item (Join-Path $root 'README.md') (Join-Path $dist $readmeName) -Force
    if (-not $NoZip) {
        $zip = Join-Path $dist ($baseName + '.zip')
        if (Test-Path $zip) { Remove-Item $zip -Force }
        Compress-Archive -Path $out, (Join-Path $dist $readmeName) -DestinationPath $zip -Force
        Write-Host "Archive: $zip"
    }
}
