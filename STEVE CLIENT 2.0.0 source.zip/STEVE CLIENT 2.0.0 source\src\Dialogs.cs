using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SteveClient
{
    internal enum DialogKind
    {
        Info,
        Success,
        Warning,
        Error,
        Question
    }

    internal class DialogForm : Form
    {
        public bool Result;
        private readonly string _title;
        private readonly string _message;
        private readonly DialogKind _kind;
        private readonly bool _showCancel;
        private bool _drag;
        private Point _dragPoint;

        private DialogForm(string title, string message, DialogKind kind, bool showCancel, string primaryText, string secondaryText)
        {
            _title = title;
            _message = message;
            _kind = kind;
            _showCancel = showCancel;
            Text = Theme.ProductName;
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            BackColor = Theme.Border;
            Padding = new Padding(1);
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(Theme.S(440), Theme.S(268));
            DoubleBuffered = true;
            KeyPreview = true;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);

            Panel body = new Panel();
            body.Dock = DockStyle.Fill;
            body.BackColor = Theme.Bg;
            body.Paint += BodyPaint;
            body.MouseDown += DragDown;
            body.MouseMove += DragMove;
            body.MouseUp += DragUp;
            Controls.Add(body);

            IconButton close = new IconButton();
            close.Glyph = IconGlyph.Close;
            close.CloseStyle = true;
            close.Size = new Size(Theme.S(30), Theme.S(30));
            close.Location = new Point(ClientSize.Width - Theme.S(42), Theme.S(12));
            close.Click += delegate { Close(); };
            body.Controls.Add(close);

            PillButton primary = new PillButton();
            primary.Text = primaryText;
            primary.Primary = kind != DialogKind.Error;
            primary.Danger = kind == DialogKind.Error;
            primary.Size = new Size(Theme.S(112), Theme.S(38));
            primary.Location = new Point(ClientSize.Width - Theme.S(24) - primary.Width,
                ClientSize.Height - Theme.S(24) - primary.Height);
            primary.Click += delegate { Result = true; Close(); };
            body.Controls.Add(primary);

            if (showCancel)
            {
                PillButton secondary = new PillButton();
                secondary.Text = secondaryText;
                secondary.Size = new Size(Theme.S(94), Theme.S(38));
                secondary.Location = new Point(primary.Left - Theme.S(10) - secondary.Width, primary.Top);
                secondary.Click += delegate { Result = false; Close(); };
                body.Controls.Add(secondary);
            }

            AcceptButton = null;
            KeyDown += delegate(object sender, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Escape)
                {
                    Result = false;
                    Close();
                }
                else if (e.KeyCode == Keys.Enter)
                {
                    Result = !showCancel || kind != DialogKind.Question;
                    Close();
                }
            };
            Shown += delegate
            {
                try
                {
                    int corner = 2;
                    Native.DwmSetWindowAttribute(Handle, Native.DWMWA_WINDOW_CORNER_PREFERENCE, ref corner, sizeof(int));
                }
                catch { }
                ApplyRegion();
            };
        }

        private void BodyPaint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            Color accent = KindColor();
            using (LinearGradientBrush b = new LinearGradientBrush(new Rectangle(0, 0, Width, Theme.S(4)), accent, Theme.Accent2, 0f))
                g.FillRectangle(b, 0, 0, Width, Theme.S(3));
            using (SolidBrush b = new SolidBrush(Theme.Bg))
                g.FillRectangle(b, 0, Theme.S(3), Width, Height - Theme.S(3));

            float circle = Theme.SF(48f);
            RectangleF circleRect = new RectangleF(Theme.SF(24f), Theme.SF(30f), circle, circle);
            using (SolidBrush b = new SolidBrush(Theme.Alpha(accent, 28)))
                g.FillEllipse(b, circleRect);
            using (Pen pen = new Pen(Theme.Alpha(accent, 100), 1f))
                g.DrawEllipse(pen, circleRect);
            IconGlyph glyph = _kind == DialogKind.Success ? IconGlyph.Check : (_kind == DialogKind.Error ? IconGlyph.Warning : (_kind == DialogKind.Question ? IconGlyph.Info : IconGlyph.Info));
            PillButton.DrawGlyph(g, glyph, new RectangleF(circleRect.X + Theme.SF(14f), circleRect.Y + Theme.SF(14f), Theme.SF(20f), Theme.SF(20f)), accent, 1.8f);

            using (SolidBrush b = new SolidBrush(Theme.Text))
                g.DrawString(_title, Theme.Ui(17f, FontStyle.Bold), b,
                    new RectangleF(Theme.SF(88f), Theme.SF(30f), Width - Theme.SF(130f), Theme.SF(28f)), Theme.Near);
            using (SolidBrush b = new SolidBrush(Theme.Muted))
                g.DrawString(_message, Theme.Ui(10.8f), b,
                    new RectangleF(Theme.SF(88f), Theme.SF(64f), Width - Theme.SF(112f), Theme.SF(106f)), MessageFormat());

            using (Pen pen = new Pen(Theme.BorderSoft, 1f))
                g.DrawLine(pen, Theme.SF(24f), Height - Theme.SF(78f), Width - Theme.SF(24f), Height - Theme.SF(78f));
        }

        private static StringFormat MessageFormat()
        {
            StringFormat sf = new StringFormat(StringFormat.GenericTypographic);
            sf.Alignment = StringAlignment.Near;
            sf.LineAlignment = StringAlignment.Near;
            sf.Trimming = StringTrimming.EllipsisWord;
            sf.FormatFlags = 0;
            return sf;
        }

        private Color KindColor()
        {
            switch (_kind)
            {
                case DialogKind.Success: return Theme.Success;
                case DialogKind.Error: return Theme.Danger;
                case DialogKind.Warning: return Theme.Warning;
                case DialogKind.Question: return Theme.Accent2;
                default: return Theme.Accent;
            }
        }

        private void DragDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                _drag = true;
                _dragPoint = e.Location;
            }
        }

        private void DragMove(object sender, MouseEventArgs e)
        {
            if (_drag)
                Location = new Point(Location.X + e.X - _dragPoint.X, Location.Y + e.Y - _dragPoint.Y);
        }

        private void DragUp(object sender, MouseEventArgs e) { _drag = false; }

        private void ApplyRegion()
        {
            try
            {
                IntPtr rgn = Native.CreateRoundRectRgn(0, 0, Width + 1, Height + 1, Theme.S(16), Theme.S(16));
                if (rgn != IntPtr.Zero) Native.SetWindowRgn(Handle, rgn, true);
            }
            catch { }
        }

        public static bool Show(IWin32Window owner, string title, string message, DialogKind kind,
            string primaryText, string secondaryText, bool showCancel)
        {
            using (DialogForm form = new DialogForm(title, message, kind, showCancel, primaryText, secondaryText))
            {
                form.ShowDialog(owner);
                return form.Result;
            }
        }

        public static void Info(IWin32Window owner, string title, string message)
        {
            Show(owner, title, message, DialogKind.Info, "知道了", "取消", false);
        }

        public static void Error(IWin32Window owner, string title, string message)
        {
            Show(owner, title, message, DialogKind.Error, "知道了", "取消", false);
        }

        public static void Warning(IWin32Window owner, string title, string message)
        {
            Show(owner, title, message, DialogKind.Warning, "知道了", "取消", false);
        }

        public static bool Confirm(IWin32Window owner, string title, string message, string primaryText)
        {
            return Show(owner, title, message, DialogKind.Question, primaryText, "取消", true);
        }
    }

    internal sealed class DarkColorTable : ProfessionalColorTable
    {
        public override Color ToolStripDropDownBackground { get { return Theme.Surface2; } }
        public override Color ImageMarginGradientBegin { get { return Theme.Surface2; } }
        public override Color ImageMarginGradientMiddle { get { return Theme.Surface2; } }
        public override Color ImageMarginGradientEnd { get { return Theme.Surface2; } }
        public override Color MenuBorder { get { return Theme.Border; } }
        public override Color MenuItemBorder { get { return Theme.Accent; } }
        public override Color MenuItemSelected { get { return Theme.Surface3; } }
        public override Color MenuItemSelectedGradientBegin { get { return Theme.Surface3; } }
        public override Color MenuItemSelectedGradientEnd { get { return Theme.Surface3; } }
        public override Color SeparatorDark { get { return Theme.BorderSoft; } }
        public override Color SeparatorLight { get { return Theme.BorderSoft; } }
    }

    internal sealed class DarkMenuRenderer : ToolStripProfessionalRenderer
    {
        public DarkMenuRenderer() : base(new DarkColorTable())
        {
            RoundedEdges = false;
        }

        protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
        {
            e.TextColor = e.Item.Enabled ? Theme.TextSoft : Theme.Muted2;
            base.OnRenderItemText(e);
        }

        protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Theme.Surface2))
                e.Graphics.FillRectangle(b, e.AffectedBounds);
        }
    }
}
