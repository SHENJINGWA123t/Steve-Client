using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace SteveClient
{
    internal sealed class MinecraftInstall
    {
        public bool Found;
        public string PackageFamilyName = string.Empty;
        public string AppUserModelId = string.Empty;
        public string Version = string.Empty;
        public bool IsPreview;
        public string DisplayName = "Minecraft for Windows";
    }

    internal static class GameLauncher
    {
        public const string ProcessName = "Minecraft.Windows";
        public const string StableFamily = "Microsoft.MinecraftUWP_8wekyb3d8bbwe";
        public const string PreviewFamily = "Microsoft.MinecraftWindowsBeta_8wekyb3d8bbwe";
        private const string StableNamePrefix = "Microsoft.MinecraftUWP_";
        private const string PreviewNamePrefix = "Microsoft.MinecraftWindowsBeta_";
        public const string StoreUri = "ms-windows-store://pdp/?productid=9NBLGGH2JHXJ";

        public static MinecraftInstall Detect()
        {
            MinecraftInstall result = new MinecraftInstall();
            List<string> packages = GetActivatablePackages();
            string stableKey = FindPackage(packages, StableFamily);
            string previewKey = FindPackage(packages, PreviewFamily);

            string selectedKey = stableKey ?? previewKey;
            if (selectedKey == null)
            {
                // Fallback to repository keys. This still catches packages whose
                // activation registry has not been populated yet.
                packages = GetRepositoryPackages();
                stableKey = FindPackage(packages, StableFamily);
                previewKey = FindPackage(packages, PreviewFamily);
                selectedKey = stableKey ?? previewKey;
            }

            if (selectedKey == null)
            {
                // Fallback to the packaged app state repository used on modern
                // Windows builds. This path does not depend on PowerShell/WinRT.
                packages = GetStateRepositoryPackages();
                stableKey = FindPackage(packages, StableFamily);
                previewKey = FindPackage(packages, PreviewFamily);
                selectedKey = stableKey ?? previewKey;
            }

            if (selectedKey == null) return result;

            result.Found = true;
            result.IsPreview = stableKey == null && previewKey != null;
            result.PackageFamilyName = result.IsPreview ? PreviewFamily : StableFamily;
            result.AppUserModelId = result.PackageFamilyName + "!Game";
            result.DisplayName = result.IsPreview ? "Minecraft Preview for Windows" : "Minecraft for Windows";
            result.Version = ParseVersion(selectedKey);
            return result;
        }

        private static string FindPackage(List<string> packages, string family)
        {
            string prefix = family.StartsWith("Microsoft.MinecraftUWP", StringComparison.OrdinalIgnoreCase)
                ? StableNamePrefix : PreviewNamePrefix;
            foreach (string package in packages)
            {
                if (package.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) ||
                    package.Equals(family, StringComparison.OrdinalIgnoreCase))
                    return package;
            }
            return null;
        }

        private static List<string> GetActivatablePackages()
        {
            List<string> result = new List<string>();
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Classes\ActivatableClasses\Package"))
                {
                    if (key != null) result.AddRange(key.GetSubKeyNames());
                }
            }
            catch { }
            return result;
        }

        private static List<string> GetRepositoryPackages()
        {
            List<string> result = new List<string>();
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\AppModel\Repository\Packages"))
                {
                    if (key != null) result.AddRange(key.GetSubKeyNames());
                }
            }
            catch { }
            return result;
        }

        internal static List<string> GetStateRepositoryPackages()
        {
            List<string> result = new List<string>();
            string[] roots = new string[]
            {
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\AppModel\StateRepository\Cache\Package\Data",
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\AppModel\StateRepository\Cache\Package\Index\PackageFullName"
            };
            foreach (string root in roots)
            {
                try
                {
                    using (RegistryKey baseKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
                    using (RegistryKey key = baseKey.OpenSubKey(root))
                    {
                        if (key == null) continue;
                        foreach (string name in key.GetSubKeyNames())
                        {
                            try
                            {
                                using (RegistryKey child = key.OpenSubKey(name))
                                {
                                    if (child == null) continue;
                                    object full = child.GetValue("PackageFullName");
                                    if (full != null && full.ToString().IndexOf("Minecraft", StringComparison.OrdinalIgnoreCase) >= 0)
                                        result.Add(full.ToString());
                                }
                            }
                            catch { }
                        }
                    }
                }
                catch { }
            }
            return result;
        }

        private static string ParseVersion(string packageKey)        {
            try
            {
                string[] parts = packageKey.Split('_');
                if (parts.Length >= 2) return parts[1];
            }
            catch { }
            return string.Empty;
        }

        public static int Launch(MinecraftInstall install)
        {
            if (install == null || !install.Found)
                throw new InvalidOperationException("未检测到 Minecraft for Windows");

            // Use the official activation manager first. It gives a process id
            // and avoids issues with shell activation on some Windows builds.
            try
            {
                IApplicationActivationManager manager = (IApplicationActivationManager)new ApplicationActivationManager();
                uint pid;
                int hr = manager.ActivateApplication(install.AppUserModelId, null, 0, out pid);
                if (hr >= 0 && pid != 0)
                {
                    Log.Info("UWP 激活成功，PID " + pid);
                    return (int)pid;
                }
                Log.Warn("UWP 激活返回 0x" + hr.ToString("X8") + "，改用 explorer 启动");
            }
            catch (Exception ex)
            {
                Log.Warn("UWP 激活失败：" + ex.Message + "，改用 explorer 启动");
            }

            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = "explorer.exe";
            info.Arguments = "shell:AppsFolder\\" + install.AppUserModelId;
            info.UseShellExecute = true;
            Process.Start(info);
            return 0;
        }

        [ComImport, Guid("2e941141-7f97-4756-ba1d-9decde894a3d"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IApplicationActivationManager
        {
            [PreserveSig]
            int ActivateApplication([MarshalAs(UnmanagedType.LPWStr)] string appUserModelId,
                [MarshalAs(UnmanagedType.LPWStr)] string arguments, int options, out uint processId);
            [PreserveSig]
            int ActivateForFile(IntPtr appUserModelId, IntPtr itemArray, IntPtr verb, out uint processId);
            [PreserveSig]
            int ActivateForProtocol(IntPtr appUserModelId, IntPtr itemArray, out uint processId);
        }

        [ComImport, Guid("45BA127D-10A8-46EA-8AB7-56EA9078943C")]
        private class ApplicationActivationManager
        {
        }

        public static Process FindRunningGame()
        {
            Process[] processes;
            try { processes = Process.GetProcessesByName(ProcessName); }
            catch { return null; }

            Process best = null;
            DateTime bestStart = DateTime.MinValue;
            foreach (Process p in processes)
            {
                try
                {
                    if (p.HasExited) continue;
                    DateTime started;
                    try { started = p.StartTime; }
                    catch { started = DateTime.MinValue; }
                    if (best == null || started > bestStart)
                    {
                        if (best != null) best.Dispose();
                        best = p;
                        bestStart = started;
                    }
                    else
                    {
                        p.Dispose();
                    }
                }
                catch
                {
                    try { p.Dispose(); } catch { }
                }
            }
            return best;
        }

        public static async Task<Process> WaitForWindowAsync(int timeoutMs, Action<int> elapsedCallback, CancellationToken token)
        {
            Stopwatch watch = Stopwatch.StartNew();
            Stopwatch noWindowWatch = null;
            int trackedPid = 0;
            int lastReported = -1;
            while (watch.ElapsedMilliseconds < timeoutMs)
            {
                token.ThrowIfCancellationRequested();
                Process process = FindRunningGame();
                if (process != null)
                {
                    bool hasWindow = false;
                    try
                    {
                        process.Refresh();
                        hasWindow = process.MainWindowHandle != IntPtr.Zero && !process.HasExited;
                    }
                    catch { }
                    if (hasWindow)
                    {
                        await Task.Delay(600, token);
                        try
                        {
                            process.Refresh();
                            if (!process.HasExited && process.MainWindowHandle != IntPtr.Zero)
                                return process;
                        }
                        catch { }
                        process.Dispose();
                        noWindowWatch = null;
                        trackedPid = 0;
                    }
                    else
                    {
                        try
                        {
                            if (process.HasExited)
                            {
                                process.Dispose();
                                noWindowWatch = null;
                                trackedPid = 0;
                            }
                            else
                            {
                                if (trackedPid != process.Id)
                                {
                                    trackedPid = process.Id;
                                    noWindowWatch = Stopwatch.StartNew();
                                }
                                // Some Minecraft/UWP builds do not expose a
                                // MainWindowHandle to external processes. If
                                // the game process has stayed alive for a
                                // while, continue with injection instead of
                                // waiting forever for a window that may never
                                // be reported.
                                if (noWindowWatch != null && noWindowWatch.ElapsedMilliseconds >= 15000)
                                {
                                    Log.Warn("Minecraft 未返回窗口句柄，但进程已稳定运行，继续注入");
                                    return process;
                                }
                                process.Dispose();
                            }
                        }
                        catch
                        {
                            process.Dispose();
                            noWindowWatch = null;
                            trackedPid = 0;
                        }
                    }
                }
                else
                {
                    noWindowWatch = null;
                    trackedPid = 0;
                }

                int seconds = (int)(watch.ElapsedMilliseconds / 1000);
                if (elapsedCallback != null && seconds != lastReported)
                {
                    lastReported = seconds;
                    elapsedCallback(seconds);
                }
                await Task.Delay(350, token);
            }
            throw new TimeoutException("等待 Minecraft 进程/窗口超时（" + (timeoutMs / 1000) + " 秒）。游戏可能仍在加载，或登录窗口需要操作。");
        }

        public static void Focus(Process process)
        {
            try
            {
                if (process == null || process.MainWindowHandle == IntPtr.Zero) return;
                Native.ShowWindowAsync(process.MainWindowHandle, Native.SW_RESTORE);
                Native.SetForegroundWindow(process.MainWindowHandle);
            }
            catch { }
        }

        public static void OpenStore()
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "explorer.exe",
                    Arguments = StoreUri,
                    UseShellExecute = true
                });
            }
            catch { }
        }

        public static bool IsGameRunning()
        {
            Process p = FindRunningGame();
            if (p == null) return false;
            p.Dispose();
            return true;
        }
    }
}
