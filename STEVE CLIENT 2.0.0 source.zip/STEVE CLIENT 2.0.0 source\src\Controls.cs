using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SteveClient
{
    internal enum IconGlyph
    {
        None,
        Play,
        Folder,
        Plus,
        Refresh,
        Trash,
        Close,
        Minimize,
        Settings,
        Shield,
        ChevronRight,
        ChevronDown,
        Download,
        Image,
        World,
        Cube,
        Warning,
        Info,
        Check,
        Power,
        Puzzle,
        Search,
        Reset
    }

    internal class BufferedPanel : Panel
    {
        public BufferedPanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            DoubleBuffered = true;
        }
    }

    /// <summary>
    /// A label that paints text only. It deliberately never fills its
    /// background, so it can sit on top of gradients and rounded cards without
    /// leaving opaque rectangles behind.
    /// </summary>
    internal class TextLabel : Control
    {
        private ContentAlignment _textAlign = ContentAlignment.MiddleLeft;
        private bool _autoEllipsis = true;

        public TextLabel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            ForeColor = Theme.Text;
            Font = Theme.Ui(10f);
            TabStop = false;
        }

        public ContentAlignment TextAlign
        {
            get { return _textAlign; }
            set { _textAlign = value; Invalidate(); }
        }

        public bool AutoEllipsis
        {
            get { return _autoEllipsis; }
            set { _autoEllipsis = value; Invalidate(); }
        }

        public override string Text
        {
            get { return base.Text; }
            set
            {
                base.Text = value;
                if (Parent != null)
                {
                    Rectangle r = new Rectangle(Left - 1, Top - 1, Width + 2, Height + 2);
                    Parent.Invalidate(r, false);
                }
                Invalidate();
            }
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            // Fill with the local surface colour. Callers set this to the
            // colour of the card/page underneath so the label blends in
            // instead of leaving a black or grey rectangle.
            using (SolidBrush b = new SolidBrush(BackColor))
                e.Graphics.FillRectangle(b, ClientRectangle);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            StringFormat format = new StringFormat(StringFormat.GenericTypographic);
            switch (_textAlign)
            {
                case ContentAlignment.TopCenter:
                case ContentAlignment.MiddleCenter:
                case ContentAlignment.BottomCenter:
                    format.Alignment = StringAlignment.Center; break;
                case ContentAlignment.TopRight:
                case ContentAlignment.MiddleRight:
                case ContentAlignment.BottomRight:
                    format.Alignment = StringAlignment.Far; break;
                default:
                    format.Alignment = StringAlignment.Near; break;
            }
            switch (_textAlign)
            {
                case ContentAlignment.TopLeft:
                case ContentAlignment.TopCenter:
                case ContentAlignment.TopRight:
                    format.LineAlignment = StringAlignment.Near; break;
                case ContentAlignment.BottomLeft:
                case ContentAlignment.BottomCenter:
                case ContentAlignment.BottomRight:
                    format.LineAlignment = StringAlignment.Far; break;
                default:
                    format.LineAlignment = StringAlignment.Center; break;
            }
            format.Trimming = _autoEllipsis ? StringTrimming.EllipsisCharacter : StringTrimming.None;
            format.FormatFlags |= StringFormatFlags.NoWrap;
            using (SolidBrush b = new SolidBrush(ForeColor))
                g.DrawString(Text, Font, b, new RectangleF(0, 0, Width, Height), format);
            format.Dispose();
        }
    }

    internal class PageHeader : Control
    {
        private string _subtitle = string.Empty;

        public PageHeader()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Bg;
            Height = Theme.S(66f);
        }

        public string Subtitle
        {
            get { return _subtitle; }
            set { _subtitle = value ?? string.Empty; Invalidate(); }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            using (SolidBrush b = new SolidBrush(Theme.Bg))
                g.FillRectangle(b, ClientRectangle);

            RectangleF rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(13f)))
            {
                using (LinearGradientBrush b = new LinearGradientBrush(rect,
                    Color.FromArgb(150, Theme.Surface2), Color.FromArgb(0, Theme.Bg), 90f))
                    g.FillPath(b, path);
                using (Pen pen = new Pen(Theme.Alpha(Theme.Border, 55), 1f))
                    g.DrawPath(pen, path);
                GraphicsState state = g.Save();
                g.SetClip(path);
                using (SolidBrush glow = new SolidBrush(Color.FromArgb(20, Theme.Accent)))
                    g.FillEllipse(glow, -Theme.SF(60f), -Theme.SF(90f), Theme.SF(360f), Theme.SF(190f));
                g.Restore(state);
            }

            // Accent tick before the title.
            using (GraphicsPath path = Theme.RoundRect(
                new RectangleF(Theme.SF(14f), Theme.SF(10f), Theme.SF(3f), Theme.SF(24f)), Theme.SF(1.5f)))
            using (SolidBrush b = new SolidBrush(Theme.Accent))
                g.FillPath(b, path);

            using (SolidBrush b = new SolidBrush(Theme.Text))
                g.DrawString(Text, Theme.Ui(23f, FontStyle.Bold), b,
                    new RectangleF(Theme.SF(26f), Theme.SF(1f), Width - Theme.SF(36f), Theme.SF(34f)), Theme.LeftCenter);
            using (SolidBrush b = new SolidBrush(Theme.Muted))
                g.DrawString(_subtitle, Theme.Ui(10.2f), b,
                    new RectangleF(Theme.SF(27f), Theme.SF(34f), Width - Theme.SF(40f), Theme.SF(22f)), Theme.LeftCenter);
        }
    }

    internal class RoundedPanel : Panel
    {
        public int Radius = 14;
        public Color BorderColor = Theme.BorderSoft;
        public bool ShowBorder = true;
        public Color GradientEnd = Color.Empty;

        public RoundedPanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            DoubleBuffered = true;
            BackColor = Theme.Surface;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(BackColor))
                e.Graphics.FillRectangle(b, ClientRectangle);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            Theme.ApplyRoundedRegion(this, Theme.SF(Radius));
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            RectangleF rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            float radius = Theme.SF(Radius);
            using (GraphicsPath path = Theme.RoundRect(rect, radius))
            {
                if (GradientEnd != Color.Empty)
                {
                    using (LinearGradientBrush brush = new LinearGradientBrush(rect, BackColor, GradientEnd, 25f))
                        g.FillPath(brush, path);
                }
                else
                {
                    using (SolidBrush brush = new SolidBrush(BackColor))
                        g.FillPath(brush, path);
                }
                if (ShowBorder)
                {
                    using (Pen pen = new Pen(BorderColor, 1f))
                        g.DrawPath(pen, path);
                }
            }
            base.OnPaint(e);
        }
    }

    internal class PillButton : Control
    {
        public IconGlyph Icon = IconGlyph.None;
        public bool Primary;
        public bool Danger;
        public bool Loading;
        private bool _hover;
        private bool _pressed;
        private readonly Timer _spinTimer;
        private float _spin;

        public PillButton()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor | ControlStyles.Selectable, true);
            BackColor = Color.Transparent;
            ForeColor = Theme.Text;
            Font = Theme.Ui(12.5f, FontStyle.Bold);
            Cursor = Cursors.Hand;
            TabStop = true;
            _spinTimer = new Timer();
            _spinTimer.Interval = 35;
            _spinTimer.Tick += delegate
            {
                _spin += 18f;
                if (_spin >= 360f) _spin -= 360f;
                Invalidate();
            };
        }

        public void SetLoading(bool loading)
        {
            Loading = loading;
            if (loading) _spinTimer.Start();
            else _spinTimer.Stop();
            Invalidate();
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            Theme.ApplyRoundedRegion(this, Math.Max(6f, Height / 2f));
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            RectangleF rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            float radius = Math.Max(6f, Height / 2f);
            Color fill;
            Color border = Color.Empty;
            Color text;
            Color icon;

            if (!Enabled)
            {
                fill = Theme.Surface2;
                border = Theme.BorderSoft;
                text = Theme.Muted2;
                icon = Theme.Muted2;
            }
            else if (Danger)
            {
                fill = _hover ? Color.FromArgb(244, 63, 94) : Color.FromArgb(225, 29, 72);
                text = Color.White;
                icon = Color.White;
            }
            else if (Primary)
            {
                fill = _hover ? Color.FromArgb(152, 108, 250) : Theme.Accent;
                text = Color.White;
                icon = Color.White;
            }
            else
            {
                fill = _pressed ? Theme.Surface3 : (_hover ? Theme.Surface3 : Theme.Surface2);
                border = _hover ? Theme.Mix(Theme.Border, Theme.Accent, 0.28f) : Theme.Border;
                text = Theme.TextSoft;
                icon = _hover ? Theme.AccentLight : Theme.Muted;
            }

            using (SolidBrush clear = new SolidBrush(fill))
                g.FillRectangle(clear, ClientRectangle);

            using (GraphicsPath path = Theme.RoundRect(rect, radius))
            using (SolidBrush brush = new SolidBrush(fill))
                g.FillPath(brush, path);

            if (Primary && Enabled)
            {
                using (LinearGradientBrush gloss = new LinearGradientBrush(rect,
                    Color.FromArgb(45, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
                using (GraphicsPath path = Theme.RoundRect(rect, radius))
                    g.FillPath(gloss, path);
            }

            if (border != Color.Empty)
            {
                RectangleF borderRect = new RectangleF(1.5f, 1.5f, Width - 3f, Height - 3f);
                float borderRadius = Math.Max(5f, Height / 2f - 1.5f);
                using (Pen pen = new Pen(border, 1f))
                using (GraphicsPath path = Theme.RoundRect(borderRect, borderRadius))
                    g.DrawPath(pen, path);
            }

            if (_pressed && Enabled) g.TranslateTransform(0f, 1f);

            float iconSize = Theme.SF(15f);
            float gap = Icon == IconGlyph.None ? 0f : Theme.SF(8f);
            SizeF textSize = g.MeasureString(Text, Font, 10000, Theme.Near);
            float total = textSize.Width + (Icon == IconGlyph.None && !Loading ? 0f : iconSize + gap);
            float startX = (Width - total) / 2f;
            float centerY = Height / 2f;
            float textX = startX;
            if (Loading)
            {
                DrawSpinner(g, new RectangleF(startX, centerY - iconSize / 2f, iconSize, iconSize), _spin, icon);
                textX += iconSize + gap;
            }
            else if (Icon != IconGlyph.None)
            {
                DrawGlyph(g, Icon, new RectangleF(startX, centerY - iconSize / 2f, iconSize, iconSize), icon, 1.7f);
                textX += iconSize + gap;
            }

            using (SolidBrush tb = new SolidBrush(text))
            using (StringFormat sf = LeftCenterFormat())
                g.DrawString(Text, Font, tb,
                    new RectangleF(textX, 0, Math.Max(1f, textSize.Width + Theme.SF(2f)), Height), sf);
        }

        private static StringFormat LeftCenterFormat()
        {
            StringFormat sf = new StringFormat(StringFormat.GenericTypographic);
            sf.Alignment = StringAlignment.Near;
            sf.LineAlignment = StringAlignment.Center;
            sf.Trimming = StringTrimming.EllipsisCharacter;
            sf.FormatFlags |= StringFormatFlags.NoWrap;
            return sf;
        }

        public static void DrawSpinner(Graphics g, RectangleF rect, float angle, Color color)
        {
            using (Pen bg = new Pen(Theme.Alpha(color, 55), Math.Max(1.5f, rect.Width / 9f)))
                g.DrawArc(bg, rect, 0, 360);
            using (Pen fg = new Pen(color, Math.Max(1.5f, rect.Width / 9f)))
            {
                fg.StartCap = LineCap.Round;
                fg.EndCap = LineCap.Round;
                g.DrawArc(fg, rect, angle, 110);
            }
        }

        public static void DrawGlyph(Graphics g, IconGlyph glyph, RectangleF r, Color color, float stroke)
        {
            float w = r.Width;
            float h = r.Height;
            float x = r.X;
            float y = r.Y;
            using (Pen pen = new Pen(color, Math.Max(1f, stroke)))
            {
                pen.StartCap = LineCap.Round;
                pen.EndCap = LineCap.Round;
                pen.LineJoin = LineJoin.Round;
                switch (glyph)
                {
                    case IconGlyph.Play:
                        {
                            PointF[] pts = { new PointF(x + w * 0.30f, y + h * 0.18f), new PointF(x + w * 0.82f, y + h * 0.50f), new PointF(x + w * 0.30f, y + h * 0.82f) };
                            using (SolidBrush b = new SolidBrush(color)) g.FillPolygon(b, pts);
                            break;
                        }
                    case IconGlyph.Folder:
                        {
                            GraphicsPath p = new GraphicsPath();
                            p.AddLines(new PointF[] {
                                new PointF(x + w*0.10f, y + h*0.30f),
                                new PointF(x + w*0.42f, y + h*0.30f),
                                new PointF(x + w*0.50f, y + h*0.42f),
                                new PointF(x + w*0.90f, y + h*0.42f),
                                new PointF(x + w*0.90f, y + h*0.80f),
                                new PointF(x + w*0.10f, y + h*0.80f)
                            });
                            p.CloseFigure();
                            g.DrawPath(pen, p);
                            p.Dispose();
                            break;
                        }
                    case IconGlyph.Plus:
                        g.DrawLine(pen, x + w * 0.5f, y + h * 0.2f, x + w * 0.5f, y + h * 0.8f);
                        g.DrawLine(pen, x + w * 0.2f, y + h * 0.5f, x + w * 0.8f, y + h * 0.5f);
                        break;
                    case IconGlyph.Refresh:
                        {
                            g.DrawArc(pen, x + w * 0.16f, y + h * 0.16f, w * 0.68f, h * 0.68f, 35, 285);
                            PointF tip = new PointF(x + w * 0.83f, y + h * 0.23f);
                            g.DrawLine(pen, tip, new PointF(tip.X - w * 0.15f, tip.Y));
                            g.DrawLine(pen, tip, new PointF(tip.X, tip.Y + h * 0.15f));
                            break;
                        }
                    case IconGlyph.Trash:
                        {
                            g.DrawLine(pen, x + w * 0.24f, y + h * 0.30f, x + w * 0.76f, y + h * 0.30f);
                            g.DrawLine(pen, x + w * 0.38f, y + h * 0.20f, x + w * 0.62f, y + h * 0.20f);
                            GraphicsPath p = new GraphicsPath();
                            p.AddLines(new PointF[] {
                                new PointF(x + w*0.30f, y + h*0.36f),
                                new PointF(x + w*0.34f, y + h*0.82f),
                                new PointF(x + w*0.66f, y + h*0.82f),
                                new PointF(x + w*0.70f, y + h*0.36f)
                            });
                            g.DrawPath(pen, p);
                            p.Dispose();
                            g.DrawLine(pen, x + w * 0.44f, y + h * 0.46f, x + w * 0.44f, y + h * 0.70f);
                            g.DrawLine(pen, x + w * 0.56f, y + h * 0.46f, x + w * 0.56f, y + h * 0.70f);
                            break;
                        }
                    case IconGlyph.Close:
                        g.DrawLine(pen, x + w * 0.28f, y + h * 0.28f, x + w * 0.72f, y + h * 0.72f);
                        g.DrawLine(pen, x + w * 0.72f, y + h * 0.28f, x + w * 0.28f, y + h * 0.72f);
                        break;
                    case IconGlyph.Minimize:
                        g.DrawLine(pen, x + w * 0.25f, y + h * 0.62f, x + w * 0.75f, y + h * 0.62f);
                        break;
                    case IconGlyph.Settings:
                        {
                            g.DrawEllipse(pen, x + w * 0.39f, y + h * 0.39f, w * 0.22f, h * 0.22f);
                            for (int i = 0; i < 8; i++)
                            {
                                double a = Math.PI * i / 4d;
                                float x1 = x + w * 0.5f + (float)Math.Cos(a) * w * 0.28f;
                                float y1 = y + h * 0.5f + (float)Math.Sin(a) * h * 0.28f;
                                float x2 = x + w * 0.5f + (float)Math.Cos(a) * w * 0.40f;
                                float y2 = y + h * 0.5f + (float)Math.Sin(a) * h * 0.40f;
                                g.DrawLine(pen, x1, y1, x2, y2);
                            }
                            break;
                        }
                    case IconGlyph.Shield:
                        {
                            GraphicsPath p = new GraphicsPath();
                            p.AddLines(new PointF[] {
                                new PointF(x + w*0.5f, y + h*0.12f),
                                new PointF(x + w*0.84f, y + h*0.26f),
                                new PointF(x + w*0.78f, y + h*0.64f),
                                new PointF(x + w*0.5f, y + h*0.88f),
                                new PointF(x + w*0.22f, y + h*0.64f),
                                new PointF(x + w*0.16f, y + h*0.26f)
                            });
                            p.CloseFigure();
                            g.DrawPath(pen, p);
                            p.Dispose();
                            g.DrawLine(pen, x + w * 0.36f, y + h * 0.52f, x + w * 0.47f, y + h * 0.63f);
                            g.DrawLine(pen, x + w * 0.47f, y + h * 0.63f, x + w * 0.66f, y + h * 0.40f);
                            break;
                        }
                    case IconGlyph.ChevronRight:
                        g.DrawLine(pen, x + w * 0.4f, y + h * 0.24f, x + w * 0.62f, y + h * 0.5f);
                        g.DrawLine(pen, x + w * 0.62f, y + h * 0.5f, x + w * 0.4f, y + h * 0.76f);
                        break;
                    case IconGlyph.ChevronDown:
                        g.DrawLine(pen, x + w * 0.28f, y + h * 0.40f, x + w * 0.5f, y + h * 0.62f);
                        g.DrawLine(pen, x + w * 0.5f, y + h * 0.62f, x + w * 0.72f, y + h * 0.40f);
                        break;
                    case IconGlyph.Image:
                        {
                            g.DrawRectangle(pen, x + w * 0.14f, y + h * 0.22f, w * 0.72f, h * 0.56f);
                            using (SolidBrush b = new SolidBrush(color))
                                g.FillEllipse(b, x + w * 0.26f, y + h * 0.32f, w * 0.12f, h * 0.12f);
                            g.DrawLine(pen, x + w * 0.2f, y + h * 0.72f, x + w * 0.44f, y + h * 0.46f);
                            g.DrawLine(pen, x + w * 0.44f, y + h * 0.46f, x + w * 0.62f, y + h * 0.64f);
                            g.DrawLine(pen, x + w * 0.62f, y + h * 0.64f, x + w * 0.74f, y + h * 0.52f);
                            break;
                        }
                    case IconGlyph.World:
                        {
                            g.DrawEllipse(pen, x + w * 0.12f, y + h * 0.12f, w * 0.76f, h * 0.76f);
                            g.DrawEllipse(pen, x + w * 0.31f, y + h * 0.12f, w * 0.38f, h * 0.76f);
                            g.DrawLine(pen, x + w * 0.12f, y + h * 0.5f, x + w * 0.88f, y + h * 0.5f);
                            break;
                        }
                    case IconGlyph.Download:
                        g.DrawLine(pen, x + w * 0.5f, y + h * 0.15f, x + w * 0.5f, y + h * 0.62f);
                        g.DrawLine(pen, x + w * 0.5f, y + h * 0.62f, x + w * 0.32f, y + h * 0.44f);
                        g.DrawLine(pen, x + w * 0.5f, y + h * 0.62f, x + w * 0.68f, y + h * 0.44f);
                        g.DrawLine(pen, x + w * 0.2f, y + h * 0.82f, x + w * 0.8f, y + h * 0.82f);
                        break;
                    case IconGlyph.Cube:
                        {
                            PointF top = new PointF(x + w * 0.5f, y + h * 0.08f);
                            PointF left = new PointF(x + w * 0.1f, y + h * 0.30f);
                            PointF right = new PointF(x + w * 0.9f, y + h * 0.30f);
                            PointF center = new PointF(x + w * 0.5f, y + h * 0.52f);
                            PointF bl = new PointF(x + w * 0.1f, y + h * 0.70f);
                            PointF br = new PointF(x + w * 0.9f, y + h * 0.70f);
                            PointF bottom = new PointF(x + w * 0.5f, y + h * 0.92f);
                            g.DrawPolygon(pen, new PointF[] { top, right, center, left });
                            g.DrawPolygon(pen, new PointF[] { left, center, bottom, bl });
                            g.DrawPolygon(pen, new PointF[] { center, right, br, bottom });
                            break;
                        }
                    case IconGlyph.Warning:
                        {
                            g.DrawPolygon(pen, new PointF[] {
                                new PointF(x + w*0.5f, y + h*0.12f),
                                new PointF(x + w*0.9f, y + h*0.84f),
                                new PointF(x + w*0.1f, y + h*0.84f)
                            });
                            g.DrawLine(pen, x + w * 0.5f, y + h * 0.36f, x + w * 0.5f, y + h * 0.58f);
                            using (SolidBrush b = new SolidBrush(color)) g.FillEllipse(b, x + w * 0.46f, y + h * 0.67f, w * 0.08f, h * 0.08f);
                            break;
                        }
                    case IconGlyph.Info:
                        g.DrawEllipse(pen, x + w * 0.14f, y + h * 0.14f, w * 0.72f, h * 0.72f);
                        g.DrawLine(pen, x + w * 0.5f, y + h * 0.46f, x + w * 0.5f, y + h * 0.68f);
                        using (SolidBrush b = new SolidBrush(color)) g.FillEllipse(b, x + w * 0.46f, y + h * 0.29f, w * 0.08f, h * 0.08f);
                        break;
                    case IconGlyph.Check:
                        g.DrawLine(pen, x + w * 0.18f, y + h * 0.52f, x + w * 0.42f, y + h * 0.76f);
                        g.DrawLine(pen, x + w * 0.42f, y + h * 0.76f, x + w * 0.84f, y + h * 0.26f);
                        break;
                    case IconGlyph.Power:
                        g.DrawArc(pen, x + w * 0.18f, y + h * 0.20f, w * 0.64f, h * 0.64f, -50, 280);
                        g.DrawLine(pen, x + w * 0.5f, y + h * 0.12f, x + w * 0.5f, y + h * 0.46f);
                        break;
                    case IconGlyph.Puzzle:
                        {
                            GraphicsPath p = new GraphicsPath();
                            p.AddLines(new PointF[] {
                                new PointF(x + w*0.18f, y + h*0.26f),
                                new PointF(x + w*0.42f, y + h*0.26f),
                                new PointF(x + w*0.42f, y + h*0.14f),
                                new PointF(x + w*0.58f, y + h*0.14f),
                                new PointF(x + w*0.58f, y + h*0.26f),
                                new PointF(x + w*0.82f, y + h*0.26f),
                                new PointF(x + w*0.82f, y + h*0.46f),
                                new PointF(x + w*0.94f, y + h*0.46f),
                                new PointF(x + w*0.94f, y + h*0.62f),
                                new PointF(x + w*0.82f, y + h*0.62f),
                                new PointF(x + w*0.82f, y + h*0.82f),
                                new PointF(x + w*0.18f, y + h*0.82f)
                            });
                            p.CloseFigure();
                            g.DrawPath(pen, p);
                            p.Dispose();
                            break;
                        }
                    case IconGlyph.Search:
                        g.DrawEllipse(pen, x + w * 0.18f, y + h * 0.18f, w * 0.48f, h * 0.48f);
                        g.DrawLine(pen, x + w * 0.62f, y + h * 0.62f, x + w * 0.84f, y + h * 0.84f);
                        break;
                    case IconGlyph.Reset:
                        g.DrawArc(pen, x + w * 0.16f, y + h * 0.16f, w * 0.68f, h * 0.68f, 130, 250);
                        g.DrawLine(pen, x + w * 0.2f, y + h * 0.2f, x + w * 0.2f, y + h * 0.42f);
                        g.DrawLine(pen, x + w * 0.2f, y + h * 0.2f, x + w * 0.41f, y + h * 0.2f);
                        break;
                }
            }
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            _hover = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            _hover = false;
            _pressed = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && Enabled)
            {
                _pressed = true;
                Focus();
                Invalidate();
            }
            base.OnMouseDown(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            _pressed = false;
            Invalidate();
            base.OnMouseUp(e);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space || e.KeyCode == Keys.Enter)
            {
                OnClick(EventArgs.Empty);
                e.Handled = true;
            }
            base.OnKeyUp(e);
        }

        protected override void OnEnabledChanged(EventArgs e)
        {
            Cursor = Enabled ? Cursors.Hand : Cursors.Default;
            Invalidate();
            base.OnEnabledChanged(e);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _spinTimer.Dispose();
            base.Dispose(disposing);
        }
    }

    internal class IconButton : Control
    {
        public IconGlyph Glyph = IconGlyph.Close;
        public bool CloseStyle;
        private bool _hover;

        public IconButton()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Theme.Bg;
            Cursor = Cursors.Hand;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            if (_hover)
            {
                Color fill = CloseStyle ? Color.FromArgb(190, 225, 29, 72) : Theme.Surface2;
                using (GraphicsPath path = Theme.RoundRect(new RectangleF(1, 1, Width - 2, Height - 2), Theme.SF(7f)))
                using (SolidBrush b = new SolidBrush(fill))
                    g.FillPath(b, path);
            }
            float size = Theme.SF(15f);
            Color color = _hover && CloseStyle ? Color.White : (_hover ? Theme.Text : Theme.Muted);
            PillButton.DrawGlyph(g, Glyph, new RectangleF((Width - size) / 2f, (Height - size) / 2f, size, size), color, 1.4f);
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }
    }

    internal class ToggleSwitch : Control
    {
        private bool _checked;
        private float _anim;
        private readonly Timer _timer;
        private bool _hover;

        public event EventHandler CheckedChanged;

        public ToggleSwitch()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Theme.Surface;
            Cursor = Cursors.Hand;
            Size = new Size(Theme.S(44), Theme.S(24));
            _timer = new Timer();
            _timer.Interval = 14;
            _timer.Tick += delegate
            {
                float target = _checked ? 1f : 0f;
                if (Math.Abs(_anim - target) < 0.03f)
                {
                    _anim = target;
                    _timer.Stop();
                }
                else
                {
                    _anim += (target - _anim) * 0.28f;
                }
                Invalidate();
            };
        }

        public bool Checked
        {
            get { return _checked; }
            set { SetChecked(value, true); }
        }

        public void SetCheckedSilent(bool value)
        {
            _checked = value;
            _anim = value ? 1f : 0f;
            Invalidate();
        }

        private void SetChecked(bool value, bool raise)
        {
            if (_checked == value) return;
            _checked = value;
            _timer.Start();
            Invalidate();
            if (raise && CheckedChanged != null) CheckedChanged(this, EventArgs.Empty);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            RectangleF track = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            Color off = _hover ? Theme.Surface3 : Theme.Surface2;
            Color on = Theme.Accent;
            Color fill = Theme.Mix(off, on, _anim);
            using (GraphicsPath path = Theme.RoundRect(track, Height / 2f))
            using (SolidBrush b = new SolidBrush(fill))
                g.FillPath(b, path);
            using (Pen pen = new Pen(_checked ? Theme.Alpha(Theme.AccentLight, 120) : Theme.Border, 1f))
            using (GraphicsPath path = Theme.RoundRect(track, Height / 2f))
                g.DrawPath(pen, path);

            float pad = Theme.SF(3f);
            float knob = Height - pad * 2f;
            float x = pad + (Width - pad * 2f - knob) * _anim;
            using (SolidBrush shadow = new SolidBrush(Color.FromArgb(60, 0, 0, 0)))
                g.FillEllipse(shadow, x + 0.5f, pad + 1f, knob, knob);
            using (SolidBrush b = new SolidBrush(_checked ? Color.White : Color.FromArgb(203, 210, 228)))
                g.FillEllipse(b, x, pad, knob, knob);
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnClick(EventArgs e)
        {
            if (Enabled) SetChecked(!_checked, true);
            base.OnClick(e);
        }
        protected override void OnKeyUp(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space || e.KeyCode == Keys.Enter)
            {
                if (Enabled) SetChecked(!_checked, true);
                e.Handled = true;
            }
            base.OnKeyUp(e);
        }
        protected override void OnEnabledChanged(EventArgs e)
        {
            Cursor = Enabled ? Cursors.Hand : Cursors.Default;
            Invalidate();
            base.OnEnabledChanged(e);
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing) _timer.Dispose();
            base.Dispose(disposing);
        }
    }

    internal class Badge : Control
    {
        private string _text = string.Empty;
        private Color _dot = Theme.Success;
        private Color _fill = Theme.Surface2;
        private Color _border = Theme.Border;

        public Badge()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Theme.Bg;
            Font = Theme.Ui(10.5f, FontStyle.Regular);
        }

        public void SetData(string text, Color dot, Color fill, Color border)
        {
            _text = text ?? string.Empty;
            _dot = dot;
            _fill = fill;
            _border = border;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            RectangleF rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            using (GraphicsPath path = Theme.RoundRect(rect, Height / 2f))
            using (SolidBrush b = new SolidBrush(_fill))
                g.FillPath(b, path);
            using (Pen pen = new Pen(_border, 1f))
            using (GraphicsPath path = Theme.RoundRect(rect, Height / 2f))
                g.DrawPath(pen, path);

            float dot = Theme.SF(6f);
            float x = Theme.SF(11f);
            using (SolidBrush b = new SolidBrush(_dot))
                g.FillEllipse(b, x, (Height - dot) / 2f, dot, dot);
            using (SolidBrush b = new SolidBrush(Theme.TextSoft))
                g.DrawString(_text, Font, b, new RectangleF(x + dot + Theme.SF(7f), 0, Width - x - dot - Theme.SF(10f), Height), Theme.Near);
        }
    }

    internal class StatCard : Control
    {
        public string Caption = string.Empty;
        public string Value = string.Empty;
        public string Hint = string.Empty;
        public IconGlyph Glyph = IconGlyph.Puzzle;
        public Color Accent = Theme.Accent;

        public StatCard()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Theme.Bg;
        }

        public void SetData(string caption, string value, string hint, IconGlyph glyph, Color accent)
        {
            Caption = caption;
            Value = value;
            Hint = hint;
            Glyph = glyph;
            Accent = accent;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            float pad = Theme.SF(14f);
            RectangleF rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(12f)))
            {
                using (LinearGradientBrush b = new LinearGradientBrush(rect, Theme.Surface, Theme.Mix(Theme.Surface, Accent, 0.06f), 20f))
                    g.FillPath(b, path);
                using (Pen pen = new Pen(Theme.BorderSoft, 1f))
                    g.DrawPath(pen, path);
            }

            float tile = Theme.SF(34f);
            RectangleF tileRect = new RectangleF(pad, (Height - tile) / 2f, tile, tile);
            using (GraphicsPath path = Theme.RoundRect(tileRect, Theme.SF(9f)))
            using (SolidBrush b = new SolidBrush(Theme.Alpha(Accent, 30)))
                g.FillPath(b, path);
            float icon = Theme.SF(17f);
            PillButton.DrawGlyph(g, Glyph, new RectangleF(tileRect.X + (tile - icon) / 2f, tileRect.Y + (tile - icon) / 2f, icon, icon), Accent, 1.5f);

            float textX = tileRect.Right + Theme.SF(12f);
            using (SolidBrush b = new SolidBrush(Theme.Muted))
                g.DrawString(Caption, Theme.Ui(9.8f), b, new RectangleF(textX, Theme.SF(10f), Width - textX - pad, Theme.SF(16f)), Theme.Near);
            using (SolidBrush b = new SolidBrush(Theme.Text))
                g.DrawString(Value, Theme.Display(16.5f, FontStyle.Bold), b, new RectangleF(textX, Theme.SF(25f), Width - textX - pad, Theme.SF(24f)), Theme.Near);
            if (!string.IsNullOrEmpty(Hint))
            {
                using (SolidBrush b = new SolidBrush(Theme.Muted2))
                    g.DrawString(Hint, Theme.Ui(8.8f), b, new RectangleF(textX, Theme.SF(49f), Width - textX - pad, Theme.SF(15f)), Theme.Near);
            }
        }
    }

    internal class HeroCard : Control
    {
        private readonly PillButton _launch;
        private string _version = string.Empty;
        private string _status = "游戏未运行";
        private Color _statusColor = Theme.Muted;
        private int _enabled;
        private int _total;
        private bool _installed;
        private bool _busy;

        public event EventHandler LaunchRequested;

        public HeroCard()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Theme.Bg;
            _launch = new PillButton();
            _launch.Text = "启动游戏";
            _launch.Icon = IconGlyph.Play;
            _launch.Primary = true;
            _launch.Click += delegate { if (LaunchRequested != null) LaunchRequested(this, EventArgs.Empty); };
            Controls.Add(_launch);
            Resize += delegate { LayoutButton(); };
        }

        public void SetState(string version, int enabled, int total, bool installed, string status, Color statusColor, bool busy, bool gameRunning)
        {
            _version = version ?? string.Empty;
            _enabled = enabled;
            _total = total;
            _installed = installed;
            _status = status ?? string.Empty;
            _statusColor = statusColor;
            _busy = busy;
            _launch.Text = busy ? "正在启动..." : (gameRunning ? "注入游戏" : "启动游戏");
            _launch.SetLoading(busy);
            _launch.Enabled = !busy;
            Invalidate();
        }

        public void SetLaunchEnabled(bool enabled)
        {
            _launch.Enabled = enabled;
            Invalidate();
        }

        private void LayoutButton()
        {
            if (_launch == null) return;
            int w = Theme.S(184f);
            int h = Theme.S(50f);
            _launch.Bounds = new Rectangle(Theme.S(28f), Height - h - Theme.S(20f), w, h);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            RectangleF rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(16f)))
            {
                using (LinearGradientBrush b = new LinearGradientBrush(rect,
                    Color.FromArgb(25, 21, 44), Color.FromArgb(13, 22, 35), 12f))
                    g.FillPath(b, path);

                GraphicsState state = g.Save();
                g.SetClip(path);
                using (SolidBrush glow = new SolidBrush(Color.FromArgb(52, Theme.Accent)))
                    g.FillEllipse(glow, Width - Theme.SF(340f), -Theme.SF(120f), Theme.SF(420f), Theme.SF(360f));
                using (SolidBrush glow2 = new SolidBrush(Color.FromArgb(24, Theme.Accent2)))
                    g.FillEllipse(glow2, Width - Theme.SF(230f), Theme.SF(40f), Theme.SF(250f), Theme.SF(250f));
                using (Pen grid = new Pen(Color.FromArgb(13, 255, 255, 255), 1f))
                {
                    for (int x = 0; x < Width; x += Theme.S(34f))
                        g.DrawLine(grid, x, 0, x, Height);
                    for (int y = 0; y < Height; y += Theme.S(34f))
                        g.DrawLine(grid, 0, y, Width, y);
                }
                g.Restore(state);

                using (Pen pen = new Pen(Theme.Alpha(Theme.Accent, 70), 1f))
                    g.DrawPath(pen, path);
            }

            float pad = Theme.SF(28f);
            Color white = Theme.Text;
            Font titleFont = Theme.Display(39f, FontStyle.Bold);
            SizeF titleSize = g.MeasureString("MINECRAFT", titleFont, 10000, Theme.Near);
            float titleCenter = pad + titleSize.Width / 2f;
            using (SolidBrush b = new SolidBrush(white))
                g.DrawString("MINECRAFT", titleFont, b,
                    new RectangleF(pad, Theme.SF(20f), Width - Theme.SF(300f), Theme.SF(50f)), Theme.Near);

            Font editionFont = Theme.Ui(10f, FontStyle.Bold);
            float editionSpacing = Theme.SF(2.6f);
            float editionWidth = Theme.MeasureSpaced(g, "BEDROCK EDITION", editionFont, editionSpacing);
            Theme.DrawSpaced(g, "BEDROCK EDITION", editionFont, Theme.AccentLight,
                titleCenter - editionWidth / 2f, Theme.SF(70f), editionSpacing);

            string versionLine = "for Windows" + (string.IsNullOrEmpty(_version) ? "" : "  ·  v" + _version);
            Font versionFont = Theme.Ui(10.5f);
            SizeF versionSize = g.MeasureString(versionLine, versionFont, 10000, Theme.Near);
            float versionWidth = Math.Max(titleSize.Width, versionSize.Width) + Theme.SF(20f);
            using (SolidBrush b = new SolidBrush(Theme.Muted))
                g.DrawString(versionLine, versionFont, b,
                    new RectangleF(titleCenter - versionWidth / 2f, Theme.SF(89f), versionWidth, Theme.SF(20f)),
                    Theme.Center);

            float statusY = Height - Theme.SF(102f);
            DrawStatus(g, titleCenter, statusY);

            using (SolidBrush b = new SolidBrush(Theme.Muted2))
                g.DrawString(_total == 0 ? "尚未添加 DLL" : (_enabled + " / " + _total + " 个模块已启用"),
                    Theme.Ui(9.5f), b, new RectangleF(pad, Height - Theme.SF(42f), Theme.SF(190f), Theme.SF(16f)), Theme.Near);

            DrawCube(g, Width - Theme.SF(150f), Theme.SF(42f), Theme.SF(70f));

            using (SolidBrush b = new SolidBrush(Theme.Muted))
                g.DrawString("AUTO INJECT", Theme.Ui(8.5f, FontStyle.Bold), b,
                    new RectangleF(Width - Theme.SF(128f), Theme.SF(18f), Theme.SF(108f), Theme.SF(16f)),
                    RightFormat());
        }

        private void DrawStatus(Graphics g, float centerX, float y)
        {
            float dot = Theme.SF(7f);
            float gap = Theme.SF(8f);
            Font statusFont = Theme.Ui(10.5f);
            float textWidth = g.MeasureString(_status, statusFont).Width;
            float total = dot + gap + textWidth;
            float x = centerX - total / 2f;
            float dotY = y + Theme.SF(10f) - dot / 2f;
            using (SolidBrush halo = new SolidBrush(Theme.Alpha(_statusColor, 45)))
                g.FillEllipse(halo, x - Theme.SF(4f), dotY - Theme.SF(4f), dot + Theme.SF(8f), dot + Theme.SF(8f));
            using (SolidBrush b = new SolidBrush(_statusColor))
                g.FillEllipse(b, x, dotY, dot, dot);
            using (SolidBrush b = new SolidBrush(Theme.TextSoft))
                g.DrawString(_status, statusFont, b,
                    new RectangleF(x + dot + gap, y, textWidth + Theme.SF(8f), Theme.SF(20f)), Theme.LeftCenter);
        }

        private static StringFormat RightFormat()
        {
            StringFormat sf = new StringFormat(StringFormat.GenericTypographic);
            sf.Alignment = StringAlignment.Far;
            sf.LineAlignment = StringAlignment.Near;
            sf.FormatFlags |= StringFormatFlags.NoWrap;
            return sf;
        }

        private void DrawCube(Graphics g, float x, float y, float u)
        {
            float topY = y + u * 0.06f;
            float midY = y + u * 0.40f;
            float lowY = y + u * 0.64f;
            float bottomY = y + u * 0.98f;
            PointF top = new PointF(x + u * 0.5f, topY);
            PointF left = new PointF(x, midY);
            PointF right = new PointF(x + u, midY);
            PointF center = new PointF(x + u * 0.5f, y + u * 0.58f);
            PointF bottomLeft = new PointF(x, lowY);
            PointF bottomRight = new PointF(x + u, lowY);
            PointF bottom = new PointF(x + u * 0.5f, bottomY);

            using (SolidBrush glow = new SolidBrush(Color.FromArgb(50, Theme.Accent2)))
                g.FillEllipse(glow, x - u * 0.35f, y + u * 0.35f, u * 1.7f, u * 0.55f);

            using (SolidBrush b = new SolidBrush(Color.FromArgb(125, 167, 139, 250)))
                g.FillPolygon(b, new PointF[] { top, right, center, left });
            using (SolidBrush b = new SolidBrush(Color.FromArgb(185, 109, 40, 217)))
                g.FillPolygon(b, new PointF[] { left, center, bottom, bottomLeft });
            using (SolidBrush b = new SolidBrush(Color.FromArgb(210, 76, 29, 149)))
                g.FillPolygon(b, new PointF[] { center, right, bottomRight, bottom });
            using (Pen pen = new Pen(Color.FromArgb(135, 220, 205, 255), 1.2f))
            {
                g.DrawPolygon(pen, new PointF[] { top, right, center, left });
                g.DrawPolygon(pen, new PointF[] { left, center, bottom, bottomLeft });
                g.DrawPolygon(pen, new PointF[] { center, right, bottomRight, bottom });
            }

            float tiny = u * 0.18f;
            using (SolidBrush b = new SolidBrush(Color.FromArgb(80, Theme.Accent2)))
            {
                g.FillPolygon(b, new PointF[] {
                    new PointF(x + u * 1.08f, y + u * 0.12f),
                    new PointF(x + u * 1.22f, y + u * 0.20f),
                    new PointF(x + u * 1.08f, y + u * 0.28f),
                    new PointF(x + u * 0.94f, y + u * 0.20f)
                });
            }
            using (SolidBrush b = new SolidBrush(Color.FromArgb(55, Theme.AccentLight)))
            {
                g.FillPolygon(b, new PointF[] {
                    new PointF(x - u * 0.05f, y + u * 0.73f),
                    new PointF(x + u * 0.05f, y + u * 0.79f),
                    new PointF(x - u * 0.05f, y + u * 0.85f),
                    new PointF(x - u * 0.15f, y + u * 0.79f)
                });
            }
        }
    }

    internal class ModuleStrip : Control
    {
        private List<DllInfo> _dlls = new List<DllInfo>();
        private bool _hover;

        public ModuleStrip()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Theme.Bg;
            Cursor = Cursors.Hand;
        }

        public void SetDlls(List<DllInfo> dlls)
        {
            _dlls = dlls ?? new List<DllInfo>();
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            RectangleF rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(13f)))
            {
                using (SolidBrush b = new SolidBrush(_hover ? Theme.Surface2 : Theme.Surface))
                    g.FillPath(b, path);
                using (Pen pen = new Pen(_hover ? Theme.Mix(Theme.Border, Theme.Accent, 0.3f) : Theme.BorderSoft, 1f))
                    g.DrawPath(pen, path);
            }

            float pad = Theme.SF(16f);
            float icon = Theme.SF(15f);
            PillButton.DrawGlyph(g, IconGlyph.Puzzle, new RectangleF(pad, Theme.SF(15f), icon, icon), Theme.AccentLight, 1.4f);
            using (SolidBrush b = new SolidBrush(Theme.Text))
                g.DrawString("模块队列", Theme.Ui(11.5f, FontStyle.Bold), b, new RectangleF(pad + icon + Theme.SF(8f), Theme.SF(12f), Theme.SF(140f), Theme.SF(20f)), Theme.Near);

            int enabled = 0;
            foreach (DllInfo d in _dlls) if (d.Enabled) enabled++;
            using (SolidBrush b = new SolidBrush(Theme.Muted))
                g.DrawString(enabled + " 已启用 · 共 " + _dlls.Count + " 个", Theme.Ui(9.8f), b,
                    new RectangleF(Width - Theme.SF(190f) - pad, Theme.SF(15f), Theme.SF(190f), Theme.SF(18f)), RightFormat());

            float y = Theme.SF(40f);
            float x = pad;
            int shown = 0;
            foreach (DllInfo d in _dlls)
            {
                if (!d.Enabled) continue;
                if (shown >= 4) break;
                string name = d.FileName;
                if (name.Length > 16) name = name.Substring(0, 14) + "…";
                SizeF size = g.MeasureString(name, Theme.Ui(9.5f));
                float chipW = Math.Min(size.Width + Theme.SF(24f), Theme.SF(180f));
                if (x + chipW > Width - pad - Theme.SF(50f)) break;
                RectangleF chip = new RectangleF(x, y, chipW, Theme.SF(23f));
                using (GraphicsPath path = Theme.RoundRect(chip, Theme.SF(6f)))
                using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Accent, 22)))
                    g.FillPath(b, path);
                using (Pen pen = new Pen(Theme.Alpha(Theme.Accent, 55), 1f))
                using (GraphicsPath path = Theme.RoundRect(chip, Theme.SF(6f)))
                    g.DrawPath(pen, path);
                using (SolidBrush b = new SolidBrush(Theme.AccentLight))
                    g.DrawString(name, Theme.Ui(9.5f), b, chip, CenterFormat());
                x += chipW + Theme.SF(7f);
                shown++;
            }

            if (_dlls.Count == 0)
            {
                using (SolidBrush b = new SolidBrush(Theme.Muted2))
                    g.DrawString("将 DLL 拖入窗口，或点击这里管理模块", Theme.Ui(9.8f), b,
                        new RectangleF(pad, y + Theme.SF(2f), Width - pad * 2f, Theme.SF(20f)), Theme.Near);
            }
            else if (enabled > shown)
            {
                using (SolidBrush b = new SolidBrush(Theme.Muted))
                    g.DrawString("+" + (enabled - shown), Theme.Ui(9.5f), b,
                        new RectangleF(Width - pad - Theme.SF(42f), y + Theme.SF(2f), Theme.SF(42f), Theme.SF(20f)), RightFormat());
            }
        }

        private static StringFormat CenterFormat()
        {
            StringFormat sf = new StringFormat(StringFormat.GenericTypographic);
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;
            sf.Trimming = StringTrimming.EllipsisCharacter;
            sf.FormatFlags |= StringFormatFlags.NoWrap;
            return sf;
        }

        private static StringFormat RightFormat()
        {
            StringFormat sf = new StringFormat(StringFormat.GenericTypographic);
            sf.Alignment = StringAlignment.Far;
            sf.LineAlignment = StringAlignment.Near;
            sf.FormatFlags |= StringFormatFlags.NoWrap;
            return sf;
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }
    }
}


