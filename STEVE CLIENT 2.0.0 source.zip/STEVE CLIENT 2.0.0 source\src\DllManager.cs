using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace SteveClient
{
    internal enum DllState
    {
        Ready,
        Injecting,
        Loaded,
        Failed,
        Skipped
    }

    internal enum PeArchitecture
    {
        Unknown,
        X86,
        X64,
        Arm64
    }

    internal sealed class PeInfo
    {
        public bool Valid;
        public bool IsDll;
        public PeArchitecture Architecture = PeArchitecture.Unknown;
        public string Error = string.Empty;

        public bool IsCompatible
        {
            get { return Valid && IsDll && Architecture == PeArchitecture.X64; }
        }

        public string ArchitectureText
        {
            get
            {
                switch (Architecture)
                {
                    case PeArchitecture.X64: return "64 位";
                    case PeArchitecture.X86: return "32 位";
                    case PeArchitecture.Arm64: return "ARM64";
                    default: return "未知";
                }
            }
        }
    }

    internal sealed class DllInfo
    {
        public string FilePath;
        public string FileName;
        public long FileSize;
        public DateTime Modified;
        public bool Enabled;
        public PeInfo Pe;
        public DllState State = DllState.Ready;
        public string StateDetail = string.Empty;

        public string SizeText
        {
            get { return DllManager.FormatSize(FileSize); }
        }

        public string StateText
        {
            get
            {
                switch (State)
                {
                    case DllState.Injecting: return "注入中";
                    case DllState.Loaded: return "已注入";
                    case DllState.Failed: return "失败";
                    case DllState.Skipped: return "已存在";
                    default: return Enabled ? "就绪" : "已禁用";
                }
            }
        }

        public string MetaText
        {
            get
            {
                string arch = Pe != null ? Pe.ArchitectureText : "未知";
                return SizeText + "  ·  " + arch + "  ·  " + Modified.ToString("yyyy/MM/dd HH:mm");
            }
        }
    }

    internal sealed class ImportResult
    {
        public readonly List<string> Imported = new List<string>();
        public readonly List<string> Skipped = new List<string>();
        public readonly List<string> Errors = new List<string>();
    }

    internal static class PeInspector
    {
        public static PeInfo Inspect(string path)
        {
            PeInfo info = new PeInfo();
            try
            {
                using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (BinaryReader br = new BinaryReader(fs))
                {
                    if (fs.Length < 0x40)
                    {
                        info.Error = "文件太小，不是有效的 PE 文件";
                        return info;
                    }
                    fs.Position = 0x3C;
                    int peOffset = br.ReadInt32();
                    if (peOffset <= 0 || peOffset + 24L > fs.Length)
                    {
                        info.Error = "PE 头偏移无效";
                        return info;
                    }
                    fs.Position = peOffset;
                    uint signature = br.ReadUInt32();
                    if (signature != 0x00004550)
                    {
                        info.Error = "缺少 PE 签名";
                        return info;
                    }

                    ushort machine = br.ReadUInt16();
                    br.ReadUInt16(); // sections
                    br.ReadUInt32(); // timestamp
                    br.ReadUInt32(); // symbol table
                    br.ReadUInt32(); // symbol count
                    ushort optionalSize = br.ReadUInt16();
                    ushort characteristics = br.ReadUInt16();

                    info.Valid = true;
                    info.IsDll = (characteristics & 0x2000) != 0;
                    switch (machine)
                    {
                        case 0x8664: info.Architecture = PeArchitecture.X64; break;
                        case 0x014C: info.Architecture = PeArchitecture.X86; break;
                        case 0xAA64: info.Architecture = PeArchitecture.Arm64; break;
                        default: info.Architecture = PeArchitecture.Unknown; break;
                    }

                    if (optionalSize >= 2 && peOffset + 24L + optionalSize <= fs.Length)
                    {
                        fs.Position = peOffset + 24L;
                        ushort magic = br.ReadUInt16();
                        if (magic == 0x20B && machine == 0x014C)
                            info.Architecture = PeArchitecture.X64; // PE32+ should be 64-bit
                    }

                    if (!info.IsDll) info.Error = "不是 DLL 文件";
                    else if (info.Architecture != PeArchitecture.X64)
                        info.Error = "不是 64 位 DLL（当前：" + info.ArchitectureText + "）";
                }
            }
            catch (Exception ex)
            {
                info.Valid = false;
                info.Error = "读取失败：" + ex.Message;
            }
            return info;
        }
    }

    internal static class DllManager
    {
        public static List<DllInfo> Scan(string directory, AppConfig config)
        {
            List<DllInfo> result = new List<DllInfo>();
            Directory.CreateDirectory(directory);
            string[] files;
            try
            {
                files = Directory.GetFiles(directory, "*.dll", SearchOption.TopDirectoryOnly);
            }
            catch (Exception ex)
            {
                Log.Warn("扫描 DLL 文件夹失败：" + ex.Message);
                return result;
            }
            Array.Sort(files, StringComparer.OrdinalIgnoreCase);
            foreach (string file in files)
            {
                try
                {
                    FileInfo fi = new FileInfo(file);
                    DllInfo info = new DllInfo();
                    info.FilePath = file;
                    info.FileName = fi.Name;
                    info.FileSize = fi.Length;
                    info.Modified = fi.LastWriteTime;
                    bool? saved = config.GetDllState(fi.Name);
                    info.Enabled = saved.HasValue ? saved.Value : true;
                    info.Pe = PeInspector.Inspect(file);
                    if (!info.Enabled) info.State = DllState.Ready;
                    result.Add(info);
                }
                catch (Exception ex)
                {
                    Log.Warn("读取 DLL 信息失败：" + Path.GetFileName(file) + " - " + ex.Message);
                }
            }
            return result;
        }

        public static ImportResult Import(IEnumerable<string> sourceFiles, string targetDirectory, bool overwrite)
        {
            ImportResult result = new ImportResult();
            Directory.CreateDirectory(targetDirectory);
            foreach (string source in sourceFiles)
            {
                try
                {
                    if (string.IsNullOrWhiteSpace(source)) continue;
                    string full = Path.GetFullPath(source);
                    if (!File.Exists(full))
                    {
                        result.Errors.Add("文件不存在：" + source);
                        continue;
                    }
                    if (!string.Equals(Path.GetExtension(full), ".dll", StringComparison.OrdinalIgnoreCase))
                    {
                        result.Errors.Add("不是 DLL 文件：" + Path.GetFileName(full));
                        continue;
                    }

                    string name = Path.GetFileName(full);
                    string dest = Path.Combine(targetDirectory, name);
                    if (string.Equals(Path.GetFullPath(dest), full, StringComparison.OrdinalIgnoreCase))
                    {
                        result.Skipped.Add(name + "（已在 DLLs 中）");
                        continue;
                    }
                    if (File.Exists(dest) && !overwrite)
                    {
                        result.Skipped.Add(name + "（同名文件已存在）");
                        continue;
                    }

                    if (File.Exists(dest))
                    {
                        FileAttributes attrs = File.GetAttributes(dest);
                        if ((attrs & FileAttributes.ReadOnly) != 0) File.SetAttributes(dest, attrs & ~FileAttributes.ReadOnly);
                    }
                    File.Copy(full, dest, true);
                    result.Imported.Add(name);
                }
                catch (Exception ex)
                {
                    result.Errors.Add(Path.GetFileName(source) + "：" + ex.Message);
                }
            }
            return result;
        }

        public static bool Archive(string filePath, out string message)
        {
            message = string.Empty;
            try
            {
                Directory.CreateDirectory(AppPaths.TrashDir);
                string name = Path.GetFileNameWithoutExtension(filePath);
                string ext = Path.GetExtension(filePath);
                string dest = Path.Combine(AppPaths.TrashDir, name + "." + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ext);
                File.Move(filePath, dest);
                message = "已移动到 " + dest;
                return true;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return false;
            }
        }

        public static string FormatSize(long bytes)
        {
            if (bytes >= 1024L * 1024L * 1024L) return (bytes / 1024d / 1024d / 1024d).ToString("0.00") + " GB";
            if (bytes >= 1024L * 1024L) return (bytes / 1024d / 1024d).ToString("0.0") + " MB";
            if (bytes >= 1024L) return (bytes / 1024d).ToString("0.0") + " KB";
            return bytes + " B";
        }
    }
}
