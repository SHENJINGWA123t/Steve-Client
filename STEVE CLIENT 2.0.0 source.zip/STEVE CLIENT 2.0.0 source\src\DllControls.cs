using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace SteveClient
{
    internal class DllRow : Control
    {
        public DllInfo Item;
        public event EventHandler ToggleRequested;
        public event EventHandler RemoveRequested;
        public event EventHandler OpenFolderRequested;
        public event Action<string[]> FilesDropped;
        private bool _hover;
        private RectangleF _toggleRect;
        private RectangleF _removeRect;

        public DllRow()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor | ControlStyles.Selectable, true);
            BackColor = Theme.Bg;
            Cursor = Cursors.Hand;
            TabStop = true;
        }

        public void Bind(DllInfo item)
        {
            Item = item;
            AccessibleName = item.FileName;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (Item == null) return;
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            RectangleF rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            bool active = Item.Enabled;
            using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(11f)))
            {
                Color fill = _hover ? Theme.Surface2 : Theme.Surface;
                if (Focused) fill = Theme.Mix(fill, Theme.Accent, 0.06f);
                using (SolidBrush b = new SolidBrush(fill))
                    g.FillPath(b, path);
                Color border = _hover ? Theme.Mix(Theme.Border, Theme.Accent, 0.22f) : Theme.BorderSoft;
                using (Pen pen = new Pen(border, 1f))
                    g.DrawPath(pen, path);
            }

            float pad = Theme.SF(12f);
            float tile = Theme.SF(38f);
            RectangleF tileRect = new RectangleF(pad, (Height - tile) / 2f, tile, tile);
            Color accent = Item.Pe != null && Item.Pe.IsCompatible ? Theme.Accent : Theme.Warning;
            if (!active) accent = Theme.Muted2;
            using (GraphicsPath path = Theme.RoundRect(tileRect, Theme.SF(9f)))
                using (SolidBrush b = new SolidBrush(Theme.Alpha(accent, active ? 28 : 15)))
                    g.FillPath(b, path);
            float icon = Theme.SF(18f);
            PillButton.DrawGlyph(g, IconGlyph.Puzzle, new RectangleF(tileRect.X + (tile - icon) / 2f, tileRect.Y + (tile - icon) / 2f, icon, icon), accent, 1.4f);

            float textX = tileRect.Right + Theme.SF(12f);
            float textW = Math.Max(Theme.SF(60f), Width - textX - Theme.SF(250f));
            Color nameColor = active ? Theme.Text : Theme.Muted;
            using (SolidBrush b = new SolidBrush(nameColor))
                g.DrawString(Item.FileName, Theme.Ui(12.2f, FontStyle.Bold), b,
                    new RectangleF(textX, Theme.SF(10f), textW, Theme.SF(22f)), Theme.Near);
            using (SolidBrush b = new SolidBrush(Theme.Muted2))
                g.DrawString(Item.MetaText, Theme.Ui(9.2f), b,
                    new RectangleF(textX, Theme.SF(32f), textW, Theme.SF(18f)), Theme.Near);

            Color stateColor;
            switch (Item.State)
            {
                case DllState.Loaded: stateColor = Theme.Success; break;
                case DllState.Failed: stateColor = Theme.Danger; break;
                case DllState.Injecting: stateColor = Theme.Accent2; break;
                case DllState.Skipped: stateColor = Theme.Warning; break;
                default: stateColor = active ? Theme.Muted : Theme.Muted2; break;
            }

            float toggleW = Theme.SF(42f);
            float toggleH = Theme.SF(22f);
            _toggleRect = new RectangleF(Width - pad - toggleW, (Height - toggleH) / 2f, toggleW, toggleH);

            float stateW = Theme.SF(116f);
            RectangleF stateRect = new RectangleF(_toggleRect.X - stateW - Theme.SF(8f), 0, stateW, Height);
            using (SolidBrush b = new SolidBrush(stateColor))
                g.DrawString(Item.StateText, Theme.Ui(9.4f), b, stateRect, RightCenterFormat());

            DrawToggle(g, _toggleRect, active, Item.State == DllState.Injecting);

            if (_hover)
            {
                float remove = Theme.SF(14f);
                _removeRect = new RectangleF(_toggleRect.X - stateW - Theme.SF(34f), (Height - Theme.SF(24f)) / 2f, Theme.SF(24f), Theme.SF(24f));
                using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Danger, 18)))
                    g.FillEllipse(b, _removeRect);
                PillButton.DrawGlyph(g, IconGlyph.Trash, new RectangleF(_removeRect.X + Theme.SF(6f), _removeRect.Y + Theme.SF(6f), remove, remove), Theme.Danger, 1.1f);
            }
            else
            {
                _removeRect = RectangleF.Empty;
            }
        }

        private static StringFormat RightCenterFormat()
        {
            StringFormat sf = new StringFormat(StringFormat.GenericTypographic);
            sf.Alignment = StringAlignment.Far;
            sf.LineAlignment = StringAlignment.Center;
            sf.Trimming = StringTrimming.EllipsisCharacter;
            sf.FormatFlags |= StringFormatFlags.NoWrap;
            return sf;
        }

        private static void DrawToggle(Graphics g, RectangleF rect, bool on, bool busy)
        {
            Color track = on ? (busy ? Theme.Alpha(Theme.Accent2, 180) : Theme.Accent) : Theme.Surface3;
            using (GraphicsPath path = Theme.RoundRect(rect, rect.Height / 2f))
            using (SolidBrush b = new SolidBrush(track))
                g.FillPath(b, path);
            using (Pen pen = new Pen(on ? Theme.Alpha(Theme.AccentLight, 100) : Theme.Border, 1f))
            using (GraphicsPath path = Theme.RoundRect(rect, rect.Height / 2f))
                g.DrawPath(pen, path);
            float knob = rect.Height - 4f;
            float x = on ? rect.Right - knob - 2f : rect.X + 2f;
            using (SolidBrush b = new SolidBrush(on ? Color.White : Color.FromArgb(190, 198, 216)))
                g.FillEllipse(b, x, rect.Y + 2f, knob, knob);
            if (busy)
            {
                using (Pen pen = new Pen(Color.White, 1.2f))
                {
                    pen.StartCap = LineCap.Round;
                    pen.EndCap = LineCap.Round;
                    g.DrawArc(pen, x + knob * 0.28f, rect.Y + 2f + knob * 0.28f, knob * 0.44f, knob * 0.44f, 10, 260);
                }
            }
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseClick(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (_toggleRect.Contains(e.Location))
                {
                    if (ToggleRequested != null) ToggleRequested(this, EventArgs.Empty);
                }
                else if (!_removeRect.IsEmpty && _removeRect.Contains(e.Location))
                {
                    if (RemoveRequested != null) RemoveRequested(this, EventArgs.Empty);
                }
                else
                {
                    Focus();
                }
            }
            base.OnMouseClick(e);
        }

        protected override void OnDoubleClick(EventArgs e)
        {
            if (OpenFolderRequested != null) OpenFolderRequested(this, EventArgs.Empty);
            base.OnDoubleClick(e);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space || e.KeyCode == Keys.Enter)
            {
                if (ToggleRequested != null) ToggleRequested(this, EventArgs.Empty);
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Delete)
            {
                if (RemoveRequested != null) RemoveRequested(this, EventArgs.Empty);
                e.Handled = true;
            }
            base.OnKeyUp(e);
        }

        protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.EnableFileDrop(Handle);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == Native.WM_DROPFILES)
            {
                string[] files = Native.ReadDropFiles(m.WParam);
                if (files.Length > 0 && FilesDropped != null) FilesDropped(files);
                return;
            }
            base.WndProc(ref m);
        }
    }

    internal class DllListPanel : Panel
    {
        private readonly List<DllRow> _rows = new List<DllRow>();
        private List<DllInfo> _items = new List<DllInfo>();
        private int _scrollOffset;
        private int _contentHeight;
        private bool _draggingThumb;
        private int _dragStartY;
        private int _dragStartOffset;
        private RectangleF _thumbRect;

        public event EventHandler<DllRow> ToggleRequested;
        public event EventHandler<DllRow> RemoveRequested;
        public event EventHandler<DllRow> OpenFolderRequested;
        public event EventHandler<DllRow> ContextRequested;
        public event Action<string[]> FilesDropped;

        public DllListPanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            AutoScroll = false;
            AllowDrop = true;
            BackColor = Theme.Bg;
            DoubleBuffered = true;
            Padding = new Padding(0);
        }

        public List<DllInfo> Items
        {
            get { return _items; }
        }

        public void SetDlls(List<DllInfo> items)
        {
            _items = items ?? new List<DllInfo>();
            _scrollOffset = 0;
            SuspendLayout();
            foreach (DllRow row in _rows)
            {
                Controls.Remove(row);
                row.Dispose();
            }
            _rows.Clear();

            foreach (DllInfo item in _items)
            {
                DllRow row = new DllRow();
                row.Bind(item);
                row.ToggleRequested += delegate { if (ToggleRequested != null) ToggleRequested(row, row); };
                row.RemoveRequested += delegate { if (RemoveRequested != null) RemoveRequested(row, row); };
                row.OpenFolderRequested += delegate { if (OpenFolderRequested != null) OpenFolderRequested(row, row); };
                row.MouseUp += delegate(object sender, MouseEventArgs e)
                {
                    if (e.Button == MouseButtons.Right && ContextRequested != null)
                        ContextRequested(row, row);
                };
                row.MouseWheel += delegate(object sender, MouseEventArgs e) { ScrollBy(-e.Delta); };
                row.FilesDropped += delegate(string[] files) { if (FilesDropped != null) FilesDropped(files); };
                Controls.Add(row);
                _rows.Add(row);
            }
            ResumeLayout(true);
            LayoutRows();
            Invalidate();
        }

        public void RefreshStates()
        {
            foreach (DllRow row in _rows) row.Invalidate();
            Invalidate();
        }

        private void LayoutRows()
        {
            int gap = Theme.S(8f);
            int rowHeight = Theme.S(64f);
            _contentHeight = _rows.Count == 0 ? 0 : _rows.Count * (rowHeight + gap) - gap;
            int maxOffset = Math.Max(0, _contentHeight - ClientSize.Height);
            if (_scrollOffset > maxOffset) _scrollOffset = maxOffset;
            if (_scrollOffset < 0) _scrollOffset = 0;

            bool scrollable = _contentHeight > ClientSize.Height;
            int width = ClientSize.Width - Theme.S(4f) - (scrollable ? Theme.S(8f) : 0);
            width = Math.Max(Theme.S(200f), width);
            int y = -_scrollOffset;
            foreach (DllRow row in _rows)
            {
                row.Bounds = new Rectangle(0, y, width, rowHeight);
                y += rowHeight + gap;
            }
            Invalidate();
        }

        private void ScrollBy(int amount)
        {
            int maxOffset = Math.Max(0, _contentHeight - ClientSize.Height);
            int next = Math.Max(0, Math.Min(maxOffset, _scrollOffset + amount));
            if (next == _scrollOffset) return;
            _scrollOffset = next;
            LayoutRows();
        }

        protected override void OnResize(EventArgs eventargs)
        {
            base.OnResize(eventargs);
            LayoutRows();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(Theme.Bg))
                e.Graphics.FillRectangle(b, ClientRectangle);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (_items.Count == 0)
            {
                Graphics g = e.Graphics;
                Theme.Prepare(g);
                float margin = Theme.SF(8f);
                RectangleF rect = new RectangleF(margin, margin, Width - margin * 2f, Math.Max(Theme.SF(240f), Height - margin * 2f));
                using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(14f)))
                using (Pen pen = new Pen(Theme.Border, 1f))
                {
                    pen.DashStyle = DashStyle.Dash;
                    g.DrawPath(pen, path);
                }
                float icon = Theme.SF(42f);
                float centerX = rect.X + rect.Width / 2f;
                float top = rect.Y + Math.Max(Theme.SF(40f), (rect.Height - Theme.SF(150f)) / 2f);
                using (GraphicsPath path = Theme.RoundRect(new RectangleF(centerX - icon / 2f, top, icon, icon), Theme.SF(11f)))
                using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Accent, 24)))
                    g.FillPath(b, path);
                PillButton.DrawGlyph(g, IconGlyph.Download, new RectangleF(centerX - Theme.SF(11f), top + Theme.SF(11f), Theme.SF(20f), Theme.SF(20f)), Theme.AccentLight, 1.5f);
                using (SolidBrush b = new SolidBrush(Theme.TextSoft))
                    g.DrawString("把 DLL 拖到这里", Theme.Ui(15f, FontStyle.Bold), b,
                        new RectangleF(rect.X, top + Theme.SF(58f), rect.Width, Theme.SF(28f)), Theme.Center);
                using (SolidBrush b = new SolidBrush(Theme.Muted))
                    g.DrawString("支持一次拖入多个 .dll 文件，或点击右上角“添加 DLL”", Theme.Ui(10.2f), b,
                        new RectangleF(rect.X, top + Theme.SF(88f), rect.Width, Theme.SF(24f)), Theme.Center);
                using (SolidBrush b = new SolidBrush(Theme.Muted2))
                    g.DrawString("DLL 必须与 Minecraft for Windows 一样是 64 位", Theme.Ui(9.3f), b,
                        new RectangleF(rect.X, top + Theme.SF(112f), rect.Width, Theme.SF(20f)), Theme.Center);
            }
            DrawScrollbar(e.Graphics);
        }

        private void DrawScrollbar(Graphics g)
        {
            if (_contentHeight <= ClientSize.Height || ClientSize.Height <= 0) return;
            Theme.Prepare(g);
            float trackW = Theme.SF(4f);
            float x = Width - Theme.SF(9f);
            float top = Theme.SF(4f);
            float trackH = Height - Theme.SF(8f);
            using (SolidBrush b = new SolidBrush(Theme.Alpha(Theme.Border, 120)))
                Theme.FillRound(g, b, new RectangleF(x, top, trackW, trackH), trackW / 2f);
            float thumbH = Math.Max(Theme.SF(32f), trackH * (float)Height / _contentHeight);
            float maxOffset = Math.Max(1, _contentHeight - Height);
            float thumbY = top + (trackH - thumbH) * ((float)_scrollOffset / maxOffset);
            _thumbRect = new RectangleF(x, thumbY, trackW, thumbH);
            using (SolidBrush b = new SolidBrush(_draggingThumb ? Theme.AccentLight : Theme.Accent))
                Theme.FillRound(g, b, _thumbRect, trackW / 2f);
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            ScrollBy(-e.Delta * Theme.S(1) / 2);
            base.OnMouseWheel(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && !_thumbRect.IsEmpty && _thumbRect.Contains(e.Location))
            {
                _draggingThumb = true;
                _dragStartY = e.Y;
                _dragStartOffset = _scrollOffset;
                Invalidate();
            }
            base.OnMouseDown(e);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (_draggingThumb)
            {
                float trackH = Height - Theme.SF(8f);
                float thumbH = _thumbRect.Height;
                float range = Math.Max(1f, trackH - thumbH);
                int maxOffset = Math.Max(1, _contentHeight - Height);
                int target = _dragStartOffset + (int)((e.Y - _dragStartY) / range * maxOffset);
                target = Math.Max(0, Math.Min(maxOffset, target));
                if (target != _scrollOffset)
                {
                    _scrollOffset = target;
                    LayoutRows();
                }
            }
            base.OnMouseMove(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (_draggingThumb)
            {
                _draggingThumb = false;
                Invalidate();
            }
            base.OnMouseUp(e);
        }

        private static string[] GetDroppedDlls(IDataObject data)
        {
            if (data == null || !data.GetDataPresent(DataFormats.FileDrop)) return new string[0];
            string[] paths = data.GetData(DataFormats.FileDrop) as string[];
            if (paths == null) return new string[0];
            List<string> dlls = new List<string>();
            foreach (string path in paths)
                if (string.Equals(Path.GetExtension(path), ".dll", StringComparison.OrdinalIgnoreCase))
                    dlls.Add(path);
            return dlls.ToArray();
        }

        protected override void OnDragEnter(DragEventArgs e)
        {
            e.Effect = GetDroppedDlls(e.Data).Length > 0 ? DragDropEffects.Copy : DragDropEffects.None;
            base.OnDragEnter(e);
        }

        protected override void OnDragDrop(DragEventArgs e)
        {
            string[] files = GetDroppedDlls(e.Data);
            if (files.Length > 0 && FilesDropped != null) FilesDropped(files);
            base.OnDragDrop(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == Native.WM_DROPFILES)
            {
                string[] files = Native.ReadDropFiles(m.WParam);
                List<string> dlls = new List<string>();
                foreach (string file in files)
                    if (string.Equals(Path.GetExtension(file), ".dll", StringComparison.OrdinalIgnoreCase))
                        dlls.Add(file);
                if (dlls.Count > 0 && FilesDropped != null) FilesDropped(dlls.ToArray());
                return;
            }
            base.WndProc(ref m);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.ApplyDarkTheme(Handle);
            Native.EnableFileDrop(Handle);
        }
    }

    internal class LogView : RichTextBox
    {
        public LogView()
        {
            BorderStyle = BorderStyle.None;
            BackColor = Theme.Surface;
            ForeColor = Theme.TextSoft;
            Font = Theme.Mono(10.5f, FontStyle.Regular);
            ReadOnly = true;
            DetectUrls = false;
            WordWrap = true;
            ScrollBars = RichTextBoxScrollBars.None;
            TabStop = false;
        }

        public void AppendEntry(LogEntry entry)
        {
            if (entry == null) return;
            Color color;
            switch (entry.Level)
            {
                case LogLevel.Success: color = Theme.Success; break;
                case LogLevel.Warning: color = Theme.Warning; break;
                case LogLevel.Error: color = Theme.Danger; break;
                default: color = Theme.TextSoft; break;
            }
            SelectionStart = TextLength;
            SelectionLength = 0;
            SelectionColor = Theme.Muted2;
            AppendText(entry.Time.ToString("HH:mm:ss") + "  ");
            SelectionColor = color;
            AppendText(entry.Message + Environment.NewLine);
            SelectionStart = TextLength;
            ScrollToCaret();
        }

        public void AppendRaw(string message, Color color)
        {
            SelectionStart = TextLength;
            SelectionLength = 0;
            SelectionColor = color;
            AppendText(message + Environment.NewLine);
            SelectionStart = TextLength;
            ScrollToCaret();
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            Native.ApplyDarkTheme(Handle);
        }
    }

    internal enum ToastKind
    {
        Info,
        Success,
        Warning,
        Error
    }

    internal class Toast : Control
    {
        private string _message = string.Empty;
        private ToastKind _kind = ToastKind.Info;
        private readonly Timer _timer;
        private Color _accent = Theme.Accent;

        public Toast()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Bg;
            Visible = false;
            _timer = new Timer();
            _timer.Interval = 3300;
            _timer.Tick += delegate { _timer.Stop(); Visible = false; };
        }

        public void ShowMessage(string message, ToastKind kind, Control parent)
        {
            _message = message ?? string.Empty;
            _kind = kind;
            switch (kind)
            {
                case ToastKind.Success: _accent = Theme.Success; break;
                case ToastKind.Warning: _accent = Theme.Warning; break;
                case ToastKind.Error: _accent = Theme.Danger; break;
                default: _accent = Theme.Accent2; break;
            }
            using (Graphics g = CreateGraphics())
            {
                SizeF size = g.MeasureString(_message, Theme.Ui(10.5f), Theme.S(430));
                int w = Math.Min(Theme.S(480), Math.Max(Theme.S(220), (int)size.Width + Theme.S(62)));
                int h = Theme.S(48);
                Width = w;
                Height = h;
            }
            PositionIn(parent);
            Visible = true;
            BringToFront();
            Invalidate();
            _timer.Stop();
            _timer.Start();
        }

        public void PositionIn(Control parent)
        {
            if (parent == null) return;
            Left = Math.Max(Theme.S(16f), (parent.ClientSize.Width - Width) / 2);
            Top = parent.ClientSize.Height - Height - Theme.S(20f);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Theme.Prepare(g);
            RectangleF rect = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(10f)))
            using (SolidBrush b = new SolidBrush(Color.FromArgb(248, Theme.Surface2)))
                g.FillPath(b, path);
            using (Pen pen = new Pen(Theme.Alpha(_accent, 100), 1f))
            using (GraphicsPath path = Theme.RoundRect(rect, Theme.SF(10f)))
                g.DrawPath(pen, path);
            using (GraphicsPath path = Theme.RoundRect(new RectangleF(0, Theme.SF(8f), Theme.SF(3f), Height - Theme.SF(16f)), Theme.SF(1.5f)))
            using (SolidBrush b = new SolidBrush(_accent))
                g.FillPath(b, path);

            Font font = Theme.Ui(10.5f);
            using (SolidBrush b = new SolidBrush(Theme.Text))
            using (StringFormat sf = new StringFormat(StringFormat.GenericTypographic))
            {
                sf.Alignment = StringAlignment.Center;
                sf.LineAlignment = StringAlignment.Center;
                sf.Trimming = StringTrimming.EllipsisCharacter;
                sf.FormatFlags |= StringFormatFlags.NoWrap;
                g.DrawString(_message, font, b,
                    new RectangleF(Theme.SF(18f), 0, Math.Max(1f, Width - Theme.SF(36f)), Height), sf);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _timer.Dispose();
            base.Dispose(disposing);
        }
    }
}
